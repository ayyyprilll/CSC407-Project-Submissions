# How the security works, in plain language

A short guide for explaining and defending the project. Each section says **what the problem is**, **what this code does about it**, and **which file to open** to show it. File names are relative to the project root.

---

## 1. Password hashing

**The problem.** If passwords are stored as plain text, anyone who copies the database (a leak, a stolen backup) instantly has every password, and people reuse passwords on other sites.

**The idea.** Store a *hash* instead. A hash is a one-way scramble: easy to compute from the password, practically impossible to reverse. When you log in, the app scrambles what you typed and compares the result with the stored scramble. The app never needs to know the real password again.

**What this app does.** It uses **bcrypt**, which was designed for passwords:

- bcrypt adds a random **salt** to each password before hashing, so two users with the same password get different hashes, and pre-computed "rainbow tables" are useless.
- bcrypt is deliberately **slow**. The *cost factor* (12) means each guess takes a noticeable fraction of a second. That is irrelevant for one login, but it makes an attacker's billions of guesses very expensive.
- The salt and cost are stored inside the hash string itself (it starts with `$2b$12$...`), so nothing extra needs storing.

**Where.**
- `src/routes/auth.js`: `bcrypt.hash(...)` when registering; `bcrypt.compare(...)` when logging in.
- `src/config.js`: `bcryptRounds` (12 in production; 4 only during tests so the test suite is fast).
- `src/utils/password.js`: the password policy (at least 10 characters, a letter and a number, at most 72 bytes because bcrypt ignores anything longer).
- `src/db/seed.js`: even the seeded admin goes through bcrypt, and the password comes from an environment variable, not the code.

**Related detail: the dummy hash.** In `src/routes/auth.js`, if the email does not exist the code still runs `bcrypt.compare` against `DUMMY_HASH`. Without this, "unknown email" would answer faster than "wrong password", and an attacker could time the responses to discover which emails have accounts.

**How to show it.** Open the database (`data/lab.db`) in a SQLite viewer: the `password_hash` column holds long `$2b$12$...` strings, never passwords.

---

## 2. Sessions

**The problem.** HTTP forgets you between requests. After you log in, the server must recognise you on the next click without asking for your password again.

**The idea.** Give the browser a random ID (a "session ID") in a cookie. The server keeps a record: "this ID belongs to user 7". The browser sends the cookie with every request, and the server looks up who it is. The ID must be unguessable, and must be protected.

**What this app does.**

- The session record lives **on the server**, in the `sessions` table of the SQLite database. The cookie only contains a long random ID, signed with `SESSION_SECRET` so it cannot be forged.
- **Cookie flags** protect the cookie: `HttpOnly` (JavaScript cannot read it, so an XSS bug cannot steal it), `SameSite=Lax` (not sent on cross-site POSTs), `Secure` in production (HTTPS only).
- **Expiry:** logged out after 30 minutes without activity, and never later than 8 hours after login.
- **Regeneration on login:** at login the old session is thrown away and a brand-new ID is issued. This stops *session fixation*, where an attacker plants a known ID in your browser before you log in.
- **Destruction on logout:** the server deletes the session row and tells the browser to drop the cookie.
- **Fresh data on every request:** the session only stores the user's id. On each request the app re-reads the user from the database, so if an admin deactivates you or changes your role, it takes effect on your very next click.
- **Password change** ends the account's other sessions (a stolen session does not survive a password change).

**Where.**
- `src/middleware/session.js`: cookie settings, timeouts, and `loadUser` (the fresh lookup).
- `src/routes/auth.js`: `regenerate` at login, `destroy` at logout.
- `src/routes/profile.js`: regenerates the session and calls `deleteOtherSessions` after a password change (`src/models/users.js`).
- `src/middleware/auth.js`: `requireLogin` and `requireRole`, which use the user that `loadUser` found.

**How to show it.** Browser dev tools > Application > Cookies: `lab.sid` has HttpOnly and SameSite. Type `document.cookie` in the console: the session cookie is not listed.

---

## 3. Parameterized queries (SQL injection)

**The problem.** If code builds SQL by gluing strings together:

```js
db.prepare("SELECT * FROM users WHERE email = '" + email + "'")   // DANGEROUS
```

then an email like `' OR '1'='1` changes the *meaning* of the query. Attackers can read other people's data, log in without a password or delete tables.

**The idea.** Keep the SQL text and the data separate. Write the query with a placeholder, and hand the data over separately. The database treats the data purely as a value, never as SQL, whatever characters it contains.

**What this app does.** Every query in the project looks like this:

```js
db.prepare('SELECT * FROM users WHERE email = ?').get(email)   // safe
```

- User input is only ever passed as `?` parameters.
- Where a query has optional filters (search, status...), the code adds **fixed, hard-coded fragments** like `AND status = ?` to the SQL, and puts the user's value in the parameter list. The SQL text itself never contains user input.
- For `LIKE` searches, the characters `%` and `_` (which are wildcards) are escaped in `src/utils/query.js` (`likePattern`) so a user cannot craft slow or surprising patterns.
- IDs from URLs must be plain digits (`parseId`), otherwise they become `0` and match nothing.
- The database itself adds a second layer: `CHECK`, `UNIQUE` and `FOREIGN KEY` constraints in `src/db/schema.sql` refuse bad data even if the application had a bug.

**Where.** All files in `src/models/` (every query), `src/utils/query.js` (`likePattern`, `parseId`, `str`, `oneOf`), `src/db/schema.sql`.

**How to show it.** Type `'; DROP TABLE users; --` into the computers search box. The page simply says "no results", and everything still works. `tests/injection.test.js` runs a list of payloads against every entry point.

---

## 4. CSRF (cross-site request forgery)

**The problem.** Browsers automatically attach your cookies to any request to our site, even a request triggered by a *different* website. So if you are logged in here and visit an evil page, that page could contain a hidden form that POSTs to `/admin/users/5/role` or `/logout`. Your browser would send your session cookie, and our server would think *you* asked for it.

**The idea.** Require something an attacker's page cannot know. Every form carries a secret random token, and the server only accepts a state-changing request if the token matches. The evil site cannot read our pages (the browser blocks that), so it cannot learn the token.

**What this app does.**

- It uses the `csrf-csrf` library ("double submit cookie", bound to the session). A signed token is placed in a **hidden field** (`_csrf`) of every form and also in a **cookie**. On every POST, the server checks that the form token and the cookie agree and belong to this session.
- Missing, wrong or expired token: the request is refused with **403** and a friendly "Form expired" page, and nothing is changed.
- Logout is a POST, so a malicious image tag on another site cannot log you out.
- `SameSite=Lax` on the cookies is an extra layer: browsers will not send them on cross-site POSTs in the first place.
- The `__Host-` prefix on the CSRF cookie name in production makes the browser insist it is Secure and not shared with subdomains.

**Where.**
- `src/middleware/csrf.js`: configuration, plus `exposeCsrfToken` which gives every template a `csrfToken`.
- `src/app.js`: the order matters: session first, then `csrfProtection`, then routes. The check runs before any route handler.
- Every `<form method="post">` in `views/` contains `<input type="hidden" name="_csrf" value="<%= csrfToken %>">`.

**How to show it.** In dev tools, delete the hidden `_csrf` input from a form and submit: you get the "Form expired" 403 page and nothing happens. `tests/csrf.test.js` automates this.

---

## 5. CSP (Content Security Policy) and XSS

**The problem (XSS).** If an attacker gets their text shown on a page as *HTML*, for example a booking purpose of `<script>steal()</script>`, the script runs in every viewer's browser with that viewer's privileges.

**Two layers of defence.**

1. **Escaping output.** All templates use EJS's `<%= value %>`, which converts `<` to `&lt;` and so on. The browser then *shows* `<script>` as harmless text instead of running it. (The unescaped tag `<%- %>` is used only for including our own partial templates, never for user data.) Also, free-text inputs reject `<` and `>` entirely (`src/validators/common.js`), and names use a strict letters-only pattern (`src/validators/auth.js`).
2. **Content Security Policy.** A header that tells the browser: "only run scripts, load styles, fonts and images that come from *my own origin*". Because this app has **no inline scripts, no `onclick=` attributes and no `style=` attributes**, the policy can be strict: no `'unsafe-inline'` at all. Even if an attacker somehow got a `<script>` tag into a page, the browser would refuse to run it. The policy also forbids plugins (`object-src 'none'`), framing by other sites (`frame-ancestors 'none'`, which stops clickjacking), and form posts to other sites (`form-action 'self'`).

The small amount of JavaScript the app needs (opening the mobile menu, "are you sure?" prompts) is in `public/js/app.js`, loaded as an external file. Fonts are self-hosted in `public/fonts/` so nothing is fetched from Google. The "are you sure?" prompt uses a `data-confirm` attribute handled by that file, instead of an inline `onsubmit`.

**Where.**
- `src/middleware/security.js`: the CSP directives (and the other Helmet headers).
- `views/**/*.ejs`: the `<%= %>` tags.
- `src/validators/common.js` and `src/validators/auth.js`: input rules.
- `public/js/app.js`: the only script.

**How to show it.** Dev tools > Network > click a page > Response Headers > `Content-Security-Policy`. Then in the Console, try to inject a script (see `TESTING.md` X-04): the browser blocks it and logs a CSP violation. View page source: there are no inline scripts.

---

## 6. Quick answers for questions you may get

**"Why are the role checks on the server and not just hiding menu links?"** Hiding a link is cosmetic: anyone can type the URL. The real check is `requireRole('admin')` (`src/middleware/auth.js`). The whole `/admin` router has it as its first line (`src/routes/admin.js`), so a route cannot be added there and left open.

**"What stops user A from cancelling user B's booking by changing the ID?"** The query is `... WHERE id = ? AND user_id = ?` where the second value is the logged-in user's id from the session (`findOwn` / `cancelOwn` in `src/models/bookings.js`). Someone else's booking looks exactly like a booking that does not exist: 404.

**"Why does login say 'Invalid email or password' for everything?"** If it said "no such user" or "account locked", attackers could discover which emails are registered. Same message, same timing, for every failure. Registration behaves the same way for an email that already exists.

**"What if someone guesses passwords?"** Two layers: an IP-based rate limit (`src/middleware/rateLimit.js`) and a per-account lockout of 15 minutes after 5 failures (`src/models/users.js`). Plus bcrypt makes each guess slow.

**"Where are secrets kept?"** Only in environment variables (`.env` locally, Render's dashboard in production). `src/config.js` refuses to start in production without them. `.env` is in `.gitignore`.

**"What do the logs contain?"** Method, path, status code and timing, as JSON. Passwords, cookies and session IDs are redacted (`src/utils/logger.js`), and the query string and body are never logged. Security-relevant events go to the **audit log** table instead (`src/utils/audit.js`), which admins can read but the app cannot edit.

**"What are the weaknesses?"** See "Known limits" on the Security page and the Limitations section of `REVIEW.md`. Being able to name them honestly is part of a good defence.

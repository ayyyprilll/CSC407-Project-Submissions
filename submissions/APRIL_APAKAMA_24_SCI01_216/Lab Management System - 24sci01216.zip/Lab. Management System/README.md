# Computer Laboratory Management System

A server-rendered web application for running a university computer lab: students and staff book computers and report faults; administrators approve bookings, review faults, manage computers and users, and read an audit log.

Built for **CSC 407: Building Web Applications, Web Application Security, Testing, Deployment and Review**. Security is the central theme, so each protection is commented in the code, mapped on the in-app **Security** page, and explained in plain language in [EXPLAINED.md](EXPLAINED.md).

| Document | What it is |
|---|---|
| [EXPLAINED.md](EXPLAINED.md) | How password hashing, sessions, parameterized queries, CSRF and CSP work in this code (for your defence) |
| [TESTING.md](TESTING.md) | Automated test summary and the manual test tables to fill in |
| [DEPLOYMENT.md](DEPLOYMENT.md) | Local development to a live Render site, env vars, HTTPS, domain, backups |
| [REVIEW.md](REVIEW.md) | Project review (features, security, results, limitations) |

## Features

**Users:** register, log in, browse computers (search + filter by keyword, status, location), book a computer for a time slot, search/filter and cancel their own bookings, report faulty machines, edit their name, change their password.

**Admins:** manage computers (add, edit, retire), approve or reject bookings, review and update fault reports, change user roles, activate/deactivate users, search the audit log.

**Everyone:** a Security page, responsive layout (left sidebar on desktop, drawer on phones, tables become stacked rows), clean 403/404/429/500 pages.

## Tech stack

Node.js 22+, Express 5, SQLite (`better-sqlite3`), EJS templates, plain CSS and a small amount of vanilla JavaScript. No frontend framework.

| Package | Why it is here |
|---|---|
| `express` | Web framework: routes and middleware |
| `ejs` | Server-side templates. `<%= %>` escapes output, the main XSS defence |
| `better-sqlite3` | SQLite driver with prepared (parameterized) statements |
| `bcrypt` | Password hashing |
| `express-session` + `better-sqlite3-session-store` | Server-side sessions kept in the same SQLite database |
| `helmet` | Security headers and the Content Security Policy |
| `express-rate-limit` | Limits requests per IP (brute-force and spam protection) |
| `csrf-csrf` + `cookie-parser` | CSRF tokens (the library reads its cookie through `cookie-parser`) |
| `express-validator` | Server-side input validation |
| `pino` + `pino-http` | Structured JSON logging with redaction of secrets |
| `dotenv` | Loads `.env` in development |
| `@fontsource/ibm-plex-*` | Source of the IBM Plex font files copied into `public/fonts/` (self-hosted, SIL Open Font License) |
| `jest`, `supertest` (dev only) | Automated tests |

## Quick start

Requires **Node.js 22 or newer**.

```bash
npm install
copy .env.example .env     # macOS/Linux: cp .env.example .env
npm run dev                # http://localhost:3000
```

On first start the app creates the database and seeds it with one admin, three sample users (`amara@`, `tunde@`, `chioma@lab.local`) and 20 computers. Passwords come from `.env` (`ADMIN_PASSWORD`, `SEED_USER_PASSWORD`). **If you leave them empty in development, random passwords are generated and printed once in the terminal**, so copy them from there. Nothing is hardcoded.

| Command | What it does |
|---|---|
| `npm run dev` | Start with auto-restart |
| `npm start` | Start (production) |
| `npm test` | Run all automated tests |
| `npm run seed` | Seed an empty database by hand (also happens automatically at startup) |
| `npm run backup` | Write a consistent database backup to `./backups/` |

## Configuration

All configuration is by environment variable (see [.env.example](.env.example) and [DEPLOYMENT.md](DEPLOYMENT.md)). In production the app **refuses to start** without `SESSION_SECRET` (32+ characters) and `ADMIN_PASSWORD`.

## Project structure

```
src/
  server.js            starts the app; seeds the database; logs crashes
  app.js               builds the Express app and sets the middleware order
  config.js            environment variables, fail-fast checks
  securityFeatures.js  content of the Security page
  db/                  schema.sql, connection.js, seed.js
  middleware/          security (Helmet/CSP), session, csrf, rateLimit, auth (RBAC),
                       validate, flash, errorHandler
  routes/              auth, dashboard, computers, bookings, faults, profile, admin, security, health, pages
  models/              all SQL lives here (parameterized): users, computers, bookings, faults, ...
  validators/          express-validator rules for each form
  utils/               logger, audit, password policy, query helpers, formatting
views/                 EJS templates (partials/, admin/, errors/ ...)
public/                css/app.css, js/ (init.js, app.js), fonts/
scripts/backup.js      database backup
tests/                 Jest + Supertest suites
render.yaml            Render deployment blueprint
```

## Security summary

Each item names where it lives. The in-app **Security** page lists the same with the tests that prove it.

| Protection | Where |
|---|---|
| Password hashing (bcrypt, cost 12) + password policy | `src/routes/auth.js`, `src/utils/password.js` |
| Sessions: HttpOnly / SameSite / Secure cookies, idle + absolute expiry, regenerate on login, destroy on logout | `src/middleware/session.js`, `src/routes/auth.js` |
| Role-based access control middleware, enforced server-side on every protected route | `src/middleware/auth.js`, first line of `src/routes/admin.js` |
| IDOR prevention (queries scoped to the session user) | `src/models/bookings.js`, `src/routes/bookings.js` |
| Server-side validation on every form and query-string filter | `src/validators/`, `src/utils/query.js` |
| SQL injection: parameterized queries only | `src/models/`, `src/db/schema.sql` constraints |
| XSS: output escaping, strict CSP, no inline scripts or styles | `views/`, `src/middleware/security.js` |
| CSRF tokens on all state-changing requests | `src/middleware/csrf.js` |
| Helmet security headers | `src/middleware/security.js` |
| Rate limiting and per-account lockout | `src/middleware/rateLimit.js`, `src/models/users.js` |
| Generic auth errors; no email enumeration | `src/routes/auth.js` |
| No sensitive data in logs (redaction) | `src/utils/logger.js` |
| Audit log | `src/utils/audit.js`, `src/models/auditLogs.js` |
| HTTPS notes, `trust proxy`, Secure cookies, HSTS | `src/app.js`, [DEPLOYMENT.md](DEPLOYMENT.md) |
| Secrets only from environment variables | `src/config.js`, `.gitignore` |

## Testing

```bash
npm test
```

See [TESTING.md](TESTING.md) for what the automated tests cover and the manual test tables to complete.

## Decisions I made where the brief was silent

Where a choice was not specified I picked the safer and simpler option. These are worth knowing for your defence:

| Decision | Reason |
|---|---|
| **bcrypt** rather than argon2 | Installs everywhere without a compiler; well known and easy to explain |
| Sessions stored in the **SQLite database** | One store to understand; survives an app restart; no extra service |
| CSRF via `csrf-csrf` (+ `cookie-parser`) | `csurf` is deprecated; this library is maintained |
| Bookings start as **pending** and need admin approval; the approval re-checks overlaps | Matches "approve or reject bookings"; prevents double-booking |
| A computer's stored status is only **available / maintenance / retired**. "In use" is worked out from approved bookings | The two can never disagree |
| Booking times are entered and shown in **UTC**; 15 minutes to 4 hours, up to 60 days ahead, max 10 pending per user | Avoids time-zone ambiguity; limits abuse |
| Admins cannot use the booking form | Booking is a user function; admins review bookings |
| Another user's booking returns **404**, not 403 | Doesn't reveal that the ID exists |
| Registering an email that already exists shows the **same message** as a new registration | Prevents discovering who has an account (trade-off: a little less friendly) |
| Login failures, lockouts and deactivated accounts all show **one generic message** | Same reason |
| Account locks for 15 minutes after 5 failures (plus an IP rate limit) | Trade-off: someone can lock another person out briefly |
| Self-registration **always** creates a normal user; only an admin can promote | Nobody can register as an admin |
| Admins cannot change their own role or deactivate themselves | Guarantees an admin always exists |
| "Retire" is a soft status change and cancels the machine's future bookings | History is never deleted (foreign keys use `ON DELETE RESTRICT`) |
| Profile edit changes the **name only** (not email); password change requires the current password | Changing the login identity would need email verification |
| **No password reset** and no "redirect back after login" parameter | No email service in scope; avoids open-redirect bugs |
| Free-text fields reject `<` and `>` as well as being escaped on output | A second layer against HTML injection |
| The Security page is **public** | So markers can read it without an account; it exposes no secrets |
| Dynamic pages are sent with `Cache-Control: no-store` | The Back button never shows a logged-out user's data |
| Passwords generated at first start are printed once in the terminal (development only) | No hardcoded defaults, still convenient |
| Node 22+ required | The SQLite library requires it |

## Known limitations

See the Limitations section of [REVIEW.md](REVIEW.md) and the "Known limits" panel on the Security page. In short: the free Render disk is not persistent, rate-limit counters are in memory, there is no email or password reset, and the SQLite design suits one server instance.

## Credits

Fonts: IBM Plex Sans and IBM Plex Mono (SIL Open Font License 1.1), via Fontsource.

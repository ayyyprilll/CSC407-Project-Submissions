# Testing

This project is tested in two ways:

1. **Automated tests** (Jest + Supertest) that run in seconds and check security behaviour on every change.
2. **Manual tests** (tables below) that you run in a real browser and on a phone, to cover what automation cannot: how the app looks, feels and behaves for a person.

> **How to use the manual tables:** the *Test* and *Expected Result* columns are pre-filled. Run each test yourself, then write what really happened in *Actual Result* and set *Status* to `Pass` or `Fail`. Rows still marked `Not run` have not been executed by anyone. Do not mark a row `Pass` unless you ran it.

---

## 1. Automated tests

Run them:

```bash
npm test                  # all tests
npm test -- tests/csrf    # one file
npx jest --coverage       # with a coverage report (written to ./coverage, git-ignored)
```

Every test builds its own throwaway in-memory database, so tests never touch real data and never depend on each other.

### What each file covers

| File | Covers |
|---|---|
| `tests/foundation.test.js` | App boots, health check, 404 page, seed data, basic DB constraints |
| `tests/auth.test.js` | Registration, login, logout, session cookie flags, session ID change on login, lockout, deactivated users, generic errors, role checks, security headers |
| `tests/csrf.test.js` | POST without token, forged token, token from another session, logout CSRF |
| `tests/ratelimit.test.js` | Login and registration rate limits (429) |
| `tests/layout.test.js` | Role-based navigation, dashboards, no inline scripts/styles, static assets |
| `tests/computers.test.js` | Search and filters, pagination, SQL injection and XSS in query strings |
| `tests/bookings.test.js` | Booking validation, overlap rules, own-bookings list, cancel, **IDOR** attempts |
| `tests/faults-profile.test.js` | Fault reports, profile edit, mass assignment, password change, session invalidation |
| `tests/admin.test.js` | Every admin route returns 403 to normal users, all admin functions, self-protection rules, audit log |
| `tests/injection.test.js` | SQL injection and XSS payloads on login, registration, forms, URLs, and second-order (stored) payloads |
| `tests/database.test.js` | Database constraints: UNIQUE, CHECK, FOREIGN KEY, NOT NULL, delete protection |
| `tests/errors.test.js` | 403, 404, 429, 500 pages; no stack traces or paths leak; health check failure |
| `tests/audit.test.js` | Log redaction (cookies, passwords, session IDs), error pages leak nothing |
| `tests/production.test.js` | Production mode: refuses to start without secrets, HSTS, Secure cookies, trust proxy, admin seeded from env |
| `tests/backup.test.js` | Backup produces a valid copy and prunes old ones |

### Latest automated result

<!-- Updated at the end of the build; re-run `npm test` and `npx jest --coverage` and update if you change the code. -->

| Item | Result |
|---|---|
| Date run | 2026-10-11 |
| Command | `npx jest --runInBand --coverage` |
| Test suites | 15 passed, 15 total |
| Tests | **302 passed, 302 total** (about 18 seconds) |
| Coverage of `src/` | Statements 93.9%, Branches 83.3%, Functions 94.6%, Lines 96.3% |
| Not covered by automated tests | `src/server.js` (the process entry point: listen, signal handlers) and the real-browser behaviour of the mobile menu script. Both are covered by the manual tests. |

### Security behaviours proven by automated tests

| Requirement from the brief | Where it is proven |
|---|---|
| Registration, login, logout | `auth.test.js` |
| Form validation | `auth.test.js`, `bookings.test.js`, `faults-profile.test.js`, `admin.test.js` |
| Access control (user gets 403 on admin routes) | `admin.test.js` (every admin route, GET and POST) |
| IDOR | `bookings.test.js` ("IDOR" tests), `faults-profile.test.js` |
| SQL injection | `injection.test.js`, `computers.test.js`, `database.test.js` |
| XSS | `injection.test.js`, `layout.test.js`, plus escaping checks in each page's tests |
| CSRF rejection | `csrf.test.js` and a "no token" test on each state-changing form |
| Rate limiting | `ratelimit.test.js` |
| Database constraints | `database.test.js`, `foundation.test.js` |
| Error handling | `errors.test.js`, `audit.test.js` |

---

## 2. Manual test environment

Fill this in before you start so your results can be reproduced.

| Item | Value |
|---|---|
| Tester | _your name_ |
| Date(s) tested | _fill in_ |
| App version / git commit | _run `git rev-parse --short HEAD`_ |
| Environment tested | _local (`npm start`) / Render URL_ |
| Desktop browser(s) and version | _e.g. Chrome 130, Firefox 131_ |
| Phone(s) and browser(s) | _e.g. Pixel 7 / Chrome, iPhone 13 / Safari_ |
| Seed accounts | admin: `ADMIN_EMAIL` / password from your `.env` (or printed once on first start). Users: `amara@lab.local`, `tunde@lab.local`, `chioma@lab.local` with `SEED_USER_PASSWORD` |

---

## 3. Manual test tables

### 3.1 Registration and login

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **R-01** Register with a valid name, new email and strong password | Redirect to login with a confirmation message; the new account can log in | | Not run |
| **R-02** Register with a password of 6 characters | Form re-shown with "at least 10 characters"; no account created | | Not run |
| **R-03** Register with a password with no number | Error about needing a letter and a number | | Not run |
| **R-04** Register with mismatched password confirmation | "Passwords do not match" | | Not run |
| **R-05** Register with an invalid email (`abc`) | "Enter a valid email address" | | Not run |
| **R-06** Register with `<script>alert(1)</script>` as the name | Rejected; nothing executes; the text is not shown unescaped | | Not run |
| **R-07** Register with an email that already exists | Same confirmation message as a new registration (the page does not reveal the email exists); still only one account | | Not run |
| **R-08** Submit the registration form with every field empty | Clear error messages; no crash | | Not run |
| **L-01** Log in as a user with the correct password | Lands on the user dashboard; sidebar shows user links only | | Not run |
| **L-02** Log in as the admin with the correct password | Lands on the admin dashboard; sidebar shows the Administration section | | Not run |
| **L-03** Log in with a wrong password | Generic "Invalid email or password" message | | Not run |
| **L-04** Log in with an email that does not exist | The exact same generic message as L-03 | | Not run |
| **L-05** Enter a wrong password 5 times for one account, then the correct one | Still refused (account locked for 15 minutes); same generic message | | Not run |
| **L-06** After L-05, check the admin audit log | Entries for `login failed` x5 and `account locked` | | Not run |
| **L-07** Log in, then open `/login` directly | Redirected to the dashboard (already logged in) | | Not run |

### 3.2 Sessions and logout

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **S-01** Click Log out | Returned to home page, logged out | | Not run |
| **S-02** After S-01, press the browser Back button | Protected page is not shown from cache; you are sent to login | | Not run |
| **S-03** After S-01, open `/dashboard` directly | Redirected to `/login` | | Not run |
| **S-04** Dev tools > Application > Cookies after login | `lab.sid` cookie is HttpOnly and SameSite=Lax (and Secure on the HTTPS site) | | Not run |
| **S-05** In the console run `document.cookie` | The session cookie is NOT listed (HttpOnly) | | Not run |
| **S-06** Note the `lab.sid` value on the login page, log in, compare | The value changed after login (session regeneration) | | Not run |
| **S-07** Log in on two browsers, change the password in one | The other browser is logged out on its next click | | Not run |
| **S-08** Stay idle for 30 minutes, then click a link | Sent to login (idle timeout). _Tip: temporarily lower `IDLE_TIMEOUT_MS` in `src/middleware/session.js` to test quickly, then restore it._ | | Not run |
| **S-09** Admin deactivates a user who is logged in | That user is logged out on their next click and cannot log in again | | Not run |

### 3.3 Access control (roles)

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **A-01** Logged out, open `/admin/users` | Redirected to login | | Not run |
| **A-02** Logged in as a normal user, open `/admin/users` | 403 "Access denied" page | | Not run |
| **A-03** As a normal user, open `/admin/audit`, `/admin/computers`, `/admin/bookings`, `/admin/faults` | Each shows 403 | | Not run |
| **A-04** As a normal user, check the sidebar | No Administration section is shown | | Not run |
| **A-05** As an admin, open `/bookings/new` | 403 (booking is a user function) | | Not run |
| **A-06** Admin changes a user to admin; that user clicks any page | Their sidebar and access update immediately without logging in again | | Not run |
| **A-07** Admin tries to change their own role | Refused with a message; role unchanged | | Not run |
| **A-08** Admin tries to deactivate themselves | Refused with a message | | Not run |

### 3.4 IDOR (changing IDs in the URL)

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **I-01** As user A, create a booking and note its ID. As user B, craft a cancel request for that ID (see note below) | 404; user A's booking is unchanged | | Not run |
| **I-02** As a user, request `/bookings/999999/cancel` (does not exist) | 404, identical to I-01 (IDs cannot be probed) | | Not run |
| **I-03** As a user, open `/profile?id=1` or `/profile/1` | Still shows only your own profile / 404 | | Not run |
| **I-04** As user A, open the bookings list and search for text from user B's booking purpose | Nothing from user B appears | | Not run |

> Note for I-01: cancel is a POST with a CSRF token, so you cannot do it by typing a URL. Use browser dev tools to edit the form's `action` (for example change `/bookings/5/cancel` to the other user's booking ID) and submit. The automated test `bookings.test.js` does the same thing.

### 3.5 Input validation

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **V-01** Book a computer with a start time in the past | "The start time must be in the future" | | Not run |
| **V-02** Book with end before start | "The end time must be after the start time" | | Not run |
| **V-03** Book for 6 hours | "A booking can be at most 4 hours" | | Not run |
| **V-04** Book a time that overlaps an approved booking on the same computer | "Already booked" message | | Not run |
| **V-05** Book while you already have an overlapping booking | "You already have a booking that overlaps" | | Not run |
| **V-06** Leave the booking purpose empty | Validation error | | Not run |
| **V-07** Report a fault with a 5000-character description | Rejected (limit is 1000) | | Not run |
| **V-08** In dev tools, remove the `required` attribute from a field and submit empty | Server still rejects it (validation is server-side) | | Not run |
| **V-09** Admin adds a computer with a duplicate asset tag | "Another computer already uses that asset tag" | | Not run |
| **V-10** Change a form `<select>` value to something not offered (dev tools) and submit | Rejected; nothing saved | | Not run |

### 3.6 SQL injection (manual payloads)

Try each payload in: the login email and password, the computers search box, the bookings search box, and the admin user search.

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **Q-01** `' OR '1'='1` in the login email | Generic login error; not logged in | | Not run |
| **Q-02** `admin@lab.local'--` in the login email | Generic login error | | Not run |
| **Q-03** `' OR 1=1 --` in the login password (real email) | Generic login error | | Not run |
| **Q-04** `'; DROP TABLE users; --` in the computers search | No results; the app keeps working; users table intact | | Not run |
| **Q-05** `' UNION SELECT password_hash FROM users --` in any search | No hashes shown; no results | | Not run |
| **Q-06** `%` and `_` in the computers search | Treated as ordinary characters (no results), not as wildcards | | Not run |

### 3.7 Cross-site scripting (XSS)

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **X-01** Search the computers list for `"><script>alert(1)</script>` | No alert box; the text is shown harmlessly in the search box | | Not run |
| **X-02** Submit a booking purpose of `<img src=x onerror=alert(1)>` | Rejected (angle brackets not allowed) | | Not run |
| **X-03** Dev tools > Console on any page | No Content-Security-Policy violations during normal use | | Not run |
| **X-04** In the console, run `document.body.appendChild(Object.assign(document.createElement('script'),{textContent:'alert(1)'}))` | Blocked by CSP; a violation is logged; no alert | | Not run |
| **X-05** View page source on several pages | No inline `<script>` blocks, no `onclick=` attributes, no `style=` attributes | | Not run |

### 3.8 CSRF

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **C-01** In dev tools, delete the hidden `_csrf` input from the booking form and submit | 403 "Form expired" page; no booking created | | Not run |
| **C-02** Save the login page as a local HTML file, change its form `action` to the live URL, open the file and submit | 403 (token missing or invalid) | | Not run |
| **C-03** Log in, then open a second tab with a hand-made form that POSTs to `/logout` without a token | 403; you stay logged in | | Not run |
| **C-04** Leave a form open for a long time (or after logging out in another tab), then submit | 403 "Form expired"; reloading the page and retrying works | | Not run |

### 3.9 Rate limiting and lockout

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **RL-01** Submit 21 login attempts quickly from one machine | After the limit, a "Too many requests" page (429) | | Not run |
| **RL-02** After RL-01, check the response headers (dev tools > Network) | `RateLimit-*` headers are present | | Not run |
| **RL-03** Submit 11 registrations from one machine within an hour | The 11th gets a 429 page | | Not run |

### 3.10 Booking workflow (end to end)

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **B-01** As a user, click Book on an available computer | Booking form opens with that computer selected | | Not run |
| **B-02** Submit a valid booking | Appears in My bookings as `pending`; dashboard "Awaiting approval" count rises | | Not run |
| **B-03** As admin, open Bookings, filter `pending`, approve it | Status becomes `approved`; audit log has `booking approved` | | Not run |
| **B-04** Create two overlapping pending requests for one computer; approve both | The second approval is refused with an overlap message | | Not run |
| **B-05** As admin, reject a booking | Status `rejected`; the user sees it in My bookings | | Not run |
| **B-06** As the user, cancel an approved future booking | Confirmation prompt, then status `cancelled` | | Not run |
| **B-07** Search My bookings by part of a computer name or purpose, and by status | Only matching rows are shown; reset clears the filter | | Not run |
| **B-08** Admin retires a computer that has future bookings | Computer shows `retired`; those bookings become `cancelled`; it can no longer be booked | | Not run |
| **B-09** Computer with a currently-running approved booking | Shows `in use` on the computers list | | Not run |

### 3.11 Admin workflow

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **AD-01** Add a computer | Appears in the list; audit log has `computer created` | | Not run |
| **AD-02** Edit a computer's location and status | Changes saved and shown | | Not run |
| **AD-03** Filter computers by status and by location, and search by keyword | Results match the filters | | Not run |
| **AD-04** As a user, report a fault; as admin, set it to investigating, then resolved | Status updates; the list orders unresolved/severe first | | Not run |
| **AD-05** Change a user's role and deactivate/activate a user | Changes apply; both are in the audit log | | Not run |
| **AD-06** Open the audit log and filter by action | Only that action's entries are shown; newest first | | Not run |
| **AD-07** Change your password on the Profile page | Success message; old password no longer works; new one does | | Not run |
| **AD-08** Open the Security page | Lists each protection with file locations; the paths exist in the project | | Not run |

### 3.12 Error handling

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **E-01** Open `/this-page-does-not-exist` | Clean 404 page with a link back; no technical details | | Not run |
| **E-02** Normal user opens an admin URL | Clean 403 page | | Not run |
| **E-03** Open `/computers?page=abc&status=zzz&q[]=x` | Page loads normally; bad values ignored | | Not run |
| **E-04** Open `/bookings/abc/cancel` by typing it in the address bar | 404 (cancel is POST-only), no stack trace | | Not run |
| **E-05** Open `/health` | `{"status":"ok"}` | | Not run |
| **E-06** Temporarily add `throw new Error('test failure');` as the first line of the handler in `src/routes/computers.js`, restart, open `/computers` | Generic "Something went wrong" page with no technical detail; the real error (with stack trace) appears only in the terminal / server log. _Remove the line afterwards._ | | Not run |
| **E-07** Search the server log for a password you typed during the tests | Not found anywhere (passwords are never logged) | | Not run |
| **E-08** Submit a very large form body (over 10 KB) | Rejected with an error, not a crash | | Not run |

### 3.13 Security headers and HTTPS (run against the deployed HTTPS site)

Use `curl -I https://YOUR-APP-URL/login` or dev tools > Network > Headers.

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **H-01** `Content-Security-Policy` header | Present; `script-src 'self'`; no `unsafe-inline` | | Not run |
| **H-02** `Strict-Transport-Security` header | Present (max-age at least 15552000) | | Not run |
| **H-03** `X-Content-Type-Options: nosniff`, `X-Frame-Options` / `frame-ancestors 'none'`, `Referrer-Policy` | Present | | Not run |
| **H-04** `X-Powered-By` header | Absent | | Not run |
| **H-05** Open `http://YOUR-APP-URL` (not https) | Redirects to HTTPS | | Not run |
| **H-06** `Set-Cookie` on the login page | Session cookie has `Secure; HttpOnly; SameSite=Lax`; CSRF cookie has the `__Host-` prefix | | Not run |
| **H-07** Optional: scan the URL with an online header checker | Record the grade and screenshot it | | Not run |

---

## 4. Usability testing

Ask 3-5 people who did not build the app to complete these tasks without help. Time them and note where they hesitate.

| Task | Expected Result | Actual Result | Status |
|---|---|---|---|
| **U-01** "Create an account and log in" | Completed without help in under 2 minutes | | Not run |
| **U-02** "Find a free computer in Lab B and book it for tomorrow afternoon" | Completed without help | | Not run |
| **U-03** "You booked the wrong time. Cancel it." | Finds My bookings and cancels | | Not run |
| **U-04** "A computer's screen is broken. Report it." | Finds Report a fault, submits | | Not run |
| **U-05** "Change your password" | Finds Profile, completes | | Not run |
| **U-06** (admin) "Approve the pending booking from Amara" | Finds Bookings, filters pending, approves | | Not run |
| **U-07** (admin) "Find who deactivated Tunde's account" | Uses the audit log | | Not run |

Observations to record (add rows or paragraphs):

- Participants (role / experience, no names needed): _fill in_
- Where people got stuck or hesitated: _fill in_
- Error messages that were unclear: _fill in_
- Changes made because of this feedback: _fill in_

**Accessibility spot checks**

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **AC-01** Use only the keyboard (Tab / Shift+Tab / Enter) to log in and book a computer | Every control reachable; visible teal focus outline on each | | Not run |
| **AC-02** Press Tab once on a fresh page | "Skip to main content" link appears first | | Not run |
| **AC-03** Zoom the browser to 200% | No content is cut off or overlapping | | Not run |
| **AC-04** Check status badges (available, pending, retired...) | Each has a text label, not just a colour | | Not run |
| **AC-05** Optional: run Lighthouse accessibility audit | Record the score and screenshot it | | Not run |

---

## 5. Mobile and responsive testing

Test on a real phone if you can, and with the browser's device toolbar (F12 > device icon) at the widths below. Save screenshots in `docs/screenshots/` and link them in the last column.

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **M-01** 375 px wide: open the home page | Content readable; no horizontal page scroll | | Not run |
| **M-02** 375 px wide: log in | Menu button (top right) appears; sidebar hidden | | Not run |
| **M-03** 375 px wide: tap the menu button | Sidebar slides in over the page; tapping outside or pressing Esc closes it | | Not run |
| **M-04** 375 px wide: open Computers | Table shows as stacked rows, each value labelled; filters stack vertically | | Not run |
| **M-05** 375 px wide: open Book a computer | Form fields full width; date pickers usable | | Not run |
| **M-06** 375 px wide: open Admin > Users | Rows readable; role selector and buttons reachable | | Not run |
| **M-07** 768 px wide (tablet) | Layout is sensible; nothing overlaps | | Not run |
| **M-08** 1280 px wide (desktop) | Left sidebar visible; tables use full width | | Not run |
| **M-09** Rotate a phone to landscape | Still usable | | Not run |
| **M-10** Disable JavaScript and load a page at 375 px | Sidebar appears stacked above the content (no broken menu) | | Not run |

Screenshots (replace the placeholders with your own files):

| View | Screenshot |
|---|---|
| Home, mobile | `docs/screenshots/mobile-home.png` _(add)_ |
| Dashboard, mobile, menu closed | `docs/screenshots/mobile-dashboard.png` _(add)_ |
| Dashboard, mobile, menu open | `docs/screenshots/mobile-menu-open.png` _(add)_ |
| Computers list, mobile | `docs/screenshots/mobile-computers.png` _(add)_ |
| Admin users, mobile | `docs/screenshots/mobile-admin-users.png` _(add)_ |
| Dashboard, desktop | `docs/screenshots/desktop-dashboard.png` _(add)_ |
| Real phone photo (device name) | `docs/screenshots/real-device.jpg` _(add)_ |

---

## 6. Performance observations

Record what you actually measure (for example with the browser's Network tab or Lighthouse). Leave a cell blank if you did not measure it.

| Measurement | Value | How measured |
|---|---|---|
| Home page load time (local) | | |
| Dashboard load time (local) | | |
| Computers list with 20 rows (local) | | |
| Time to first response after the Render free instance has been idle | | |
| Lighthouse performance score (mobile) | | |
| Total transferred size of the dashboard page | | |
| Time for one login (bcrypt cost 12) | | |

---

## 7. Post-deployment checks

| Test | Expected Result | Actual Result | Status |
|---|---|---|---|
| **D-01** Open the Render URL | Home page loads over HTTPS (padlock) | | Not run |
| **D-02** `/health` on the live site | `{"status":"ok"}` | | Not run |
| **D-03** Log in as the admin with the password you set in Render | Works; admin dashboard shows 20 computers | | Not run |
| **D-04** Render dashboard > Logs after using the site | JSON log lines for requests; no passwords or cookies in them | | Not run |
| **D-05** Trigger a restart / redeploy | App comes back; data is re-seeded if the disk was reset | | Not run |
| **D-06** Run `npm run backup` locally against a copy of the database | A file appears in `backups/` and opens in a SQLite viewer | | Not run |
| **D-07** If using a custom domain: open it over HTTPS | Valid certificate; HTTP redirects to HTTPS | | Not run |

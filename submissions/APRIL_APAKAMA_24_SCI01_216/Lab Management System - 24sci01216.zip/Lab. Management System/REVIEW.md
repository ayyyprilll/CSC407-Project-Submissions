# Project Review

**Project:** Computer Laboratory Management System
**Course:** CSC 407: Building Web Applications, Web Application Security, Testing, Deployment and Review
**Author:** _your name and matric number_
**Date:** _fill in_
**Live URL:** _paste your Render URL_ · **Repository:** _paste your GitHub URL_

> **How to use this document.** Sections marked *(measured)* contain results that were produced while building the project. Sections marked **[YOUR INPUT]** need real results or experiences that only you can supply. They are left as honest placeholders. Delete the hint text once you fill them in, and edit the "Problems encountered" section so it reflects *your* experience.

---

## 1. What the application does

The Computer Laboratory Management System lets a university computer lab run its booking and maintenance process online.

- **Lab users** (students or staff) register, log in, look through the lab's computers, request a time slot on an available machine, track and cancel their own bookings, report faulty machines, and manage their own profile and password.
- **Administrators** keep the computer inventory up to date (add, edit, retire), approve or reject booking requests, work through fault reports, manage user accounts (change role, deactivate) and read an audit log of important actions.

It is a server-rendered web application (Node.js, Express, SQLite, EJS) with a black-and-teal "operations console" interface that works on phones and desktops. Security is the central design concern, so each protection is implemented, commented in the code, explained in `EXPLAINED.md` and listed on the in-app Security page.

## 2. Features implemented

| Area | Implemented |
|---|---|
| Accounts | Registration, login, logout, profile edit (name), change password |
| Roles | Admin and User; navigation and dashboards differ by role; enforced on the server |
| Computers | List with keyword, status and location filters and pagination; admin add / edit / retire |
| Bookings | Request a slot; pending → approved / rejected by admin; overlap checks; user search, filter and cancel; admin review queue |
| Faults | Users report faults with severity; admins review and set open / investigating / resolved |
| Users (admin) | Search, change role, activate / deactivate (deactivation ends sessions at once) |
| Audit log | Logins, failed logins, lockouts, registrations, password changes, bookings and decisions, role changes, computer changes; searchable and filterable |
| Security page | Every protection with its code location and test file |
| Errors | Clean 400 / 403 / 404 / 429 / 500 pages |
| UI | Left sidebar, drawer menu on phones, stacked table rows on phones, status badges with text labels, visible keyboard focus, skip link |
| Operations | Health check, structured JSON logging, database backup script, self-seeding on first start, Render blueprint |
| Documentation | README, TESTING, DEPLOYMENT, EXPLAINED, this review |

## 3. Security measures

| Threat | Measure | Where |
|---|---|---|
| Stolen database leaks passwords | bcrypt (cost 12, per-password salt); never stored in plain text | `src/routes/auth.js`, `src/utils/password.js` |
| Weak passwords | Policy: 10+ characters, a letter and a number, max 72 bytes | `src/utils/password.js` |
| Session theft / fixation | Server-side sessions; HttpOnly, SameSite=Lax, Secure (production); idle (30 min) and absolute (8 h) expiry; new ID at login; full destruction at logout; other sessions ended on password change | `src/middleware/session.js`, `src/routes/auth.js`, `src/routes/profile.js` |
| Unauthorized access | `requireLogin` / `requireRole` middleware on the server; one `requireRole('admin')` guards the whole admin router | `src/middleware/auth.js`, `src/routes/admin.js` |
| IDOR | Queries scoped to the session user's id; other users' records look like "not found"; no user id in profile URLs | `src/models/bookings.js`, `src/routes/*.js` |
| Mass assignment | Routes read only named fields; role/user_id/status in requests are ignored | `src/routes/profile.js`, `bookings.js`, `auth.js` |
| Invalid / malicious input | Server-side validation of every form and every query-string filter (type, length, allow-lists) | `src/validators/`, `src/utils/query.js` |
| SQL injection | Parameterized queries everywhere; LIKE wildcards escaped; ids must be digits; DB constraints as a backstop | `src/models/`, `src/db/schema.sql` |
| XSS | Escaped output; free text rejects `<` `>`; strict CSP; no inline scripts, handlers or styles | `views/`, `src/validators/common.js`, `src/middleware/security.js` |
| CSRF | Per-session token in every form, checked on every state-changing request; SameSite cookies; logout is POST | `src/middleware/csrf.js` |
| Clickjacking, MIME sniffing, etc. | Helmet headers; CSP `frame-ancestors 'none'`; `nosniff`; HSTS in production | `src/middleware/security.js` |
| Brute force | IP rate limits on login/registration; 15-minute lockout after 5 failures per account | `src/middleware/rateLimit.js`, `src/models/users.js` |
| Account enumeration | One generic login message; dummy bcrypt comparison for unknown emails; identical response for duplicate registration | `src/routes/auth.js` |
| Information leakage | Generic error pages; stack traces only in server logs | `src/middleware/errorHandler.js` |
| Secrets in logs | Redaction of cookies, auth headers, passwords, session IDs; no bodies or query strings in request logs | `src/utils/logger.js`, `src/app.js` |
| Repudiation | Audit log of important actions with user, time and IP; no edit/delete path in the app | `src/utils/audit.js` |
| Leaked secrets in code | All secrets from environment variables; app refuses to start in production without them; `.env` git-ignored | `src/config.js`, `.gitignore` |
| Transport security | HTTPS via Render; `trust proxy`; Secure cookies; HSTS; `upgrade-insecure-requests` | `src/app.js`, `DEPLOYMENT.md` |
| Oversized requests | 10 KB body limit; general rate limit | `src/app.js` |
| Stale pages after logout | `Cache-Control: no-store` on dynamic pages | `src/app.js` |

## 4. Testing results

### Automated tests *(measured, 2026-10-11)*

- **302 tests in 15 suites, all passing**, in about 18 seconds.
- Coverage of `src/`: **96.3% of lines**, 93.9% of statements, 94.6% of functions, 83.3% of branches.
- Covered: registration, login, logout, session behaviour, form validation, access control on every admin route (GET and POST), IDOR attempts, SQL injection and XSS payloads on every entry point (including stored payloads read back later), CSRF rejection, rate limiting, lockout, database constraints, error pages, log redaction, production configuration (Secure cookies, HSTS, trust proxy, fail-fast startup) and the backup script.
- Not covered by automation: `src/server.js` (process entry) and how the pages look and feel in real browsers.

Details: `TESTING.md` section 1.

### Manual tests **[YOUR INPUT]**

Complete the tables in `TESTING.md` sections 3 to 7 and summarise here:

| Group | Tests run | Passed | Failed | Notes |
|---|---|---|---|---|
| Registration and login | | | | |
| Sessions and logout | | | | |
| Access control and IDOR | | | | |
| Validation, SQL injection, XSS, CSRF | | | | |
| Rate limiting and lockout | | | | |
| Booking and admin workflows | | | | |
| Error handling | | | | |
| Security headers and HTTPS (live site) | | | | |
| Post-deployment | | | | |

**Defects found during manual testing and how they were fixed:** _fill in_

### Usability and mobile testing **[YOUR INPUT]**

- Who tested, how many people, which tasks: _fill in (see TESTING.md section 4)_
- Task completion and where people struggled: _fill in_
- Devices and browsers used for responsive testing: _fill in (see TESTING.md section 5)_
- Screenshots: `docs/screenshots/` _(add and reference them)_
- Changes made as a result: _fill in_

## 5. Performance observations **[YOUR INPUT]**

Nothing was benchmarked while building, so there are no measured numbers here. Record what you measure in `TESTING.md` section 6 and summarise it here. Things worth commenting on once you have data:

- Page load times locally and on Render.
- The delay on the first request after the free Render instance has been idle.
- The cost of bcrypt on login (this is intentional).
- Page weight: there is no JavaScript framework; the stylesheet is one file, there are two tiny scripts, and fonts are five small WOFF2 files.

Design choices that should help performance, to confirm or refute with your measurements: server-rendered pages with no client-side rendering; SQLite in the same process (no network hop to a database); indexed foreign keys; pagination of every list; static files cached for a day in production.

## 6. Problems encountered

> **[YOUR INPUT]** This section lists real technical problems that came up while this code was built, so you have an accurate starting point. Edit it to reflect your own experience, and add problems you hit while testing and deploying.

| Problem | Cause | Resolution |
|---|---|---|
| The test runner never exited | The session-store library starts a cleanup timer that is never released | The timer is created with `unref()` in `src/middleware/session.js` so it no longer keeps the process alive |
| CSRF tokens failed for visitors who were not logged in | Tokens are bound to the session ID, but a session was not saved until something was stored in it | `exposeCsrfToken` in `src/middleware/csrf.js` marks the session as used so the cookie is issued on the first page |
| Production-mode tests could not log in | The HTTP test client correctly refuses to send `Secure` cookies over plain HTTP | The test replays the cookies by hand, simulating an HTTPS proxy (`tests/production.test.js`) |
| Free-text validation test data failed unexpectedly | The database `CHECK` constraint (purpose of at least 3 characters) correctly rejected one-letter test values | Test data fixed; the failure showed the constraint working as a second line of defence |
| `bcrypt` truncates passwords after 72 bytes | A bcrypt design limit | Maximum of 72 bytes enforced in the password policy |
| Choosing the order of middleware | CSRF needs the session; sessions need cookies; limits should run first | Order documented in `src/app.js` |
| _Add your own: deployment, DNS, Render free-plan behaviour, browser quirks, etc._ | | |

## 7. Limitations

Be ready to discuss these honestly.

1. **Free-plan data loss.** Render's free disk is ephemeral. The app re-seeds the admin and computers on start, but users, bookings and logs created later are lost on restart. A persistent disk or hosted database fixes this.
2. **SQLite and scaling.** SQLite in the same process suits one server instance. It cannot be shared by several instances behind a load balancer.
3. **In-memory rate limiting.** Rate-limit counters reset when the server restarts and are not shared between instances.
4. **No password reset or email verification.** A user who forgets their password cannot recover the account in the app, and emails are not verified. There is no email service.
5. **Account lockout can be abused.** Someone who knows an email address can lock that account for 15 minutes by guessing wrongly (an accepted trade-off against password guessing).
6. **No multi-factor authentication.**
7. **Times are UTC only.** There is no per-user time-zone support.
8. **Profile editing is limited** to the display name; the email cannot be changed.
9. **Duplicate-registration response** is intentionally vague, which is slightly less friendly for genuine users.
10. **No malware scanning or file uploads** exist; if uploads were added later they would need their own controls.
11. **Audit log is append-only by convention**: the application has no code to change it, but someone with direct database access could. Real tamper-resistance would ship logs to an external service.
12. **Dependencies** must be kept updated (`npm audit`); this project pins them through `package-lock.json` but does not automate updates.
13. **Automated tests do not drive a real browser**, so the mobile menu script and visual layout rely on the manual tests.

## 8. Future improvements

- Persistent storage (Render disk or PostgreSQL) and scheduled off-site backups.
- Email-based password reset and email verification.
- Optional two-factor authentication for administrators.
- Shared rate-limit store (e.g. Redis) for multiple instances.
- Per-user time zones and a calendar view of bookings.
- Notifications (email) when a booking is approved or rejected.
- Admin tools: unlock an account, export reports (CSV), bulk import of computers.
- Fault reports linked to computer status (auto-set maintenance on high severity).
- Browser-level end-to-end tests (Playwright) for the visual and mobile behaviour.
- Dependency and secret scanning in CI (`npm audit`, GitHub Dependabot), and a CI workflow that runs the tests on every push.
- Log shipping and alerts on repeated failed logins.

## 9. Conclusion **[YOUR INPUT]**

_Write a short personal reflection: what you learned, what was hardest, what you would do differently, and whether the application meets its goals._

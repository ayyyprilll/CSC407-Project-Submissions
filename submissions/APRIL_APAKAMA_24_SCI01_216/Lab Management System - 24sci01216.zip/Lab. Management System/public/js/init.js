// Loaded in <head>. Marks the page as "JavaScript available" so the CSS can switch the sidebar
// into a drawer on small screens. Without JavaScript the sidebar just stacks above the content.
document.documentElement.classList.add('js');

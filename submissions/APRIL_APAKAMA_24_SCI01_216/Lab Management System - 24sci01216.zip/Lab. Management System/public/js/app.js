// Small amount of vanilla JavaScript. This file is served from our own origin, which is what the
// Content Security Policy allows (no inline scripts, no event-handler attributes).
(function () {
  'use strict';

  var body = document.body;
  var toggle = document.querySelector('[data-nav-toggle]');
  var sidebar = document.getElementById('sidebar');

  function setOpen(open) {
    body.classList.toggle('nav-open', open);
    if (toggle) toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  if (toggle && sidebar) {
    toggle.addEventListener('click', function () {
      setOpen(!body.classList.contains('nav-open'));
    });
    // Tapping the dark area, or pressing Escape, closes the drawer.
    var scrim = document.querySelector('[data-nav-close]');
    if (scrim) scrim.addEventListener('click', function () { setOpen(false); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { setOpen(false); toggle.focus(); }
    });
  }

  // Ask for confirmation before destructive actions: <form data-confirm="Cancel this booking?">
  document.addEventListener('submit', function (e) {
    var msg = e.target.getAttribute && e.target.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) e.preventDefault();
  });
})();

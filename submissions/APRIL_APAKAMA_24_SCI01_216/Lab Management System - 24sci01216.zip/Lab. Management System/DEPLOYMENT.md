# Deployment guide

From your laptop to a live HTTPS website on **Render**, deploying from **GitHub**.

> Render's dashboard and free-plan rules change from time to time. The steps below describe the usual flow; if a screen looks different, follow the same idea and check Render's documentation (render.com/docs).

---

## 1. The path at a glance

```
Local development  ->  GitHub repository  ->  Render builds and starts it  ->  Live HTTPS URL
 (npm run dev)         (git push)             (npm ci, npm start)             (+ optional domain)
```

---

## 2. Local development

Requirements: **Node.js 22 or newer** (the SQLite library needs it) and Git.

```bash
npm install
copy .env.example .env        # macOS/Linux: cp .env.example .env
npm run dev                   # restarts automatically on file changes
```

Open http://localhost:3000.

On the first start the database is empty, so the app **seeds itself**: one admin, three sample users and 20 computers. In development, any password you did not set in `.env` is generated randomly and **printed once in the terminal**. Copy it then. To start over, stop the app and delete the `data/` folder.

Run the tests before every push:

```bash
npm test
```

---

## 3. Put the code on GitHub

1. Create an empty repository on GitHub (no README, no .gitignore: the project already has them).
2. Check that no secrets are about to be committed:
   ```bash
   git status            # .env and data/ must NOT appear (they are in .gitignore)
   ```
3. Connect and push:
   ```bash
   git remote add origin https://github.com/YOUR-USER/YOUR-REPO.git
   git push -u origin main
   ```

Never commit `.env`, database files or backups. If you ever do by accident, treat every secret in it as compromised and change it.

---

## 4. Deploy on Render

### Option A: Blueprint (uses `render.yaml`)

1. Render dashboard > **New > Blueprint** > connect your GitHub account > choose the repository.
2. Render reads `render.yaml` and shows the service it will create. It will ask you for the values marked `sync: false`: **`ADMIN_PASSWORD`** (and optionally **`SEED_USER_PASSWORD`**). Type them here, in the dashboard. They are never stored in git.
3. Click **Apply**. Render installs dependencies, builds, starts the app, and checks `/health`.

### Option B: manual web service

Render dashboard > **New > Web Service** > connect the repo, then:

| Setting | Value |
|---|---|
| Runtime | Node |
| Build command | `npm ci --omit=dev` |
| Start command | `npm start` |
| Health check path | `/health` |
| Instance type | Free (see section 8 for what that means for your data) |

Then add the environment variables from the table in section 5.

### After the first deploy

- Open the `https://....onrender.com` URL Render gives you.
- `/health` should return `{"status":"ok"}`.
- Log in with `ADMIN_EMAIL` and the `ADMIN_PASSWORD` you entered.
- Every later `git push` to the connected branch redeploys automatically (`autoDeploy: true`).

---

## 5. Environment variables

Set these in Render: your service > **Environment**.

| Variable | Required in production | Purpose | Notes |
|---|---|---|---|
| `NODE_ENV` | yes (`production`) | Turns on production behaviour (see section 7) | |
| `NODE_VERSION` | yes (`22`) | Tells Render which Node to use | The SQLite library needs 22+ |
| `SESSION_SECRET` | **yes**, 32+ chars | Signs session cookies and CSRF tokens | `render.yaml` makes Render generate it. The app refuses to start without it. Changing it logs everyone out. |
| `ADMIN_PASSWORD` | **yes** | Password of the first admin, created when the database is empty | At least 10 chars with a letter and number. The app refuses to start without it. |
| `ADMIN_EMAIL` | recommended | Email of the first admin | Defaults to `admin@lab.local` |
| `ADMIN_NAME` | no | Display name of the first admin | |
| `SEED_USER_PASSWORD` | no | If set, 3 sample users are created with this shared password | Leave unset for a real deployment with no demo accounts. |
| `DB_PATH` | no | Where the SQLite file lives | Default `./data/lab.db`. With a paid persistent disk use the disk path, e.g. `/var/data/lab.db`. |
| `PORT` | no | Port to listen on | Render sets it for you |
| `LOG_LEVEL` | no | `info` by default in production | `debug` for troubleshooting |

Locally these live in `.env` (see `.env.example`).

Generate a strong secret yourself if needed:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

---

## 6. HTTPS and domain

### HTTPS

Render terminates HTTPS for you and provides a free, auto-renewing TLS certificate for the `onrender.com` address and for custom domains. Plain `http://` requests are redirected to `https://`.

Because Render's proxy sits between the browser and the app, the app is configured for it:

- **`trust proxy`** (`src/app.js`, set to 1 in production). Without it, Express would think every request arrived over plain HTTP and would never send `Secure` cookies, and every visitor would appear to have the proxy's IP address (so rate limiting would block everyone together and the audit log would record useless IPs).
- **Secure cookies** (`src/middleware/session.js`, `src/middleware/csrf.js`): sent only over HTTPS in production.
- **HSTS** (`src/middleware/security.js`): tells browsers to always use HTTPS for this site (`max-age` 180 days).
- **`upgrade-insecure-requests`** in the CSP: the browser upgrades any accidental `http://` sub-resource to HTTPS.

If you deploy somewhere other than Render, make sure your host/proxy sets `X-Forwarded-Proto` and `X-Forwarded-For`, and change the `trust proxy` hop count if there is more than one proxy.

### Custom domain (optional)

1. Render > your service > **Settings > Custom Domains > Add Custom Domain**, enter e.g. `lab.yourdomain.com`.
2. At your DNS provider, add the record Render shows (normally a `CNAME` pointing the subdomain at your `*.onrender.com` address; apex domains use the A/ALIAS values Render lists).
3. Wait for DNS to propagate; Render then verifies the domain and issues the certificate automatically.
4. Visit `https://lab.yourdomain.com` and confirm the padlock and the redirect from `http://`.

---

## 7. What changes between development and production

| Area | Development (`npm run dev`) | Production (Render) |
|---|---|---|
| `NODE_ENV` | `development` | `production` |
| Protocol | `http://localhost:3000` | `https://...` terminated by Render's proxy |
| Secrets | `.env` file; missing ones are generated at random | Render environment variables; missing ones stop the app starting |
| Session cookie | `HttpOnly`, `SameSite=Lax` | plus `Secure` |
| CSRF cookie name | `lab.csrf` | `__Host-lab.csrf` (Secure, host-only) |
| HSTS and `upgrade-insecure-requests` | off (would break plain HTTP) | on |
| `trust proxy` | off | on (1 hop) |
| bcrypt cost | 12 | 12 (tests use 4 for speed only) |
| Log level | `debug` | `info`, JSON lines |
| Static file caching | none | 1 day |
| Sample users | created with a random password printed once | only if `SEED_USER_PASSWORD` is set |
| Admin password | random if unset, printed once | **must** be set; never printed |
| Database | `./data/lab.db` | `./data/lab.db` on an ephemeral disk, or a persistent disk path |
| Dependencies | all, including Jest | `npm ci --omit=dev` (no test tools) |

---

## 8. Data persistence on the free plan (important)

The app uses a **SQLite file**. On Render's free plan the disk is **ephemeral**: the file is wiped whenever the service restarts, redeploys or spins down after being idle. That has two consequences:

1. **The app seeds itself on every start.** `src/server.js` calls `seedIfEmpty`, so after a reset you immediately get the admin (from `ADMIN_PASSWORD`) and the 20 sample computers back. The site is never left empty or locked out.
2. **Data created after seeding (new users, bookings, fault reports, audit entries) is lost on the next reset.** That is acceptable for a demonstration, and it is a limitation you should state in your review.

Free web services also **spin down after a period of inactivity** and take a little while to wake on the next request (the first load can be slow).

Options if you need data to survive:

- **Render persistent disk** (paid instance types): attach a disk at `/var/data` and set `DB_PATH=/var/data/lab.db`. The SQLite file then survives restarts and deploys.
- **A hosted database** (for example PostgreSQL): would need the data layer in `src/models/` rewritten for that database. Out of scope for this project, but a sensible "future improvement".

---

## 9. Backups

`npm run backup` writes a timestamped, consistent copy of the database to `./backups/` (override with `BACKUP_DIR`) and keeps the newest 7 (`BACKUP_KEEP`). It uses SQLite's online backup API, so it is safe to run while the app is live.

**Suggested strategy**

| Question | Answer for this project |
|---|---|
| What to back up | The SQLite file (users, bookings, faults, audit log). Everything else is in git. |
| How often | Before every deploy that changes the schema, and at least daily if the data matters (a scheduled job, or a Render cron job on a paid plan). |
| Where to keep copies | **Off the server**: your laptop, a private cloud drive or a private bucket. A backup on the same disk dies with it. |
| How many | Keep several generations (default 7) so a bad change noticed a few days late can still be undone. |
| Privacy | Backups contain bcrypt hashes and personal data. Never commit them (`backups/` is git-ignored). Store them privately; delete old copies. |
| Test restores | A backup you have never restored is a hope, not a backup. To restore: stop the app, replace `data/lab.db` with the backup file, start the app. Try it once on your laptop. |

On the free plan there is no persistent disk to run the script against, so practise the backup and restore locally (and, if you add a persistent disk later, schedule it there).

---

## 10. Monitoring and logs

- **Request and error logs**: one JSON object per line on stdout (pino). In Render, open your service > **Logs**. Look for `"level":50` (error) and `"level":60` (fatal). Each request line has method, path, status code and response time. Passwords, cookies and session IDs are redacted and bodies/query strings are not logged.
- **Health check**: Render calls `GET /health` and restarts the service if it fails. The endpoint also checks the database responds.
- **Crashes**: `uncaughtException` and `unhandledRejection` are logged at fatal level and the process exits so Render restarts it cleanly.
- **Security events**: the in-app **audit log** (Admin > Audit log) records logins, failed logins, lockouts, role changes and booking decisions.
- **Optional**: Render can email you on failed deploys; an external uptime monitor can ping `/health` (this also keeps a free instance awake, which you may or may not want).

---

## 11. Post-deployment checklist

- [ ] `https://YOUR-URL/health` returns `{"status":"ok"}`
- [ ] Padlock shown; `http://` redirects to `https://`
- [ ] Admin login works with the password set in Render
- [ ] `curl -I https://YOUR-URL/login` shows `Content-Security-Policy`, `Strict-Transport-Security`, `X-Content-Type-Options`, and **no** `X-Powered-By`
- [ ] Session cookie has `Secure; HttpOnly; SameSite=Lax`
- [ ] Logs show JSON lines with no passwords or cookies
- [ ] No `.env`, database or backup files in the GitHub repository
- [ ] Default/sample passwords changed or sample users not created
- [ ] Run the post-deployment rows in `TESTING.md` section 7

## 12. Rolling back

Render keeps previous deploys: service > **Events / Deploys** > pick an earlier successful deploy > **Rollback**. Or `git revert` the bad commit and push. Remember that on the free plan the database is re-seeded on restart anyway.

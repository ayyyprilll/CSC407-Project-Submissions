// Admin area: access control on every route, and each admin function.
const { request, buildApp, loggedInAgent, submit, slot, userId, csrfFor, ADMIN, USER, USER2 } = require('./helpers');

let app, db, admin;
beforeEach(async () => {
  ({ app, db } = buildApp());
  admin = await loggedInAgent(app, ADMIN);
});
afterEach(() => db.close());

const post = (path, fields = {}, page = '/admin/users') => submit(admin, page, path, fields);
const flashText = async (agent, page = '/admin/users') => (await agent.get(page)).text;

function addBooking({ user = USER, computer = 1, day = 3, hour = 10, minutes = 60, status = 'pending' } = {}) {
  const s = slot(day, hour, minutes);
  const info = db.prepare('INSERT INTO bookings (user_id, computer_id, start_time, end_time, purpose, status) VALUES (?, ?, ?, ?, ?, ?)')
    .run(userId(db, user), computer, new Date(s.start + ':00Z').toISOString(), new Date(s.end + ':00Z').toISOString(), 'lab session', status);
  return Number(info.lastInsertRowid);
}
const bookingStatus = (id) => db.prepare('SELECT * FROM bookings WHERE id = ?').get(id);

// ---------- Access control: every admin route ----------
const GET_ROUTES = ['/admin', '/admin/computers', '/admin/computers/new', '/admin/computers/1/edit', '/admin/bookings', '/admin/faults', '/admin/users', '/admin/audit'];
const POST_ROUTES = [
  '/admin/computers', '/admin/computers/1', '/admin/computers/1/retire', '/admin/bookings/1/approve', '/admin/bookings/1/reject',
  '/admin/faults/1/status', '/admin/users/1/role', '/admin/users/1/active',
];

describe('every admin route is closed to non-admins', () => {
  test.each(GET_ROUTES)('GET %s: user gets 403, anonymous is sent to login', async (path) => {
    const user = await loggedInAgent(app, USER);
    expect((await user.get(path)).status).toBe(403);
    const anon = await request(app).get(path);
    expect(anon.status).toBe(302);
    expect(anon.headers.location).toBe('/login');
  });

  test.each(POST_ROUTES)('POST %s: a normal user gets 403 even with a valid CSRF token', async (path) => {
    const user = await loggedInAgent(app, USER);
    const res = await submit(user, '/dashboard', path, { role: 'admin', status: 'resolved', active: '0', asset_tag: 'HACK-1', name: 'x', location: 'y', specs: '' });
    expect(res.status).toBe(403);
  });

  test('a normal user cannot promote themselves', async () => {
    const user = await loggedInAgent(app, USER);
    await submit(user, '/dashboard', `/admin/users/${userId(db, USER)}/role`, { role: 'admin' });
    expect(db.prepare('SELECT role FROM users WHERE email = ?').get(USER.email).role).toBe('user');
  });

  test('nothing changed in the database after the forbidden attempts', async () => {
    const user = await loggedInAgent(app, USER);
    await submit(user, '/dashboard', '/admin/computers/1/retire', {});
    expect(db.prepare('SELECT status FROM computers WHERE id = 1').get().status).toBe('available');
  });
});

describe('admin pages render', () => {
  test.each(['/admin/computers', '/admin/bookings', '/admin/faults', '/admin/users', '/admin/audit', '/admin/computers/new', '/admin/computers/1/edit'])(
    '%s returns 200 for an admin', async (path) => {
      expect((await admin.get(path)).status).toBe(200);
    }
  );

  test.each(['/admin/computers', '/admin/bookings', '/admin/faults', '/admin/users', '/admin/audit'])(
    '%s survives SQL injection in filters', async (path) => {
      const res = await admin.get(path).query({ q: "' OR 1=1; DROP TABLE users; --", status: "' OR 1=1 --", action: "x' --" });
      expect(res.status).toBe(200);
      expect(db.prepare('SELECT COUNT(*) n FROM users').get().n).toBe(4);
    }
  );

  test('admin sidebar shows the Administration section', async () => {
    expect((await admin.get('/admin/users')).text).toContain('Administration');
  });
});

// ---------- Computers ----------
describe('managing computers', () => {
  const good = { asset_tag: 'lab-100', name: 'Workstation 100', location: 'Lab D', specs: 'Test spec', status: 'available' };

  test('add: tag is upper-cased and the action is audited', async () => {
    const res = await post('/admin/computers', good, '/admin/computers/new');
    expect(res.status).toBe(302);
    expect(db.prepare("SELECT asset_tag FROM computers WHERE name = 'Workstation 100'").get().asset_tag).toBe('LAB-100');
    expect(db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action = 'computer_created'").get().n).toBe(1);
  });

  test.each([
    ['duplicate tag', { asset_tag: 'LAB-001' }],
    ['bad characters in tag', { asset_tag: '<b>x</b>' }],
    ['HTML in name', { name: '<script>alert(1)</script>' }],
    ['unknown status', { status: 'exploded' }],
    ['missing location', { location: '' }],
  ])('add rejects %s', async (_n, over) => {
    const res = await post('/admin/computers', { ...good, ...over }, '/admin/computers/new');
    expect(res.status).toBe(400);
    expect(db.prepare('SELECT COUNT(*) n FROM computers').get().n).toBe(20);
  });

  test('edit changes the fields', async () => {
    const res = await post('/admin/computers/2', { ...good, asset_tag: 'LAB-002', name: 'Renamed', status: 'maintenance' }, '/admin/computers/2/edit');
    expect(res.status).toBe(302);
    expect(db.prepare('SELECT name, status FROM computers WHERE id = 2').get()).toEqual({ name: 'Renamed', status: 'maintenance' });
  });

  test('edit to a duplicate tag is refused', async () => {
    const res = await post('/admin/computers/2', { ...good, asset_tag: 'LAB-003' }, '/admin/computers/2/edit');
    expect(res.status).toBe(400);
  });

  test('retire is a soft change and cancels future bookings', async () => {
    const b = addBooking({ computer: 4, status: 'approved' });
    const past = addBooking({ computer: 4, day: -5, status: 'approved' });
    const res = await post('/admin/computers/4/retire', {}, '/admin/computers');
    expect(res.status).toBe(302);
    expect(db.prepare('SELECT status FROM computers WHERE id = 4').get().status).toBe('retired');
    expect(bookingStatus(b).status).toBe('cancelled');
    expect(bookingStatus(past).status).toBe('approved'); // history untouched
  });

  test('unknown or malformed ids give 404', async () => {
    expect((await admin.get('/admin/computers/9999/edit')).status).toBe(404);
    expect((await admin.get('/admin/computers/abc/edit')).status).toBe(404);
    expect((await post('/admin/computers/9999/retire', {}, '/admin/computers')).status).toBe(404);
  });

  test('computer names are escaped in the admin list', async () => {
    db.prepare('UPDATE computers SET name = ? WHERE id = 1').run('<img src=x onerror=alert(1)>');
    const html = (await admin.get('/admin/computers')).text;
    expect(html).not.toContain('<img src=x');
  });

  test('changes need a CSRF token', async () => {
    const res = await admin.post('/admin/computers/1/retire').type('form').send({});
    expect(res.status).toBe(403);
    expect(db.prepare('SELECT status FROM computers WHERE id = 1').get().status).toBe('available');
  });
});

// ---------- Bookings ----------
describe('booking decisions', () => {
  test('approve records who decided and is audited', async () => {
    const id = addBooking();
    const res = await post(`/admin/bookings/${id}/approve`, {}, '/admin/bookings');
    expect(res.status).toBe(302);
    const row = bookingStatus(id);
    expect(row.status).toBe('approved');
    expect(row.decided_by).toBe(userId(db, ADMIN));
    expect(row.decided_at).not.toBeNull();
    expect(db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action = 'booking_approved' AND target_id = ?").get(id).n).toBe(1);
  });

  test('reject works and is audited', async () => {
    const id = addBooking();
    await post(`/admin/bookings/${id}/reject`, {}, '/admin/bookings');
    expect(bookingStatus(id).status).toBe('rejected');
    expect(db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action = 'booking_rejected'").get().n).toBe(1);
  });

  test('two overlapping requests: the second cannot be approved', async () => {
    const a = addBooking({ user: USER });
    const b = addBooking({ user: USER2 });
    await post(`/admin/bookings/${a}/approve`, {}, '/admin/bookings');
    await post(`/admin/bookings/${b}/approve`, {}, '/admin/bookings');
    expect(bookingStatus(a).status).toBe('approved');
    expect(bookingStatus(b).status).toBe('pending');
    expect(await flashText(admin, '/admin/bookings')).toContain('overlaps');
  });

  test('cannot approve a booking whose time has passed', async () => {
    const id = addBooking({ day: -2 });
    await post(`/admin/bookings/${id}/approve`, {}, '/admin/bookings');
    expect(bookingStatus(id).status).toBe('pending');
  });

  test('cannot approve a booking for a computer under maintenance', async () => {
    const id = addBooking({ computer: 5 });
    db.prepare("UPDATE computers SET status = 'maintenance' WHERE id = 5").run();
    await post(`/admin/bookings/${id}/approve`, {}, '/admin/bookings');
    expect(bookingStatus(id).status).toBe('pending');
  });

  test('only pending bookings can be decided', async () => {
    const id = addBooking({ status: 'cancelled' });
    await post(`/admin/bookings/${id}/approve`, {}, '/admin/bookings');
    expect(bookingStatus(id).status).toBe('cancelled');
  });

  test('unknown and malformed ids give 404', async () => {
    expect((await post('/admin/bookings/9999/approve', {}, '/admin/bookings')).status).toBe(404);
    expect((await post('/admin/bookings/1;DROP/approve', {}, '/admin/bookings')).status).toBe(404);
  });

  test('admin list shows bookings of all users and can filter and search', async () => {
    addBooking({ user: USER, computer: 1 });
    addBooking({ user: USER2, computer: 2, status: 'approved' });
    const all = (await admin.get('/admin/bookings')).text;
    expect(all).toContain('Amara Okafor');
    expect(all).toContain('Tunde Bello');
    const pending = (await admin.get('/admin/bookings?status=pending')).text;
    expect(pending).toContain('Amara Okafor');
    expect(pending).not.toContain('Tunde Bello');
    expect((await admin.get('/admin/bookings?q=tunde')).text).not.toContain('Amara Okafor');
  });
});

// ---------- Faults ----------
describe('fault reports', () => {
  let id;
  beforeEach(() => {
    id = Number(db.prepare("INSERT INTO fault_reports (computer_id, reported_by, description, severity) VALUES (1, ?, 'Keyboard keys stuck', 'low')")
      .run(userId(db, USER)).lastInsertRowid);
  });

  test('admin can move a report through investigating to resolved', async () => {
    await post(`/admin/faults/${id}/status`, { status: 'investigating' }, '/admin/faults');
    expect(db.prepare('SELECT status FROM fault_reports WHERE id = ?').get(id).status).toBe('investigating');
    await post(`/admin/faults/${id}/status`, { status: 'resolved' }, '/admin/faults');
    const row = db.prepare('SELECT status, resolved_by FROM fault_reports WHERE id = ?').get(id);
    expect(row).toEqual({ status: 'resolved', resolved_by: userId(db, ADMIN) });
  });

  test('invalid status is refused', async () => {
    await post(`/admin/faults/${id}/status`, { status: 'deleted' }, '/admin/faults');
    expect(db.prepare('SELECT status FROM fault_reports WHERE id = ?').get(id).status).toBe('open');
  });

  test('unknown id gives 404', async () => {
    expect((await post('/admin/faults/9999/status', { status: 'resolved' }, '/admin/faults')).status).toBe(404);
  });

  test('list shows the report and escapes its text', async () => {
    db.prepare("UPDATE fault_reports SET description = ? WHERE id = ?").run('<script>alert(1)</script>', id);
    const html = (await admin.get('/admin/faults')).text;
    expect(html).not.toContain('<script>alert(1)');
    expect(html).toContain('&lt;script&gt;');
  });
});

// ---------- Users ----------
describe('user management', () => {
  const role = (u) => db.prepare('SELECT role FROM users WHERE email = ?').get(u.email).role;
  const active = (u) => db.prepare('SELECT is_active FROM users WHERE email = ?').get(u.email).is_active;

  test('admin can change a role, and it is audited with the details', async () => {
    await post(`/admin/users/${userId(db, USER)}/role`, { role: 'admin' });
    expect(role(USER)).toBe('admin');
    const entry = db.prepare("SELECT * FROM audit_logs WHERE action = 'role_changed'").get();
    expect(entry.details).toContain('user -> admin');
    expect(entry.user_id).toBe(userId(db, ADMIN));
  });

  test('the role takes effect immediately for the affected user', async () => {
    const user = await loggedInAgent(app, USER);
    expect((await user.get('/admin/users')).status).toBe(403);
    await post(`/admin/users/${userId(db, USER)}/role`, { role: 'admin' });
    expect((await user.get('/admin/users')).status).toBe(200);
  });

  test('invalid role values are refused', async () => {
    await post(`/admin/users/${userId(db, USER)}/role`, { role: 'superadmin' });
    expect(role(USER)).toBe('user');
  });

  test('an admin cannot change their own role (so an admin always remains)', async () => {
    await post(`/admin/users/${userId(db, ADMIN)}/role`, { role: 'user' });
    expect(role(ADMIN)).toBe('admin');
  });

  test('an admin cannot deactivate themselves', async () => {
    await post(`/admin/users/${userId(db, ADMIN)}/active`, { active: '0' });
    expect(active(ADMIN)).toBe(1);
  });

  test('deactivating a user logs them out immediately and blocks login; activating restores it', async () => {
    const user = await loggedInAgent(app, USER);
    expect((await user.get('/dashboard')).status).toBe(200);
    await post(`/admin/users/${userId(db, USER)}/active`, { active: '0' });
    expect(active(USER)).toBe(0);
    expect((await user.get('/dashboard')).status).toBe(302);
    expect(db.prepare("SELECT COUNT(*) n FROM sessions WHERE json_extract(sess, '$.userId') = ?").get(userId(db, USER)).n).toBe(0);
    await post(`/admin/users/${userId(db, USER)}/active`, { active: '1' });
    expect((await loggedInAgent(app, USER).then((a) => a.get('/dashboard'))).status).toBe(200);
  });

  test('unknown and malformed ids give 404', async () => {
    expect((await post('/admin/users/9999/role', { role: 'user' })).status).toBe(404);
    expect((await post('/admin/users/x/active', { active: '0' })).status).toBe(404);
  });

  test('list supports search and filters, and never shows password hashes', async () => {
    const html = (await admin.get('/admin/users')).text;
    expect(html).not.toMatch(/\$2[aby]\$/);
    expect((await admin.get('/admin/users?q=amara')).text).not.toContain('tunde@lab.local');
    expect((await admin.get('/admin/users?role=admin')).text).not.toContain('amara@lab.local');
  });

  test('user-supplied names are escaped in the list', async () => {
    db.prepare('UPDATE users SET full_name = ? WHERE email = ?').run('<img src=x onerror=alert(1)>', USER.email);
    expect((await admin.get('/admin/users')).text).not.toContain('<img src=x');
  });
});

// ---------- Audit log ----------
describe('audit log', () => {
  test('records the key events and the admin can view and filter them', async () => {
    await loggedInAgent(app, USER);                               // login_success
    await post(`/admin/users/${userId(db, USER)}/role`, { role: 'admin' }); // role_changed
    const id = addBooking({ user: USER2 });
    await post(`/admin/bookings/${id}/approve`, {}, '/admin/bookings');     // booking_approved
    const actions = db.prepare('SELECT DISTINCT action FROM audit_logs').all().map((r) => r.action);
    expect(actions).toEqual(expect.arrayContaining(['login_success', 'role_changed', 'booking_approved']));

    const html = (await admin.get('/admin/audit')).text;
    expect(html).toContain('role changed');
    const filtered = (await admin.get('/admin/audit?action=booking_approved')).text;
    expect(filtered).toContain('<td data-label="Action">booking approved</td>');
    expect(filtered).not.toContain('<td data-label="Action">role changed</td>'); // (the dropdown still lists it)
  });

  test('details are escaped (a malicious value cannot inject markup)', async () => {
    db.prepare("INSERT INTO audit_logs (action, details) VALUES ('login_failed', ?)").run('<script>alert(1)</script>');
    const html = (await admin.get('/admin/audit')).text;
    expect(html).not.toContain('<script>alert(1)');
  });

  test('the app exposes no way to change or delete audit entries', async () => {
    db.prepare("INSERT INTO audit_logs (action) VALUES ('x')").run();
    for (const method of ['post', 'put', 'delete', 'patch']) {
      const token = await csrfFor(admin, '/admin/audit');
      const res = await admin[method]('/admin/audit').type('form').send({ _csrf: token });
      expect([404, 405]).toContain(res.status);
    }
    expect(db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE action = 'x'").get().n).toBe(1);
  });
});

describe('security page', () => {
  test('is public and lists the protections with their code locations', async () => {
    const res = await request(app).get('/security');
    expect(res.status).toBe(200);
    for (const word of ['Password hashing', 'CSRF protection', 'IDOR prevention', 'src/middleware/csrf.js']) {
      expect(res.text).toContain(word);
    }
  });
});

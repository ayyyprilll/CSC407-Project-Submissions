// Phase 1 tests: app boots, health check, 404 page, seed, and database constraints.
process.env.NODE_ENV = 'test';
const request = require('supertest');
const { openDb } = require('../src/db/connection');
const { seedIfEmpty } = require('../src/db/seed');
const { createApp } = require('../src/app');

let db, app;
beforeAll(() => {
  db = openDb(':memory:');
  seedIfEmpty(db);
  app = createApp(db);
});
afterAll(() => db.close());

describe('app basics', () => {
  test('home page renders', async () => {
    const res = await request(app).get('/');
    expect(res.status).toBe(200);
    expect(res.text).toContain('Computer Laboratory Management');
  });

  test('health check reports ok', async () => {
    const res = await request(app).get('/health');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ status: 'ok' });
  });

  test('unknown route gives a clean 404 page without internals', async () => {
    const res = await request(app).get('/no/such/page');
    expect(res.status).toBe(404);
    expect(res.text).toContain('Page not found');
    expect(res.text).not.toMatch(/at .*\.js:\d+/); // no stack trace
  });

  test('X-Powered-By header is not sent', async () => {
    const res = await request(app).get('/');
    expect(res.headers['x-powered-by']).toBeUndefined();
  });
});

describe('seed data', () => {
  test('creates 1 admin, 3 users and 20 computers', () => {
    expect(db.prepare("SELECT COUNT(*) n FROM users WHERE role='admin'").get().n).toBe(1);
    expect(db.prepare("SELECT COUNT(*) n FROM users WHERE role='user'").get().n).toBe(3);
    expect(db.prepare('SELECT COUNT(*) n FROM computers').get().n).toBe(20);
  });

  test('passwords are stored as bcrypt hashes', () => {
    const rows = db.prepare('SELECT password_hash FROM users').all();
    for (const r of rows) expect(r.password_hash).toMatch(/^\$2[aby]\$/);
  });

  test('seeding twice does not duplicate data', () => {
    expect(seedIfEmpty(db)).toBe(false);
    expect(db.prepare('SELECT COUNT(*) n FROM computers').get().n).toBe(20);
  });
});

describe('database constraints', () => {
  test('duplicate email is rejected (case-insensitive)', () => {
    expect(() =>
      db.prepare('INSERT INTO users (full_name,email,password_hash) VALUES (?,?,?)')
        .run('Dup User', 'AMARA@LAB.LOCAL', 'x')
    ).toThrow(/UNIQUE/);
  });

  test('invalid role is rejected', () => {
    expect(() =>
      db.prepare('INSERT INTO users (full_name,email,password_hash,role) VALUES (?,?,?,?)')
        .run('Bad Role', 'badrole@lab.local', 'x', 'superuser')
    ).toThrow(/CHECK/);
  });

  test('foreign keys are enforced', () => {
    expect(() =>
      db.prepare("INSERT INTO bookings (user_id,computer_id,start_time,end_time,purpose) VALUES (999,1,'2030-01-01T10:00:00Z','2030-01-01T11:00:00Z','test')").run()
    ).toThrow(/FOREIGN KEY/);
  });

  test('booking must end after it starts', () => {
    expect(() =>
      db.prepare("INSERT INTO bookings (user_id,computer_id,start_time,end_time,purpose) VALUES (1,1,'2030-01-01T11:00:00Z','2030-01-01T10:00:00Z','test')").run()
    ).toThrow(/CHECK/);
  });

  test('invalid computer status is rejected', () => {
    expect(() =>
      db.prepare("UPDATE computers SET status='exploded' WHERE id=1").run()
    ).toThrow(/CHECK/);
  });
});

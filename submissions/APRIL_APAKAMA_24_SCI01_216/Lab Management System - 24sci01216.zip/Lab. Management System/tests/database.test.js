// Database constraints: the database refuses bad data even if application code were to allow it.
const fs = require('fs');
const os = require('os');
const path = require('path');
const { openDb } = require('../src/db/connection');
const { seedIfEmpty } = require('../src/db/seed');
const computers = require('../src/models/computers');
const users = require('../src/models/users');

let db;
beforeEach(() => { db = openDb(':memory:'); seedIfEmpty(db); });
afterEach(() => db.close());

const insertUser = (over = {}) => {
  const v = { full_name: 'Test Person', email: 'person@lab.local', password_hash: 'x', role: 'user', is_active: 1, ...over };
  return db.prepare('INSERT INTO users (full_name,email,password_hash,role,is_active) VALUES (@full_name,@email,@password_hash,@role,@is_active)').run(v);
};
const future = (h) => new Date(Date.now() + h * 3600000).toISOString();

describe('users table', () => {
  test('email must be unique regardless of letter case', () => {
    insertUser();
    expect(() => insertUser({ email: 'PERSON@LAB.LOCAL' })).toThrow(/UNIQUE/);
  });
  test.each([
    ['role outside the allowed list', { email: 'a1@lab.local', role: 'root' }],
    ['is_active other than 0/1', { email: 'a2@lab.local', is_active: 2 }],
    ['name too short', { email: 'a3@lab.local', full_name: 'A' }],
    ['name too long', { email: 'a4@lab.local', full_name: 'N'.repeat(101) }],
    ['email too short', { email: 'a@b' }],
  ])('rejects %s', (_n, over) => {
    expect(() => insertUser(over)).toThrow(/CHECK/);
  });
  test('password hash is required', () => {
    expect(() => db.prepare('INSERT INTO users (full_name,email) VALUES (?,?)').run('No Hash', 'nohash@lab.local')).toThrow(/NOT NULL/);
  });
});

describe('computers table', () => {
  const ins = (tag, extra = {}) => db.prepare('INSERT INTO computers (asset_tag,name,location,specs,status) VALUES (?,?,?,?,?)')
    .run(tag, extra.name || 'Name', extra.location || 'Lab', extra.specs || '', extra.status || 'available');
  test('asset tag is unique', () => expect(() => ins('LAB-001')).toThrow(/UNIQUE/));
  test('status must be a known value', () => expect(() => ins('NEW-1', { status: 'broken' })).toThrow(/CHECK/));
  test('specs are limited to 300 characters', () => expect(() => ins('NEW-2', { specs: 's'.repeat(301) })).toThrow(/CHECK/));
});

describe('bookings table', () => {
  const ins = (over = {}) => {
    const v = { user_id: 2, computer_id: 1, start_time: future(1), end_time: future(2), purpose: 'valid purpose', status: 'pending', ...over };
    return db.prepare('INSERT INTO bookings (user_id,computer_id,start_time,end_time,purpose,status) VALUES (@user_id,@computer_id,@start_time,@end_time,@purpose,@status)').run(v);
  };
  test('valid row is accepted and defaults to pending', () => {
    ins();
    expect(db.prepare('SELECT status FROM bookings').get().status).toBe('pending');
  });
  test('needs an existing user and an existing computer (foreign keys)', () => {
    expect(() => ins({ user_id: 999 })).toThrow(/FOREIGN KEY/);
    expect(() => ins({ computer_id: 999 })).toThrow(/FOREIGN KEY/);
  });
  test('end must be after start', () => expect(() => ins({ start_time: future(2), end_time: future(1) })).toThrow(/CHECK/));
  test('status must be a known value', () => expect(() => ins({ status: 'maybe' })).toThrow(/CHECK/));
  test('purpose length limits', () => {
    expect(() => ins({ purpose: 'ab' })).toThrow(/CHECK/);
    expect(() => ins({ purpose: 'p'.repeat(201) })).toThrow(/CHECK/);
  });
  test('a user or computer with bookings cannot be deleted (history is protected)', () => {
    ins();
    expect(() => db.prepare('DELETE FROM users WHERE id = 2').run()).toThrow(/FOREIGN KEY/);
    expect(() => db.prepare('DELETE FROM computers WHERE id = 1').run()).toThrow(/FOREIGN KEY/);
  });
});

describe('fault_reports and audit_logs tables', () => {
  test('severity and status must be known values', () => {
    const ins = (sev, st) => db.prepare('INSERT INTO fault_reports (computer_id,reported_by,description,severity,status) VALUES (1,2,?,?,?)').run('something broke', sev, st);
    expect(() => ins('apocalyptic', 'open')).toThrow(/CHECK/);
    expect(() => ins('low', 'ignored')).toThrow(/CHECK/);
    expect(() => ins('low', 'open')).not.toThrow();
  });
  test('description length limits', () => {
    const ins = (d) => db.prepare("INSERT INTO fault_reports (computer_id,reported_by,description,severity) VALUES (1,2,?,'low')").run(d);
    expect(() => ins('bad')).toThrow(/CHECK/);
    expect(() => ins('d'.repeat(1001))).toThrow(/CHECK/);
  });
  test('deleting a user keeps their audit entries (user id becomes NULL)', () => {
    const id = Number(insertUser({ email: 'gone@lab.local' }).lastInsertRowid);
    db.prepare("INSERT INTO audit_logs (user_id, action) VALUES (?, 'login_success')").run(id);
    db.prepare('DELETE FROM users WHERE id = ?').run(id);
    expect(db.prepare("SELECT user_id FROM audit_logs WHERE action = 'login_success'").get().user_id).toBeNull();
  });
});

describe('connection behaviour', () => {
  test('foreign key enforcement is switched on', () => {
    expect(db.pragma('foreign_keys', { simple: true })).toBe(1);
  });

  test('schema can be applied repeatedly and keeps existing data', () => {
    const file = path.join(os.tmpdir(), `lab-schema-test-${process.pid}-${Date.now()}.db`);
    try {
      const a = openDb(file);
      a.prepare("INSERT INTO computers (asset_tag,name,location) VALUES ('KEEP-1','Keep','Lab')").run();
      a.close();
      const b = openDb(file);
      expect(b.prepare("SELECT COUNT(*) n FROM computers WHERE asset_tag = 'KEEP-1'").get().n).toBe(1);
      b.close();
    } finally {
      for (const ext of ['', '-wal', '-shm']) fs.rmSync(file + ext, { force: true });
    }
  });

  test('parameter binding stores hostile text as plain data and does not execute it', () => {
    const evil = "Robert'); DROP TABLE users; --";
    const r = computers.create(db, { assetTag: 'EVIL-1', name: evil, location: 'Lab', specs: '', status: 'available' });
    expect(r.id).toBeGreaterThan(0);
    expect(db.prepare('SELECT name FROM computers WHERE id = ?').get(r.id).name).toBe(evil);
    expect(db.prepare('SELECT COUNT(*) n FROM users').get().n).toBe(4);
  });

  test('lockout counter locks on the 5th failure and clears on success', () => {
    for (let i = 1; i <= 4; i++) expect(users.registerFailedAttempt(db, 2)).toBe(false);
    expect(users.registerFailedAttempt(db, 2)).toBe(true);
    expect(users.isLocked(db.prepare('SELECT * FROM users WHERE id = 2').get())).toBe(true);
    users.clearFailedAttempts(db, 2);
    expect(users.isLocked(db.prepare('SELECT * FROM users WHERE id = 2').get())).toBe(false);
  });
});

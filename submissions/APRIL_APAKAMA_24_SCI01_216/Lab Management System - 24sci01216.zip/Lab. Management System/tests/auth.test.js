// Registration, login, logout, sessions, lockout, role checks and security headers.
const { request, buildApp, csrfFor, login, loggedInAgent, ADMIN, USER } = require('./helpers');

let app, db;
beforeEach(() => ({ app, db } = buildApp()));
afterEach(() => db.close());

async function register(agent, fields) {
  const token = await csrfFor(agent, '/register');
  return agent.post('/register').type('form').send({ _csrf: token, ...fields });
}

const validReg = {
  full_name: "Ngozi O'Brien-Eze",
  email: 'ngozi@lab.local',
  password: 'GoodPassw0rd!',
  confirm_password: 'GoodPassw0rd!',
};

describe('registration', () => {
  test('creates a normal user with a bcrypt-hashed password', async () => {
    const res = await register(request.agent(app), validReg);
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/login');
    const row = db.prepare('SELECT * FROM users WHERE email = ?').get('ngozi@lab.local');
    expect(row.role).toBe('user');
    expect(row.password_hash).toMatch(/^\$2[aby]\$/);
    expect(row.password_hash).not.toContain('GoodPassw0rd');
  });

  test('cannot self-assign the admin role by adding a form field', async () => {
    await register(request.agent(app), { ...validReg, role: 'admin' });
    expect(db.prepare('SELECT role FROM users WHERE email = ?').get('ngozi@lab.local').role).toBe('user');
  });

  test('duplicate email gets the same response and creates no second account', async () => {
    const res = await register(request.agent(app), { ...validReg, email: USER.email });
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/login');
    expect(db.prepare('SELECT COUNT(*) n FROM users WHERE email = ?').get(USER.email).n).toBe(1);
  });

  test.each([
    ['short password', { password: 'Ab1', confirm_password: 'Ab1' }],
    ['no digit', { password: 'OnlyLettersHere', confirm_password: 'OnlyLettersHere' }],
    ['mismatch', { confirm_password: 'Different1234' }],
    ['bad email', { email: 'not-an-email' }],
    ['script in name', { full_name: '<script>alert(1)</script>' }],
    ['array injection', { email: ['a@b.co', 'c@d.co'] }],
  ])('rejects invalid input: %s', async (_name, override) => {
    const before = db.prepare('SELECT COUNT(*) n FROM users').get().n;
    const res = await register(request.agent(app), { ...validReg, ...override });
    expect(res.status).toBe(400);
    expect(db.prepare('SELECT COUNT(*) n FROM users').get().n).toBe(before);
  });

  test('re-rendered form never contains the submitted password', async () => {
    const res = await register(request.agent(app), { ...validReg, password: 'Short1', confirm_password: 'Short1' });
    expect(res.text).not.toContain('Short1');
  });
});

describe('login', () => {
  test('valid credentials redirect to the dashboard', async () => {
    const res = await login(request.agent(app), USER);
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/dashboard');
  });

  test('session cookie is HttpOnly and SameSite=Lax', async () => {
    const res = await login(request.agent(app), USER);
    const cookie = res.headers['set-cookie'].find((c) => c.startsWith('lab.sid='));
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Lax/i);
  });

  test('session ID changes on login (fixation defence)', async () => {
    const agent = request.agent(app);
    const pre = await agent.get('/login');
    const preCookie = pre.headers['set-cookie'].find((c) => c.startsWith('lab.sid=')).split(';')[0];
    const token = pre.text.match(/name="_csrf" value="([^"]+)"/)[1];
    const res = await agent.post('/login').type('form').send({ _csrf: token, ...USER });
    const postCookie = res.headers['set-cookie'].find((c) => c.startsWith('lab.sid=')).split(';')[0];
    expect(postCookie).not.toBe(preCookie);
  });

  test('wrong password and unknown email produce identical generic errors', async () => {
    const strip = (t) => t.replace(/name="_csrf" value="[^"]+"/, '').replace(/value="[^"]*"/g, '');
    const a = await login(request.agent(app), { email: USER.email, password: 'WrongPassword1' });
    const b = await login(request.agent(app), { email: 'nobody@lab.local', password: 'WrongPassword1' });
    expect(a.status).toBe(401);
    expect(b.status).toBe(401);
    expect(a.text).toContain('Invalid email or password');
    expect(strip(a.text)).toBe(strip(b.text));
  });

  test('account locks after 5 failures, even for the correct password', async () => {
    const agent = request.agent(app);
    for (let i = 0; i < 5; i++) await login(agent, { email: USER.email, password: 'WrongPassword1' });
    const res = await login(agent, USER);
    expect(res.status).toBe(401);
    expect(db.prepare('SELECT locked_until FROM users WHERE email = ?').get(USER.email).locked_until).not.toBeNull();
  });

  test('lock expires, then login works and counters reset', async () => {
    const agent = request.agent(app);
    for (let i = 0; i < 5; i++) await login(agent, { email: USER.email, password: 'WrongPassword1' });
    db.prepare("UPDATE users SET locked_until = '2000-01-01T00:00:00.000Z' WHERE email = ?").run(USER.email);
    const res = await login(agent, USER);
    expect(res.status).toBe(302);
    expect(db.prepare('SELECT failed_attempts, locked_until FROM users WHERE email = ?').get(USER.email))
      .toEqual({ failed_attempts: 0, locked_until: null });
  });

  test('deactivated users cannot log in', async () => {
    db.prepare('UPDATE users SET is_active = 0 WHERE email = ?').run(USER.email);
    const res = await login(request.agent(app), USER);
    expect(res.status).toBe(401);
  });

  test('deactivating a user ends their existing session immediately', async () => {
    const agent = await loggedInAgent(app, USER);
    expect((await agent.get('/dashboard')).status).toBe(200);
    db.prepare('UPDATE users SET is_active = 0 WHERE email = ?').run(USER.email);
    const res = await agent.get('/dashboard');
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/login');
  });

  test('success and failure are written to the audit log, without passwords', async () => {
    await login(request.agent(app), { email: USER.email, password: 'WrongPassword1' });
    await login(request.agent(app), USER);
    const actions = db.prepare('SELECT action FROM audit_logs').all().map((r) => r.action);
    expect(actions).toEqual(expect.arrayContaining(['login_failed', 'login_success']));
    const dump = JSON.stringify(db.prepare('SELECT * FROM audit_logs').all());
    expect(dump).not.toContain('WrongPassword1');
    expect(dump).not.toContain(USER.password);
  });
});

describe('logout', () => {
  test('destroys the session; the old cookie is useless afterwards', async () => {
    const agent = await loggedInAgent(app, USER);
    const page = await agent.get('/dashboard');
    const token = page.text.match(/name="_csrf" value="([^"]+)"/)[1];
    const res = await agent.post('/logout').type('form').send({ _csrf: token });
    expect(res.status).toBe(302);
    const after = await agent.get('/dashboard');
    expect(after.status).toBe(302);
    expect(after.headers.location).toBe('/login');
    expect(db.prepare('SELECT COUNT(*) n FROM sessions').get().n).toBeLessThanOrEqual(1);
  });
});

describe('access control', () => {
  test('anonymous visitors are redirected from protected pages', async () => {
    const res = await request(app).get('/dashboard');
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/login');
  });

  test('a normal user gets 403 on admin routes', async () => {
    const agent = await loggedInAgent(app, USER);
    expect((await agent.get('/admin')).status).toBe(403);
  });

  test('an admin passes the role check on admin routes', async () => {
    const agent = await loggedInAgent(app, ADMIN);
    expect((await agent.get('/admin')).status).toBe(302); // allowed through; /admin redirects to the dashboard
  });

  test('role change takes effect on the very next request', async () => {
    const agent = await loggedInAgent(app, ADMIN);
    db.prepare("UPDATE users SET role = 'user' WHERE email = ?").run(ADMIN.email);
    expect((await agent.get('/admin')).status).toBe(403);
  });
});

describe('security headers', () => {
  test('CSP is strict: self only, no unsafe-inline', async () => {
    const res = await request(app).get('/');
    const csp = res.headers['content-security-policy'];
    expect(csp).toContain("script-src 'self'");
    expect(csp).toContain("object-src 'none'");
    expect(csp).toContain("frame-ancestors 'none'");
    expect(csp).not.toContain('unsafe-inline');
    expect(csp).not.toContain('unsafe-eval');
  });

  test('other protective headers are present', async () => {
    const res = await request(app).get('/');
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['x-powered-by']).toBeUndefined();
    expect(res.headers['cache-control']).toBe('no-store');
  });

  test('pages contain no inline scripts or inline event handlers', async () => {
    for (const path of ['/', '/login', '/register']) {
      const html = (await request(app).get(path)).text;
      expect(html).not.toMatch(/<script(?![^>]*\bsrc=)/i);
      expect(html).not.toMatch(/\son[a-z]+\s*=/i);
      expect(html).not.toMatch(/\sstyle\s*=/i);
    }
  });
});

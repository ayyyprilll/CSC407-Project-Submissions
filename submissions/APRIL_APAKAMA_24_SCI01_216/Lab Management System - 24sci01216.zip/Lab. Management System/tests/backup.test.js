// Backup script: produces a valid, restorable copy and prunes old ones.
const fs = require('fs');
const os = require('os');
const path = require('path');
const Database = require('better-sqlite3');
const { openDb } = require('../src/db/connection');
const { seedIfEmpty } = require('../src/db/seed');
const { runBackup } = require('../scripts/backup');

let dir, dbFile;
beforeEach(() => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'lab-backup-'));
  dbFile = path.join(dir, 'live.db');
  const db = openDb(dbFile);
  seedIfEmpty(db, { quiet: true });
  db.close();
});
afterEach(() => fs.rmSync(dir, { recursive: true, force: true }));

test('creates a backup that opens and contains the data', async () => {
  const { target } = await runBackup({ dbPath: dbFile, dir: path.join(dir, 'b') });
  const copy = new Database(target, { readonly: true });
  expect(copy.prepare('SELECT COUNT(*) n FROM computers').get().n).toBe(20);
  expect(copy.prepare('SELECT COUNT(*) n FROM users').get().n).toBe(4);
  copy.close();
});

test('keeps only the newest N backups', async () => {
  const out = path.join(dir, 'b');
  for (let i = 0; i < 5; i++) {
    await runBackup({ dbPath: dbFile, dir: out, keep: 3, now: new Date(Date.UTC(2030, 0, 1, 0, 0, i)) });
  }
  const files = fs.readdirSync(out).sort();
  expect(files).toHaveLength(3);
  expect(files[0]).toContain('00-00-02'); // the two oldest were removed
});

test('fails clearly when the database does not exist', async () => {
  await expect(runBackup({ dbPath: path.join(dir, 'missing.db'), dir })).rejects.toThrow(/not found/);
});

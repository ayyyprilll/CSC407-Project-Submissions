// Runs before every test file. Test-only values, so tests never depend on a developer's .env.
process.env.NODE_ENV = 'test';
process.env.ADMIN_EMAIL = 'admin@lab.local';
process.env.ADMIN_PASSWORD = 'Admin-Test-Pass-1';
process.env.SEED_USER_PASSWORD = 'User-Test-Pass-1';

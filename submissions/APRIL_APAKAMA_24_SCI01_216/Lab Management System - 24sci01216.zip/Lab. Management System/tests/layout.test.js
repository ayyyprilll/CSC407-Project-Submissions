// Layout and dashboards: role-specific navigation and content, static assets, no inline code.
const { request, buildApp, loggedInAgent, ADMIN, USER } = require('./helpers');

let app, db;
beforeEach(() => ({ app, db } = buildApp()));
afterEach(() => db.close());

describe('role-based navigation and dashboards', () => {
  test('a normal user sees user links and no Administration section', async () => {
    const res = await (await loggedInAgent(app, USER)).get('/dashboard');
    expect(res.status).toBe(200);
    expect(res.text).toContain('Book a computer');
    expect(res.text).toContain('My bookings');
    expect(res.text).not.toContain('Administration');
    expect(res.text).not.toContain('/admin/users');
  });

  test('an admin sees the Administration section and the admin dashboard', async () => {
    const res = await (await loggedInAgent(app, ADMIN)).get('/dashboard');
    expect(res.status).toBe(200);
    expect(res.text).toContain('Administration');
    expect(res.text).toContain('/admin/users');
    expect(res.text).toContain('Admin dashboard');
  });

  test('the current page is marked in the navigation', async () => {
    const res = await (await loggedInAgent(app, USER)).get('/dashboard');
    expect(res.text).toMatch(/href="\/dashboard" aria-current="page"/);
  });

  test('logged-in pages have no inline scripts, handlers or styles', async () => {
    const html = (await (await loggedInAgent(app, ADMIN)).get('/dashboard')).text;
    expect(html).not.toMatch(/<script(?![^>]*\bsrc=)/i);
    expect(html).not.toMatch(/\son[a-z]+\s*=/i);
    expect(html).not.toMatch(/\sstyle\s*=/i);
  });

  test('user names are HTML-escaped in the page', async () => {
    db.prepare("UPDATE users SET full_name = ? WHERE email = ?").run('<img src=x onerror=alert(1)>', USER.email);
    const html = (await (await loggedInAgent(app, USER)).get('/dashboard')).text;
    expect(html).not.toContain('<img src=x');
    expect(html).toContain('&lt;img src=x');
  });
});

describe('static assets', () => {
  test.each(['/css/app.css', '/js/app.js', '/js/init.js', '/fonts/ibm-plex-sans-latin-400-normal.woff2'])(
    '%s is served', async (p) => {
      expect((await request(app).get(p)).status).toBe(200);
    }
  );

  test('source files are not exposed', async () => {
    for (const p of ['/package.json', '/src/config.js', '/.env', '/data/lab.db']) {
      expect((await request(app).get(p)).status).toBe(404);
    }
  });
});

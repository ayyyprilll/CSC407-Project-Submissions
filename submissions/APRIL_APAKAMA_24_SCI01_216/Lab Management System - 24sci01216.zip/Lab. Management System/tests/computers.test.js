// Computers list: search, filters, and hostile input in the query string.
const { request, buildApp, loggedInAgent, USER } = require('./helpers');

let app, db, agent;
beforeEach(async () => {
  ({ app, db } = buildApp());
  agent = await loggedInAgent(app, USER);
});
afterEach(() => db.close());

const rowCount = (html) => (html.match(/<td data-label="Tag"/g) || []).length;

describe('computers list', () => {
  test('requires login', async () => {
    const res = await request(app).get('/computers');
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/login');
  });

  test('shows the first page of computers with a pager', async () => {
    const res = await agent.get('/computers');
    expect(res.status).toBe(200);
    expect(rowCount(res.text)).toBe(15);
    expect(res.text).toContain('Showing 1-15 of 20');
    const page2 = await agent.get('/computers?page=2');
    expect(rowCount(page2.text)).toBe(5);
  });

  test('filters by status', async () => {
    const res = await agent.get('/computers?status=maintenance');
    expect(rowCount(res.text)).toBe(1);
    expect(res.text).toContain('LAB-007');
  });

  test('filters by location and keyword together', async () => {
    const res = await agent.get('/computers?location=Lab%20A&q=LAB-01');
    expect(res.status).toBe(200);
    expect(res.text).toContain('LAB-010');
    expect(res.text).not.toContain('LAB-002');
  });

  test('derived "in use" status comes from approved bookings', async () => {
    const start = new Date(Date.now() - 3600000).toISOString();
    const end = new Date(Date.now() + 3600000).toISOString();
    db.prepare("INSERT INTO bookings (user_id, computer_id, start_time, end_time, purpose, status) VALUES (2, 1, ?, ?, 'test purpose', 'approved')").run(start, end);
    const res = await agent.get('/computers?status=in_use');
    expect(rowCount(res.text)).toBe(1);
    expect(res.text).toContain('LAB-001');
  });

  test('unknown filter values and junk pages are ignored, not errors', async () => {
    const res = await agent.get('/computers?status=bogus&location=Moon&page=abc');
    expect(res.status).toBe(200);
    expect(rowCount(res.text)).toBe(15);
  });

  test('array-style parameters do not crash the page', async () => {
    expect((await agent.get('/computers?q=a&q=b')).status).toBe(200);
    expect((await agent.get('/computers?q[]=a&status[x]=y')).status).toBe(200);
  });

  test('LIKE wildcards typed by the user are treated literally', async () => {
    expect(rowCount((await agent.get('/computers?q=%25')).text)).toBe(0);
    expect(rowCount((await agent.get('/computers?q=_')).text)).toBe(0);
  });
});

describe('SQL injection attempts in filters', () => {
  const payloads = [
    "' OR '1'='1",
    "'; DROP TABLE users; --",
    "x' UNION SELECT id, email, password_hash, 1, 1, 1, 1 FROM users --",
    '" OR 1=1 --',
    "1; DELETE FROM computers",
  ];

  test.each(payloads)('payload %s returns no extra data and breaks nothing', async (p) => {
    const res = await agent.get('/computers').query({ q: p, location: p, status: p });
    expect(res.status).toBe(200);
    expect(rowCount(res.text)).toBe(0);
    expect(res.text).not.toMatch(/\$2[aby]\$/); // no password hashes leaked
    expect(db.prepare('SELECT COUNT(*) n FROM users').get().n).toBe(4);
    expect(db.prepare('SELECT COUNT(*) n FROM computers').get().n).toBe(20);
  });
});

describe('XSS attempts', () => {
  test('search text is escaped when echoed back into the form', async () => {
    const payload = '"><script>alert(1)</script>';
    const res = await agent.get('/computers').query({ q: payload });
    expect(res.text).not.toContain('<script>alert(1)');
    expect(res.text).toContain('&lt;script&gt;alert(1)');
  });

  test('a malicious computer name stored in the database is escaped on output', async () => {
    db.prepare("UPDATE computers SET name = ? WHERE id = 1").run('<img src=x onerror=alert(1)>');
    const res = await agent.get('/computers');
    expect(res.text).not.toContain('<img src=x');
    expect(res.text).toContain('&lt;img src=x onerror=alert(1)&gt;');
  });
});

// Logging hygiene: secrets must never appear in log output.
const { Writable } = require('stream');
const pino = require('pino');
const logger = require('../src/utils/logger');
const { buildApp, loggedInAgent, request, csrfFor, USER } = require('./helpers');

function captureLogs(fn) {
  const lines = [];
  const stream = new Writable({ write(chunk, _e, cb) { lines.push(chunk.toString()); cb(); } });
  const log = pino({ level: 'debug', redact: logger.redactConfig }, stream);
  fn(log);
  return lines.join('');
}

describe('log redaction', () => {
  test('cookies, authorization, passwords and session IDs are redacted', () => {
    const out = captureLogs((log) => {
      log.info({
        req: { headers: { cookie: 'lab.sid=s%3ASECRETSESSION', authorization: 'Bearer TOPSECRET' } },
        res: { headers: { 'set-cookie': ['lab.sid=ANOTHERSECRET'] } },
        password: 'hunter2-password',
        new_password: 'NewSecret-123',
        current_password: 'OldSecret-123',
        user: { password: 'nested-secret', password_hash: '$2b$12$hashhashhash' },
        sessionID: 'SESSIONIDVALUE',
      }, 'test line');
    });
    for (const secret of ['SECRETSESSION', 'TOPSECRET', 'ANOTHERSECRET', 'hunter2-password', 'NewSecret-123', 'OldSecret-123', 'nested-secret', '$2b$12$hashhashhash', 'SESSIONIDVALUE']) {
      expect(out).not.toContain(secret);
    }
    expect(out).toContain('[REDACTED]');
  });
});

describe('application output', () => {
  test('error pages never reveal stack traces, file paths or SQL', async () => {
    const { app, db } = buildApp();
    const agent = await loggedInAgent(app, USER);
    const pages = [
      await agent.get('/definitely-missing'),
      await agent.get('/admin/users'),
      await request(app).post('/login').type('form').send({}),
    ];
    for (const res of pages) {
      expect(res.text).not.toMatch(/node_modules|\.js:\d+|SqliteError|SELECT |at Object\./);
    }
    db.close();
  });

  test('malformed request bodies produce a clean error, not a crash', async () => {
    const { app, db } = buildApp();
    const agent = request.agent(app);
    const token = await csrfFor(agent, '/login');
    const res = await agent.post('/login').type('form').send(`_csrf=${token}&email=%E0%A4%A&password=%`);
    expect([400, 401]).toContain(res.status);
    const big = await request(app).post('/login').type('form').send('x=' + 'a'.repeat(20000));
    expect([403, 413, 400]).toContain(big.status);
    db.close();
  });
});

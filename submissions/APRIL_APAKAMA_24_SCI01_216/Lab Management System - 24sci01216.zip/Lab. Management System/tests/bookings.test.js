// Bookings: create, validate, overlap rules, list/filter, cancel, and IDOR attempts.
const { request, buildApp, loggedInAgent, submit, slot, userId, ADMIN, USER, USER2 } = require('./helpers');

let app, db;
beforeEach(() => ({ app, db } = buildApp()));
afterEach(() => db.close());

const book = (agent, fields) => submit(agent, '/bookings/new', '/bookings', fields);
const valid = (over = {}) => ({ computer_id: 1, ...slot(2, 10), purpose: 'CSC 407 project work', ...over });

describe('creating a booking', () => {
  test('valid booking is stored as pending for the logged-in user', async () => {
    const agent = await loggedInAgent(app, USER);
    const res = await book(agent, valid());
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/bookings');
    const row = db.prepare('SELECT * FROM bookings').get();
    expect(row.status).toBe('pending');
    expect(row.user_id).toBe(userId(db, USER));
    expect((await agent.get('/bookings')).text).toContain('Booking submitted');
  });

  test('a user_id sent in the form is ignored (cannot book as someone else)', async () => {
    const agent = await loggedInAgent(app, USER);
    await book(agent, valid({ user_id: userId(db, USER2), status: 'approved' }));
    const row = db.prepare('SELECT * FROM bookings').get();
    expect(row.user_id).toBe(userId(db, USER));
    expect(row.status).toBe('pending');
  });

  test.each([
    ['start in the past', () => slot(-1, 10)],
    ['end before start', () => ({ start: slot(2, 12).start, end: slot(2, 10).start })],
    ['longer than 4 hours', () => slot(2, 8, 300)],
    ['shorter than 15 minutes', () => slot(2, 8, 5)],
    ['more than 60 days ahead', () => slot(90, 10)],
    ['malformed date', () => ({ start: 'tomorrow', end: 'later' })],
  ])('rejects %s', async (_n, make) => {
    const agent = await loggedInAgent(app, USER);
    const res = await book(agent, valid(make()));
    expect(res.status).toBe(400);
    expect(db.prepare('SELECT COUNT(*) n FROM bookings').get().n).toBe(0);
  });

  test.each([
    ['unknown computer', { computer_id: 9999 }],
    ['computer under maintenance', { computer_id: 7 }],
    ['retired computer', { computer_id: 19 }],
    ['non-numeric computer id', { computer_id: 'abc' }],
    ['missing purpose', { purpose: '' }],
    ['HTML in purpose', { purpose: '<script>alert(1)</script>' }],
    ['purpose too long', { purpose: 'x'.repeat(201) }],
  ])('rejects %s', async (_n, over) => {
    const agent = await loggedInAgent(app, USER);
    const res = await book(agent, valid(over));
    expect(res.status).toBe(400);
    expect(db.prepare('SELECT COUNT(*) n FROM bookings').get().n).toBe(0);
  });

  test('cannot overlap an approved booking on the same computer', async () => {
    const s = slot(2, 10);
    db.prepare("INSERT INTO bookings (user_id, computer_id, start_time, end_time, purpose, status) VALUES (?, 1, ?, ?, 'other', 'approved')")
      .run(userId(db, USER2), new Date(s.start + ':00Z').toISOString(), new Date(s.end + ':00Z').toISOString());
    const agent = await loggedInAgent(app, USER);
    const res = await book(agent, valid());
    expect(res.status).toBe(400);
    expect(res.text).toContain('already booked');
  });

  test('cannot double-book yourself at the same time', async () => {
    const agent = await loggedInAgent(app, USER);
    expect((await book(agent, valid())).status).toBe(302);
    const res = await book(agent, valid({ computer_id: 2 }));
    expect(res.status).toBe(400);
    expect(res.text).toContain('overlaps');
  });

  test('an admin cannot use the user booking form (403)', async () => {
    const agent = await loggedInAgent(app, ADMIN);
    expect((await agent.get('/bookings/new')).status).toBe(403);
  });

  test('booking without a CSRF token is rejected', async () => {
    const agent = await loggedInAgent(app, USER);
    const res = await agent.post('/bookings').type('form').send(valid());
    expect(res.status).toBe(403);
    expect(db.prepare('SELECT COUNT(*) n FROM bookings').get().n).toBe(0);
  });

  test('stored XSS: a booking purpose cannot carry markup into the page', async () => {
    const agent = await loggedInAgent(app, USER);
    db.prepare("INSERT INTO bookings (user_id, computer_id, start_time, end_time, purpose) VALUES (?, 1, ?, ?, ?)")
      .run(userId(db, USER), new Date(Date.now() + 86400000).toISOString(), new Date(Date.now() + 90000000).toISOString(), '<script>alert(1)</script>');
    const res = await agent.get('/bookings');
    expect(res.text).not.toContain('<script>alert(1)');
    expect(res.text).toContain('&lt;script&gt;');
  });
});

describe('listing and filtering', () => {
  beforeEach(() => {
    const ins = db.prepare("INSERT INTO bookings (user_id, computer_id, start_time, end_time, purpose, status) VALUES (?, ?, ?, ?, ?, ?)");
    const t = (d) => new Date(Date.now() + d * 86400000).toISOString();
    ins.run(userId(db, USER), 1, t(1), t(1.04), 'my pending work', 'pending');
    ins.run(userId(db, USER), 2, t(2), t(2.04), 'my approved lecture', 'approved');
    ins.run(userId(db, USER2), 3, t(3), t(3.04), 'secret other user purpose', 'approved');
  });

  test('a user sees only their own bookings', async () => {
    const res = await (await loggedInAgent(app, USER)).get('/bookings');
    expect(res.text).toContain('my pending work');
    expect(res.text).toContain('my approved lecture');
    expect(res.text).not.toContain('secret other user purpose');
  });

  test('status filter and keyword search work', async () => {
    const agent = await loggedInAgent(app, USER);
    const a = await agent.get('/bookings?status=approved');
    expect(a.text).toContain('my approved lecture');
    expect(a.text).not.toContain('my pending work');
    const b = await agent.get('/bookings?q=lecture');
    expect(b.text).toContain('my approved lecture');
    expect(b.text).not.toContain('my pending work');
  });

  test("searching cannot reveal another user's bookings", async () => {
    const res = await (await loggedInAgent(app, USER)).get('/bookings?q=secret');
    expect(res.text).not.toContain('secret other user purpose');
  });

  test('SQL injection in the search box leaks nothing', async () => {
    const agent = await loggedInAgent(app, USER);
    const res = await agent.get('/bookings').query({ q: "' OR user_id != 0 --", status: "' OR 1=1 --" });
    expect(res.status).toBe(200);
    expect(res.text).not.toContain('secret other user purpose');
    expect(db.prepare('SELECT COUNT(*) n FROM bookings').get().n).toBe(3);
  });
});

describe('cancelling and IDOR', () => {
  let mine, theirs;
  beforeEach(() => {
    const ins = db.prepare("INSERT INTO bookings (user_id, computer_id, start_time, end_time, purpose, status) VALUES (?, ?, ?, ?, 'test purpose', 'approved')");
    const t = (d) => new Date(Date.now() + d * 86400000).toISOString();
    mine = Number(ins.run(userId(db, USER), 1, t(1), t(1.04)).lastInsertRowid);
    theirs = Number(ins.run(userId(db, USER2), 2, t(1), t(1.04)).lastInsertRowid);
  });
  const status = (id) => db.prepare('SELECT status FROM bookings WHERE id = ?').get(id).status;
  const cancel = (agent, id) => submit(agent, '/bookings', `/bookings/${id}/cancel`, {});

  test('a user can cancel their own booking', async () => {
    const res = await cancel(await loggedInAgent(app, USER), mine);
    expect(res.status).toBe(302);
    expect(status(mine)).toBe('cancelled');
  });

  test("IDOR: cancelling another user's booking gives 404 and changes nothing", async () => {
    const res = await cancel(await loggedInAgent(app, USER), theirs);
    expect(res.status).toBe(404);
    expect(status(theirs)).toBe('approved');
  });

  test('IDOR: a nonexistent id looks the same as someone else\'s (cannot probe ids)', async () => {
    const res = await cancel(await loggedInAgent(app, USER), 99999);
    expect(res.status).toBe(404);
  });

  test.each(['abc', '1;DROP TABLE bookings', '-1', '1.5'])('malformed id %s gives 404', async (bad) => {
    const res = await cancel(await loggedInAgent(app, USER), encodeURIComponent(bad));
    expect(res.status).toBe(404);
    expect(db.prepare('SELECT COUNT(*) n FROM bookings').get().n).toBe(2);
  });

  test('cancelling twice reports an error instead of failing silently', async () => {
    const agent = await loggedInAgent(app, USER);
    await cancel(agent, mine);
    await cancel(agent, mine);
    const page = await agent.get('/bookings');
    expect(page.text).toContain('can no longer be cancelled');
  });

  test('cancel without a CSRF token is rejected', async () => {
    const agent = await loggedInAgent(app, USER);
    const res = await agent.post(`/bookings/${mine}/cancel`).type('form').send({});
    expect(res.status).toBe(403);
    expect(status(mine)).toBe('approved');
  });

  test('anonymous visitors cannot cancel', async () => {
    const res = await request(app).post(`/bookings/${mine}/cancel`).type('form').send({});
    expect([302, 403]).toContain(res.status);
    expect(status(mine)).toBe('approved');
  });
});

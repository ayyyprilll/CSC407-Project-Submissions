// Error handling: 400, 403, 404, 429 and 500 pages are clean, and nothing internal leaks.
const { request, buildApp, loggedInAgent, csrfFor, login, USER } = require('./helpers');

const LEAKS = /node_modules|\.js:\d+|SqliteError|TypeError|ReferenceError|at Object\.|C:\\|\/home\/|stack/i;

describe('error pages', () => {
  test('404 for visitors and for logged-in users', async () => {
    const { app, db } = buildApp();
    const anon = await request(app).get('/nothing-here');
    expect(anon.status).toBe(404);
    expect(anon.text).toContain('Page not found');
    expect(anon.text).not.toMatch(LEAKS);
    const user = await loggedInAgent(app, USER);
    const res = await user.get('/nothing-here');
    expect(res.status).toBe(404);
    expect(res.text).toContain('Back to dashboard');
    db.close();
  });

  test('403 page for a forbidden admin URL', async () => {
    const { app, db } = buildApp();
    const res = await (await loggedInAgent(app, USER)).get('/admin/users');
    expect(res.status).toBe(403);
    expect(res.text).toContain('Access denied');
    expect(res.text).not.toMatch(LEAKS);
    db.close();
  });

  test('500 page is generic when something breaks internally', async () => {
    const { app, db } = buildApp();
    const user = await loggedInAgent(app, USER);
    // Simulate a failing database by replacing a method the route uses.
    const original = db.prepare.bind(db);
    db.prepare = (sql) => { if (/FROM computers/.test(sql)) throw new Error('SQLITE_IOERR: secret internal detail at /srv/app/data.db'); return original(sql); };
    const res = await user.get('/computers');
    expect(res.status).toBe(500);
    expect(res.text).toContain('Something went wrong');
    expect(res.text).not.toMatch(LEAKS);
    expect(res.text).not.toContain('secret internal detail');
    expect(res.text).not.toContain('/srv/app');
    db.prepare = original;
    db.close();
  });

  test('the health check reports unavailable (503) without details if the database fails', async () => {
    const { app, db } = buildApp();
    db.close();
    const res = await request(app).get('/health');
    expect(res.status).toBe(503);
    expect(res.body).toEqual({ status: 'unavailable' });
  });

  test('429 page after too many attempts', async () => {
    const { app, db } = buildApp({ loginLimit: 1 });
    const agent = request.agent(app);
    await login(agent, { email: 'x@lab.local', password: 'WrongPassword1' });
    const res = await login(agent, { email: 'x@lab.local', password: 'WrongPassword1' });
    expect(res.status).toBe(429);
    expect(res.text).toContain('Too many requests');
    db.close();
  });

  test('403 page for a failed CSRF check explains how to recover', async () => {
    const { app, db } = buildApp();
    const res = await request(app).post('/login').type('form').send(USER);
    expect(res.status).toBe(403);
    expect(res.text).toContain('Form expired');
    db.close();
  });

  test('unsupported methods on real URLs are treated as not found', async () => {
    const { app, db } = buildApp();
    const agent = request.agent(app);
    const token = await csrfFor(agent, '/login');
    for (const m of ['put', 'delete', 'patch']) {
      const res = await agent[m]('/login').type('form').send({ _csrf: token });
      expect([403, 404]).toContain(res.status);
    }
    db.close();
  });

  test('malformed URL encoding does not crash the server', async () => {
    const { app, db } = buildApp();
    const res = await request(app).get('/computers?q=%E0%A4%A');
    expect([302, 400, 200]).toContain(res.status);
    const res2 = await request(app).get('/%E0%A4%A');
    expect([400, 404]).toContain(res2.status);
    expect(res2.text).not.toMatch(LEAKS);
    db.close();
  });
});

// Production configuration: behaviour that only switches on when NODE_ENV=production.
// Each test loads the app in an isolated module registry with production env vars.
const request = require('supertest');

const PROD_ENV = {
  NODE_ENV: 'production',
  SESSION_SECRET: 'a'.repeat(48),
  ADMIN_PASSWORD: 'Production-Admin-Pass-1',
  ADMIN_EMAIL: 'admin@lab.local',
  SEED_USER_PASSWORD: '',
  LOG_LEVEL: 'silent', // keep test output readable
};

function withEnv(env, fn) {
  const saved = { ...process.env };
  Object.assign(process.env, env);
  try { return fn(); } finally {
    for (const k of Object.keys(env)) { if (saved[k] === undefined) delete process.env[k]; else process.env[k] = saved[k]; }
  }
}

function loadProdApp() {
  return withEnv(PROD_ENV, () => {
    let result;
    jest.isolateModules(() => {
      const { openDb } = require('../src/db/connection');
      const { seedIfEmpty } = require('../src/db/seed');
      const { createApp } = require('../src/app');
      const db = openDb(':memory:');
      seedIfEmpty(db, { quiet: true });
      result = { db, app: createApp(db) };
    });
    return result;
  });
}

const HTTPS = { 'X-Forwarded-Proto': 'https', 'X-Forwarded-For': '203.0.113.7' };

describe('startup safety checks', () => {
  test('refuses to start without a strong SESSION_SECRET', () => {
    expect(() => withEnv({ ...PROD_ENV, SESSION_SECRET: 'short' }, () => jest.isolateModules(() => require('../src/config')))).toThrow(/SESSION_SECRET/);
  });
  test('refuses to start without ADMIN_PASSWORD', () => {
    expect(() => withEnv({ ...PROD_ENV, ADMIN_PASSWORD: '' }, () => jest.isolateModules(() => require('../src/config')))).toThrow(/ADMIN_PASSWORD/);
  });
});

describe('production behaviour (simulated HTTPS proxy)', () => {
  let ctx;
  beforeAll(() => { ctx = loadProdApp(); });
  afterAll(() => ctx.db.close());

  test('seeds the admin from the environment, and skips sample users without a shared password', () => {
    expect(ctx.db.prepare('SELECT COUNT(*) n FROM users').get().n).toBe(1);
    expect(ctx.db.prepare('SELECT COUNT(*) n FROM computers').get().n).toBe(20);
  });

  test('sends HSTS and upgrade-insecure-requests', async () => {
    const res = await request(ctx.app).get('/login').set(HTTPS);
    expect(res.headers['strict-transport-security']).toMatch(/max-age=\d+/);
    expect(res.headers['content-security-policy']).toContain('upgrade-insecure-requests');
  });

  test('session and CSRF cookies are Secure, HttpOnly and SameSite', async () => {
    const res = await request(ctx.app).get('/login').set(HTTPS);
    const cookies = res.headers['set-cookie'];
    const sid = cookies.find((c) => c.startsWith('lab.sid='));
    const csrf = cookies.find((c) => c.startsWith('__Host-lab.csrf='));
    expect(sid).toMatch(/Secure/i);
    expect(sid).toMatch(/HttpOnly/i);
    expect(sid).toMatch(/SameSite=Lax/i);
    expect(csrf).toMatch(/Secure/i);
  });

  // The test client talks plain HTTP to the app, so it would (correctly) refuse to send Secure
  // cookies back. A real browser uses HTTPS, so here we replay the cookies by hand.
  async function loginOverSimulatedHttps(password) {
    const page = await request(ctx.app).get('/login').set(HTTPS);
    const cookie = page.headers['set-cookie'].map((c) => c.split(';')[0]).join('; ');
    const token = page.text.match(/name="_csrf" value="([^"]+)"/)[1];
    return request(ctx.app).post('/login').set(HTTPS).set('Cookie', cookie).type('form')
      .send({ _csrf: token, email: 'admin@lab.local', password });
  }

  test('trust proxy: the audit log records the real client IP, not the proxy', async () => {
    await loginOverSimulatedHttps('wrong-password-1');
    expect(ctx.db.prepare("SELECT ip_address FROM audit_logs WHERE action = 'login_failed'").get().ip_address).toBe('203.0.113.7');
  });

  test('admin can log in with the environment password', async () => {
    const res = await loginOverSimulatedHttps(PROD_ENV.ADMIN_PASSWORD);
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/dashboard');
  });

  test('health check works', async () => {
    const res = await request(ctx.app).get('/health').set(HTTPS);
    expect(res.body).toEqual({ status: 'ok' });
  });
});

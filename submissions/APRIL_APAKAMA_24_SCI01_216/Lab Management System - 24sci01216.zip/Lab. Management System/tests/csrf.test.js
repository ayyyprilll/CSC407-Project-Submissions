// CSRF: state-changing requests without a valid token must be rejected.
const { request, buildApp, csrfFor, loggedInAgent, USER } = require('./helpers');

let app, db;
beforeEach(() => ({ app, db } = buildApp()));
afterEach(() => db.close());

describe('CSRF protection', () => {
  test('login POST without a token is rejected with 403', async () => {
    const res = await request(app).post('/login').type('form').send(USER);
    expect(res.status).toBe(403);
  });

  test('register POST without a token is rejected and creates nothing', async () => {
    const before = db.prepare('SELECT COUNT(*) n FROM users').get().n;
    const res = await request(app).post('/register').type('form').send({
      full_name: 'Evil Bot', email: 'evil@x.co', password: 'Password123', confirm_password: 'Password123',
    });
    expect(res.status).toBe(403);
    expect(db.prepare('SELECT COUNT(*) n FROM users').get().n).toBe(before);
  });

  test('a forged token value is rejected', async () => {
    const agent = request.agent(app);
    await agent.get('/login');
    const res = await agent.post('/login').type('form').send({ _csrf: 'forged-token', ...USER });
    expect(res.status).toBe(403);
  });

  test('a token from one session cannot be used in another', async () => {
    const attackerToken = await csrfFor(request.agent(app), '/login');
    const victim = request.agent(app);
    await victim.get('/login');
    const res = await victim.post('/login').type('form').send({ _csrf: attackerToken, ...USER });
    expect(res.status).toBe(403);
  });

  test('logout without a token is rejected and the user stays logged in', async () => {
    const agent = await loggedInAgent(app, USER);
    expect((await agent.post('/logout').type('form').send({})).status).toBe(403);
    expect((await agent.get('/dashboard')).status).toBe(200);
  });

  test('the CSRF error page does not leak internals', async () => {
    const res = await request(app).post('/login').type('form').send(USER);
    expect(res.text).toContain('Form expired');
    expect(res.text).not.toMatch(/EBADCSRFTOKEN|node_modules|at .*\.js:\d+/);
  });
});

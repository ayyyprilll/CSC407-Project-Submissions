// Rate limiting: too many login attempts from one IP are refused with 429.
const { buildApp, login, request, USER } = require('./helpers');

describe('rate limiting', () => {
  test('login endpoint returns 429 after the limit is exceeded', async () => {
    const { app, db } = buildApp({ loginLimit: 3 });
    const agent = request.agent(app);
    const statuses = [];
    for (let i = 0; i < 5; i++) {
      statuses.push((await login(agent, { email: 'nobody@lab.local', password: 'WrongPassword1' })).status);
    }
    expect(statuses.slice(0, 3)).toEqual([401, 401, 401]);
    expect(statuses.slice(3)).toEqual([429, 429]);
    db.close();
  });

  test('a blocked client cannot log in even with the right password', async () => {
    const { app, db } = buildApp({ loginLimit: 2 });
    const agent = request.agent(app);
    await login(agent, { email: 'x@lab.local', password: 'WrongPassword1' });
    await login(agent, { email: 'x@lab.local', password: 'WrongPassword1' });
    expect((await login(agent, USER)).status).toBe(429);
    db.close();
  });

  test('registration is limited per IP', async () => {
    const { app, db } = buildApp({ registerLimit: 2 });
    const agent = request.agent(app);
    const codes = [];
    for (let i = 0; i < 3; i++) {
      const page = await agent.get('/register');
      const token = page.text.match(/name="_csrf" value="([^"]+)"/)[1];
      const res = await agent.post('/register').type('form').send({
        _csrf: token, full_name: 'Test User', email: `u${i}@lab.local`, password: 'GoodPassw0rd1', confirm_password: 'GoodPassw0rd1',
      });
      codes.push(res.status);
    }
    expect(codes).toEqual([302, 302, 429]);
    db.close();
  });

  test('the rate-limit page is a clean error with no internals', async () => {
    const { app, db } = buildApp({ loginLimit: 1 });
    const agent = request.agent(app);
    await login(agent, { email: USER.email, password: 'WrongPassword1' });
    const res = await login(agent, { email: USER.email, password: 'WrongPassword1' });
    expect(res.status).toBe(429);
    expect(res.text).toContain('Too many requests');
    expect(res.text).not.toMatch(/node_modules|at .*\.js:\d+/);
    db.close();
  });
});

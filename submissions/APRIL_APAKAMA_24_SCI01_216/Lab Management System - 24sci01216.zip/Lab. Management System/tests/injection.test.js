// Hostile input on every kind of entry point: SQL injection and XSS payloads.
const { request, buildApp, csrfFor, loggedInAgent, submit, slot, userId, USER, ADMIN } = require('./helpers');

let app, db;
beforeEach(() => ({ app, db } = buildApp()));
afterEach(() => db.close());

const SQLI = [
  "' OR '1'='1",
  "' OR 1=1 --",
  "admin@lab.local'--",
  "'; DROP TABLE users; --",
  "' UNION SELECT password_hash FROM users --",
  '") OR ("1"="1',
  "1; UPDATE users SET role='admin'",
];
const XSS = [
  '<script>alert(1)</script>',
  '"><script>alert(1)</script>',
  "<img src=x onerror=alert('x')>",
  "'><svg onload=alert(1)>",
  'javascript:alert(1)',
];
const intact = () => {
  expect(db.prepare('SELECT COUNT(*) n FROM users').get().n).toBe(4);
  expect(db.prepare("SELECT COUNT(*) n FROM users WHERE role = 'admin'").get().n).toBe(1);
};

describe('SQL injection through login', () => {
  test.each(SQLI)('email payload %s is refused', async (p) => {
    const agent = request.agent(app);
    const token = await csrfFor(agent, '/login');
    const res = await agent.post('/login').type('form').send({ _csrf: token, email: p, password: 'whatever123' });
    expect([400, 401]).toContain(res.status);
    expect(res.headers['set-cookie'] || []).not.toEqual(expect.arrayContaining([expect.stringMatching(/lab\.sid=.*userId/)]));
    intact();
  });

  test.each(SQLI)('password payload %s does not bypass authentication', async (p) => {
    const agent = request.agent(app);
    const token = await csrfFor(agent, '/login');
    const res = await agent.post('/login').type('form').send({ _csrf: token, email: USER.email, password: p });
    expect(res.status).toBe(401);
    expect((await agent.get('/dashboard')).status).toBe(302);
    intact();
  });
});

describe('SQL injection through forms and URLs', () => {
  test.each(SQLI)('registration fields with %s create no account and break nothing', async (p) => {
    const agent = request.agent(app);
    const token = await csrfFor(agent, '/register');
    const res = await agent.post('/register').type('form').send({ _csrf: token, full_name: p, email: p, password: p, confirm_password: p });
    expect(res.status).toBe(400);
    intact();
  });

  test.each(SQLI)('booking purpose %s is rejected or stored literally, never executed', async (p) => {
    const agent = await loggedInAgent(app, USER);
    await submit(agent, '/bookings/new', '/bookings', { computer_id: 1, ...slot(2, 10), purpose: p });
    intact();
    const row = db.prepare('SELECT purpose FROM bookings').get();
    if (row) expect(row.purpose).toBe(p);
  });

  test.each(SQLI)('URL id %s cannot reach SQL', async (p) => {
    const agent = await loggedInAgent(app, ADMIN);
    for (const url of [`/admin/computers/${encodeURIComponent(p)}/edit`, `/bookings/${encodeURIComponent(p)}/cancel`]) {
      const res = await agent.get(url);
      expect([404, 403, 200, 302]).toContain(res.status);
      expect(res.status).not.toBe(500);
    }
    intact();
  });

  test('second-order injection: hostile text saved earlier is still safe when read back', async () => {
    const hostile = "x'); DROP TABLE bookings; --";
    db.prepare('UPDATE computers SET name = ? WHERE id = 1').run(hostile);
    const agent = await loggedInAgent(app, USER);
    expect((await agent.get('/computers')).status).toBe(200);
    expect((await agent.get('/computers?q=DROP')).status).toBe(200);
    expect(db.prepare("SELECT COUNT(*) n FROM sqlite_master WHERE name = 'bookings'").get().n).toBe(1);
  });
});

describe('XSS: payloads are rejected or escaped everywhere they could be shown', () => {
  test.each(XSS)('login form echoes the email %s only in escaped form', async (p) => {
    const agent = request.agent(app);
    const token = await csrfFor(agent, '/login');
    const res = await agent.post('/login').type('form').send({ _csrf: token, email: p, password: 'x' });
    expect(res.text).not.toMatch(/<script>alert|<img src=x onerror|<svg onload/);
  });

  test.each(XSS)('registration form %s is refused and echoed only escaped', async (p) => {
    const agent = request.agent(app);
    const token = await csrfFor(agent, '/register');
    const res = await agent.post('/register').type('form').send({ _csrf: token, full_name: p, email: p, password: 'GoodPassw0rd1', confirm_password: 'GoodPassw0rd1' });
    expect(res.status).toBe(400);
    expect(res.text).not.toMatch(/<script>alert|<img src=x onerror|<svg onload/);
  });

  test.each(XSS)('profile name %s is refused', async (p) => {
    const agent = await loggedInAgent(app, USER);
    const res = await submit(agent, '/profile', '/profile', { full_name: p });
    expect(res.status).toBe(400);
    expect(res.text).not.toMatch(/<script>alert|<img src=x onerror|<svg onload/);
  });

  test.each(XSS)('fault description %s is refused', async (p) => {
    const agent = await loggedInAgent(app, USER);
    const res = await submit(agent, '/faults/new', '/faults', { computer_id: 1, severity: 'low', description: p });
    if (/[<>]/.test(p)) expect(res.status).toBe(400);
    expect(res.text).not.toMatch(/<script>alert|<img src=x onerror|<svg onload/);
  });

  test('values planted directly in the database are escaped on every page that shows them', async () => {
    const bad = '<script>alert(1)</script>';
    const id = userId(db, USER);
    db.prepare('UPDATE users SET full_name = ? WHERE id = ?').run(bad, id);
    db.prepare("UPDATE computers SET name = ?, location = ?, specs = ? WHERE id = 1").run(bad, bad, bad);
    db.prepare("INSERT INTO bookings (user_id, computer_id, start_time, end_time, purpose) VALUES (?, 1, ?, ?, ?)")
      .run(id, new Date(Date.now() + 86400000).toISOString(), new Date(Date.now() + 90000000).toISOString(), bad);
    db.prepare("INSERT INTO fault_reports (computer_id, reported_by, description, severity) VALUES (1, ?, ?, 'low')").run(id, bad);
    db.prepare("INSERT INTO audit_logs (user_id, action, details) VALUES (?, 'login_failed', ?)").run(id, bad);

    const user = await loggedInAgent(app, USER);
    const admin = await loggedInAgent(app, ADMIN);
    const pages = [
      [user, '/dashboard'], [user, '/computers'], [user, '/bookings'], [user, '/profile'], [user, '/bookings/new'], [user, '/faults/new'],
      [admin, '/dashboard'], [admin, '/admin/computers'], [admin, '/admin/bookings'], [admin, '/admin/faults'], [admin, '/admin/users'], [admin, '/admin/audit'],
    ];
    for (const [agent, url] of pages) {
      const res = await agent.get(url);
      expect(res.status).toBe(200);
      expect(res.text).not.toContain('<script>alert(1)</script>');
    }
  });

  test('every response carries a CSP that blocks inline script even if escaping failed', async () => {
    const res = await request(app).get('/login');
    expect(res.headers['content-security-policy']).toMatch(/script-src 'self'(;|$)/);
  });
});

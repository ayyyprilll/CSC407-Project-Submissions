// Fault reports and the profile / change-password pages.
const { request, buildApp, loggedInAgent, submit, login, userId, USER, USER2 } = require('./helpers');

let app, db;
beforeEach(() => ({ app, db } = buildApp()));
afterEach(() => db.close());

describe('fault reports', () => {
  const report = (agent, f) => submit(agent, '/faults/new', '/faults', f);
  const ok = { computer_id: 3, severity: 'high', description: 'Screen flickers and goes black.' };

  test('a logged-in user can report a fault', async () => {
    const agent = await loggedInAgent(app, USER);
    const res = await report(agent, ok);
    expect(res.status).toBe(302);
    const row = db.prepare('SELECT * FROM fault_reports').get();
    expect(row).toMatchObject({ computer_id: 3, severity: 'high', status: 'open', reported_by: userId(db, USER) });
  });

  test('reported_by cannot be spoofed from the form', async () => {
    const agent = await loggedInAgent(app, USER);
    await report(agent, { ...ok, reported_by: userId(db, USER2), status: 'resolved' });
    const row = db.prepare('SELECT * FROM fault_reports').get();
    expect(row.reported_by).toBe(userId(db, USER));
    expect(row.status).toBe('open');
  });

  test.each([
    ['bad severity', { severity: 'catastrophic' }],
    ['unknown computer', { computer_id: 4242 }],
    ['retired computer', { computer_id: 19 }],
    ['empty description', { description: '' }],
    ['HTML in description', { description: '<img src=x onerror=alert(1)>' }],
    ['description too long', { description: 'y'.repeat(1001) }],
  ])('rejects %s', async (_n, over) => {
    const res = await report(await loggedInAgent(app, USER), { ...ok, ...over });
    expect(res.status).toBe(400);
    expect(db.prepare('SELECT COUNT(*) n FROM fault_reports').get().n).toBe(0);
  });

  test('requires login and a CSRF token', async () => {
    expect((await request(app).get('/faults/new')).status).toBe(302);
    const agent = await loggedInAgent(app, USER);
    expect((await agent.post('/faults').type('form').send(ok)).status).toBe(403);
  });
});

describe('profile', () => {
  test('a user can change their own name', async () => {
    const agent = await loggedInAgent(app, USER);
    const res = await submit(agent, '/profile', '/profile', { full_name: 'Amara N. Okafor' });
    expect(res.status).toBe(302);
    expect(db.prepare('SELECT full_name FROM users WHERE id = ?').get(userId(db, USER)).full_name).toBe('Amara N. Okafor');
  });

  test('mass assignment: role, email and id fields in the request are ignored', async () => {
    const agent = await loggedInAgent(app, USER);
    await submit(agent, '/profile', '/profile', {
      full_name: 'Amara Okafor', role: 'admin', email: 'hacker@evil.test', id: 1, is_active: 0,
    });
    const row = db.prepare('SELECT * FROM users WHERE id = ?').get(userId(db, USER));
    expect(row.role).toBe('user');
    expect(row.email).toBe(USER.email);
    expect(row.is_active).toBe(1);
  });

  test("another user's profile cannot be reached or edited (no id parameter exists)", async () => {
    const agent = await loggedInAgent(app, USER);
    await submit(agent, '/profile', '/profile?id=1&user_id=1', { full_name: 'Hijacked Name', user_id: 1 });
    expect(db.prepare("SELECT full_name FROM users WHERE role = 'admin'").get().full_name).toBe('Lab Administrator');
    expect((await agent.get('/profile/1')).status).toBe(404);
  });

  test('invalid names are rejected', async () => {
    const agent = await loggedInAgent(app, USER);
    const res = await submit(agent, '/profile', '/profile', { full_name: '<script>alert(1)</script>' });
    expect(res.status).toBe(400);
    expect(res.text).not.toContain('<script>alert(1)');
  });

  test('profile page needs login', async () => {
    expect((await request(app).get('/profile')).status).toBe(302);
  });
});

describe('change password', () => {
  const NEW = 'BrandNewPassw0rd';
  const change = (agent, f) => submit(agent, '/profile', '/profile/password', f);

  test('success: new password works, old one does not, hash changed', async () => {
    const before = db.prepare('SELECT password_hash h FROM users WHERE id = ?').get(userId(db, USER)).h;
    const agent = await loggedInAgent(app, USER);
    const res = await change(agent, { current_password: USER.password, new_password: NEW, confirm_password: NEW });
    expect(res.status).toBe(302);
    expect(db.prepare('SELECT password_hash h FROM users WHERE id = ?').get(userId(db, USER)).h).not.toBe(before);
    expect((await login(request.agent(app), { email: USER.email, password: NEW })).status).toBe(302);
    expect((await login(request.agent(app), USER)).status).toBe(401);
    expect((await agent.get('/dashboard')).status).toBe(200); // still logged in here
  });

  test('other sessions of the same account are ended', async () => {
    const other = await loggedInAgent(app, USER);
    expect((await other.get('/dashboard')).status).toBe(200);
    const agent = await loggedInAgent(app, USER);
    await change(agent, { current_password: USER.password, new_password: NEW, confirm_password: NEW });
    const res = await other.get('/dashboard');
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/login');
  });

  test('wrong current password is refused and nothing changes', async () => {
    const before = db.prepare('SELECT password_hash h FROM users WHERE id = ?').get(userId(db, USER)).h;
    const res = await change(await loggedInAgent(app, USER), { current_password: 'WrongPassword1', new_password: NEW, confirm_password: NEW });
    expect(res.status).toBe(400);
    expect(db.prepare('SELECT password_hash h FROM users WHERE id = ?').get(userId(db, USER)).h).toBe(before);
  });

  test.each([
    ['too short', { new_password: 'Ab1', confirm_password: 'Ab1' }],
    ['no number', { new_password: 'NoNumbersHereAtAll', confirm_password: 'NoNumbersHereAtAll' }],
    ['mismatch', { confirm_password: 'SomethingElse123' }],
    ['same as current', { new_password: USER.password, confirm_password: USER.password }],
  ])('rejects a new password that is %s', async (_n, over) => {
    const res = await change(await loggedInAgent(app, USER), { current_password: USER.password, new_password: NEW, confirm_password: NEW, ...over });
    expect(res.status).toBe(400);
    expect((await login(request.agent(app), USER)).status).toBe(302);
  });

  test('requires a CSRF token', async () => {
    const agent = await loggedInAgent(app, USER);
    const res = await agent.post('/profile/password').type('form').send({ current_password: USER.password, new_password: NEW, confirm_password: NEW });
    expect(res.status).toBe(403);
  });

  test('is recorded in the audit log without the password', async () => {
    await change(await loggedInAgent(app, USER), { current_password: USER.password, new_password: NEW, confirm_password: NEW });
    const rows = JSON.stringify(db.prepare('SELECT * FROM audit_logs').all());
    expect(rows).toContain('password_changed');
    expect(rows).not.toContain(NEW);
    expect(rows).not.toContain(USER.password);
  });
});

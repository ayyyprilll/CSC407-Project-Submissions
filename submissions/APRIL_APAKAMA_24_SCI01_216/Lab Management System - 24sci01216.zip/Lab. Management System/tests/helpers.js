// Shared test helpers.
const request = require('supertest');
const { openDb } = require('../src/db/connection');
const { seedIfEmpty } = require('../src/db/seed');
const { createApp } = require('../src/app');

const ADMIN = { email: 'admin@lab.local', password: 'Admin-Test-Pass-1' };
const USER = { email: 'amara@lab.local', password: 'User-Test-Pass-1' };
const USER2 = { email: 'tunde@lab.local', password: 'User-Test-Pass-1' };

function buildApp(opts = {}) {
  const db = openDb(':memory:');
  seedIfEmpty(db);
  return { db, app: createApp(db, opts) };
}

// Pulls the hidden CSRF token out of a rendered form.
function extractCsrf(html) {
  const m = html.match(/name="_csrf" value="([^"]+)"/);
  if (!m) throw new Error('No CSRF token found in page');
  return m[1];
}

// Fetches a page with the agent (so cookies are kept) and returns its CSRF token.
async function csrfFor(agent, path = '/login') {
  const res = await agent.get(path);
  return extractCsrf(res.text);
}

// Logs in with a real form submission (including CSRF token). Returns the agent response.
async function login(agent, creds) {
  const token = await csrfFor(agent, '/login');
  return agent.post('/login').type('form').send({ _csrf: token, email: creds.email, password: creds.password });
}

// Returns a supertest agent already logged in as `creds`.
async function loggedInAgent(app, creds) {
  const agent = request.agent(app);
  const res = await login(agent, creds);
  if (res.status !== 302) throw new Error(`Login helper failed with ${res.status}`);
  return agent;
}

// Submits a form the way a browser would: load a page first to get a CSRF token, then POST.
async function submit(agent, formPage, path, fields) {
  const token = await csrfFor(agent, formPage);
  return agent.post(path).type('form').send({ _csrf: token, ...fields });
}

// "YYYY-MM-DDTHH:mm" in UTC, `days` days from now at a fixed hour (what datetime-local sends).
function slot(days, hour, minutes = 60) {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() + days);
  d.setUTCHours(hour, 0, 0, 0);
  const end = new Date(d.getTime() + minutes * 60000);
  const f = (x) => x.toISOString().slice(0, 16);
  return { start: f(d), end: f(end) };
}

const userId = (db, creds) => db.prepare('SELECT id FROM users WHERE email = ?').get(creds.email).id;

module.exports = { request, buildApp, extractCsrf, csrfFor, login, loggedInAgent, submit, slot, userId, ADMIN, USER, USER2 };

Put your usability and mobile test screenshots here, named as listed in TESTING.md section 5.


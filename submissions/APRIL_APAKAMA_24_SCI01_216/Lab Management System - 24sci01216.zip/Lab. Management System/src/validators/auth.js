// Server-side validation rules for the auth forms (express-validator).
// Approach: VALIDATE on the way in (allow-list of acceptable characters, length limits, types),
// ESCAPE on the way out (EJS <%= %> escapes HTML). We do not "clean" values by escaping them on
// input, because that would store mangled data and cause double-escaping.
const { body } = require('express-validator');
const { passwordProblems } = require('../utils/password');

// Letters (any language), spaces, apostrophes, hyphens, full stops. No < > & " or digits.
const NAME_RE = /^[\p{L}][\p{L} .'’-]{1,99}$/u;

const registerRules = [
  body('full_name')
    .isString().withMessage('Full name is required.').bail()
    .trim()
    .matches(NAME_RE).withMessage('Full name must be 2-100 characters: letters, spaces, apostrophes, hyphens or full stops.'),
  body('email')
    .isString().withMessage('Email is required.').bail()
    .trim().toLowerCase()
    .isLength({ max: 254 }).withMessage('Email is too long.')
    .isEmail().withMessage('Enter a valid email address.'),
  body('password')
    .isString().withMessage('Password is required.').bail()
    .custom((value, { req }) => {
      const problems = passwordProblems(value, req.body.email);
      if (problems.length) throw new Error(problems[0]);
      return true;
    }),
  body('confirm_password')
    .custom((value, { req }) => value === req.body.password).withMessage('Passwords do not match.'),
];

// Login uses loose rules on purpose: any failure is reported with the SAME generic message.
const loginRules = [
  body('email').isString().bail().trim().toLowerCase().isEmail().isLength({ max: 254 }),
  body('password').isString().bail().isLength({ min: 1, max: 128 }),
];

module.exports = { registerRules, loginRules, NAME_RE };

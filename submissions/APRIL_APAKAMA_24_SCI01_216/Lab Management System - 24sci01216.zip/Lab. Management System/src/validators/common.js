// Reusable validation pieces.
const { body } = require('express-validator');

// Free-text fields (purpose, fault description ...). Steps:
//  1. must be a string (blocks arrays/objects sent as ?a[]=1 style tricks)
//  2. strip invisible control characters
//  3. trim, check length
//  4. reject < and > : no legitimate use here, and it removes the raw material for HTML injection.
//     (Output is ALSO escaped by EJS - this is the second layer, not the only one.)
function freeText(field, { min, max, label }) {
  return body(field)
    .isString().withMessage(`${label} is required.`).bail()
    .customSanitizer((v) => v.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, ''))
    .trim()
    .isLength({ min, max }).withMessage(`${label} must be ${min}-${max} characters.`).bail()
    .not().matches(/[<>]/).withMessage(`${label} must not contain < or >.`);
}

// A database id sent from a form: a positive whole number.
function idField(field, label) {
  return body(field)
    .isString().withMessage(`${label} is required.`).bail()
    .isInt({ min: 1, max: 1000000000 }).withMessage(`Choose a valid ${label.toLowerCase()}.`)
    .toInt();
}

module.exports = { freeText, idField };

// Validation for the fault report form.
const { body } = require('express-validator');
const { freeText, idField } = require('./common');
const { SEVERITIES } = require('../models/faults');

const faultRules = [
  idField('computer_id', 'Computer'),
  body('severity').isString().bail().isIn(SEVERITIES).withMessage('Choose a severity.'),
  freeText('description', { min: 5, max: 1000, label: 'Description' }),
];

module.exports = { faultRules };

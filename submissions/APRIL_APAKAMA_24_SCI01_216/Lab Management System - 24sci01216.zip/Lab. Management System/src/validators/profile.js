// Validation for the profile and change-password forms.
const { body } = require('express-validator');
const { NAME_RE } = require('./auth');
const { passwordProblems } = require('../utils/password');

const profileRules = [
  body('full_name')
    .isString().withMessage('Full name is required.').bail()
    .trim()
    .matches(NAME_RE).withMessage('Full name must be 2-100 characters: letters, spaces, apostrophes, hyphens or full stops.'),
];

const passwordChangeRules = [
  body('current_password').isString().withMessage('Enter your current password.').bail()
    .isLength({ min: 1, max: 128 }).withMessage('Enter your current password.'),
  body('new_password')
    .isString().withMessage('Enter a new password.').bail()
    .custom((value, { req }) => {
      const problems = passwordProblems(value, req.user.email);
      if (problems.length) throw new Error(problems[0]);
      if (value === req.body.current_password) throw new Error('The new password must be different from the current one.');
      return true;
    }),
  body('confirm_password').custom((value, { req }) => value === req.body.new_password).withMessage('Passwords do not match.'),
];

module.exports = { profileRules, passwordChangeRules };

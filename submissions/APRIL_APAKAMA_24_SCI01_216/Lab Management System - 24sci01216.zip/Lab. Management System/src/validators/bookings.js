// Validation for the booking form.
const { body } = require('express-validator');
const { freeText, idField } = require('./common');

const DT_RE = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/; // what <input type="datetime-local"> sends
const MIN_MINUTES = 15;
const MAX_MINUTES = 240;   // 4 hours
const MAX_DAYS_AHEAD = 60;

// Times are entered and stored in UTC (the pages say so), so there is no time-zone guessing.
function parseSlot(start, end) {
  if (!DT_RE.test(start || '') || !DT_RE.test(end || '')) return { error: 'Enter a valid start and end time.' };
  const s = new Date(start + ':00Z');
  const e = new Date(end + ':00Z');
  if (Number.isNaN(s.getTime()) || Number.isNaN(e.getTime())) return { error: 'Enter a valid start and end time.' };
  const now = Date.now();
  if (s.getTime() < now) return { error: 'The start time must be in the future.' };
  if (s.getTime() > now + MAX_DAYS_AHEAD * 86400000) return { error: `You can only book up to ${MAX_DAYS_AHEAD} days ahead.` };
  const minutes = (e - s) / 60000;
  if (minutes <= 0) return { error: 'The end time must be after the start time.' };
  if (minutes < MIN_MINUTES) return { error: `A booking must be at least ${MIN_MINUTES} minutes.` };
  if (minutes > MAX_MINUTES) return { error: `A booking can be at most ${MAX_MINUTES / 60} hours.` };
  return { startIso: s.toISOString(), endIso: e.toISOString() };
}

const bookingRules = [
  idField('computer_id', 'Computer'),
  body('start').isString().withMessage('Start time is required.'),
  body('end')
    .isString().withMessage('End time is required.').bail()
    .custom((end, { req }) => {
      const slot = parseSlot(req.body.start, end);
      if (slot.error) throw new Error(slot.error);
      return true;
    }),
  freeText('purpose', { min: 3, max: 200, label: 'Purpose' }),
];

module.exports = { bookingRules, parseSlot };

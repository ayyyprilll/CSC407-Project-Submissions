// Validation for the admin forms.
const { body } = require('express-validator');
const { freeText } = require('./common');
const { STATUSES } = require('../models/computers');
const faults = require('../models/faults');
const { ROLES } = require('../models/adminUsers');

const computerRules = [
  body('asset_tag')
    .isString().withMessage('Asset tag is required.').bail()
    .trim().toUpperCase()
    .matches(/^[A-Z0-9][A-Z0-9._-]{1,29}$/).withMessage('Asset tag must be 2-30 characters: letters, numbers, dot, dash or underscore.'),
  freeText('name', { min: 2, max: 100, label: 'Name' }),
  freeText('location', { min: 2, max: 100, label: 'Location' }),
  body('specs')
    .optional({ values: 'falsy' })
    .isString().withMessage('Specs must be text.').bail()
    .trim().isLength({ max: 300 }).withMessage('Specs must be 300 characters or fewer.').bail()
    .not().matches(/[<>]/).withMessage('Specs must not contain < or >.'),
  body('status').isString().bail().isIn(STATUSES).withMessage('Choose a valid status.'),
];

const faultStatusRules = [
  body('status').isString().bail().isIn(faults.STATUSES).withMessage('Choose a valid status.'),
];

const roleRules = [
  body('role').isString().bail().isIn(ROLES).withMessage('Choose a valid role.'),
];

const activeRules = [
  body('active').isString().bail().isIn(['0', '1']).withMessage('Invalid request.'),
];

module.exports = { computerRules, faultStatusRules, roleRules, activeRules };

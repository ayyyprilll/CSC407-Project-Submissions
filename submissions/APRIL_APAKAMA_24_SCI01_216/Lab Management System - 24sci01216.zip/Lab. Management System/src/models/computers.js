// Computer queries. Parameterized SQL only. The only text placed into SQL is fixed fragments
// written in this file; everything that comes from a user is a bound `?` value.
const { likePattern } = require('../utils/query');

// "in_use" is not stored: it is worked out from approved bookings that cover the current moment.
// This way a computer's state can never get out of step with the bookings table.
const DISPLAY_STATUS_SQL = `
  CASE WHEN c.status = 'available' AND EXISTS (
         SELECT 1 FROM bookings b
          WHERE b.computer_id = c.id AND b.status = 'approved'
            AND b.start_time <= ? AND b.end_time > ?)
       THEN 'in_use' ELSE c.status END`;

const STATUS_FILTERS = ['available', 'in_use', 'maintenance', 'retired'];

function filterClause({ q, status, location }) {
  const where = [];
  const params = [];
  if (q) {
    const like = likePattern(q);
    where.push(`(name LIKE ? ESCAPE '\\' OR asset_tag LIKE ? ESCAPE '\\' OR specs LIKE ? ESCAPE '\\')`);
    params.push(like, like, like);
  }
  if (status) { where.push('display_status = ?'); params.push(status); }
  if (location) { where.push('location = ?'); params.push(location); }
  return { sql: where.length ? 'WHERE ' + where.join(' AND ') : '', params };
}

function search(db, filters, { limit, offset }) {
  const now = new Date().toISOString();
  const { sql, params } = filterClause(filters);
  const inner = `SELECT c.*, ${DISPLAY_STATUS_SQL} AS display_status FROM computers c`;
  const rows = db
    .prepare(`SELECT * FROM (${inner}) ${sql} ORDER BY asset_tag LIMIT ? OFFSET ?`)
    .all(now, now, ...params, limit, offset);
  const total = db
    .prepare(`SELECT COUNT(*) AS n FROM (${inner}) ${sql}`)
    .get(now, now, ...params).n;
  return { rows, total };
}

function locations(db) {
  return db.prepare('SELECT DISTINCT location FROM computers ORDER BY location').all().map((r) => r.location);
}

function findById(db, id) {
  return db.prepare('SELECT * FROM computers WHERE id = ?').get(id);
}

// Computers a user may book (physically available).
function listBookable(db) {
  return db
    .prepare("SELECT id, asset_tag, name, location FROM computers WHERE status = 'available' ORDER BY location, asset_tag")
    .all();
}

// Computers a fault can be reported against (anything not retired).
function listReportable(db) {
  return db
    .prepare("SELECT id, asset_tag, name, location FROM computers WHERE status != 'retired' ORDER BY location, asset_tag")
    .all();
}

// ---- Admin writes ----
const STATUSES = ['available', 'maintenance', 'retired'];

function isDuplicateTag(err) {
  return err && err.code === 'SQLITE_CONSTRAINT_UNIQUE';
}

function create(db, { assetTag, name, location, specs, status }) {
  try {
    const info = db
      .prepare('INSERT INTO computers (asset_tag, name, location, specs, status) VALUES (?, ?, ?, ?, ?)')
      .run(assetTag, name, location, specs, status);
    return { id: Number(info.lastInsertRowid) };
  } catch (err) {
    if (isDuplicateTag(err)) return { error: 'Another computer already uses that asset tag.' };
    throw err;
  }
}

// Changing the status to "retired" also cancels any future pending/approved bookings for that machine.
function update(db, id, { assetTag, name, location, specs, status }) {
  return db.transaction(() => {
    try {
      db.prepare('UPDATE computers SET asset_tag = ?, name = ?, location = ?, specs = ?, status = ? WHERE id = ?')
        .run(assetTag, name, location, specs, status, id);
    } catch (err) {
      if (isDuplicateTag(err)) return { error: 'Another computer already uses that asset tag.' };
      throw err;
    }
    return { cancelled: status === 'retired' ? cancelFutureBookings(db, id) : 0 };
  })();
}

function retire(db, id) {
  return db.transaction(() => {
    db.prepare("UPDATE computers SET status = 'retired' WHERE id = ?").run(id);
    return { cancelled: cancelFutureBookings(db, id) };
  })();
}

function cancelFutureBookings(db, computerId) {
  return db
    .prepare("UPDATE bookings SET status = 'cancelled' WHERE computer_id = ? AND status IN ('pending','approved') AND end_time > ?")
    .run(computerId, new Date().toISOString()).changes;
}

module.exports = { STATUS_FILTERS, STATUSES, search, locations, findById, listBookable, listReportable, create, update, retire };

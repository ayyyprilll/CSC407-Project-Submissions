// Audit log queries (read-only). The log is append-only: the application has no code that edits or deletes rows.
const { likePattern } = require('../utils/query');

function search(db, { q = '', action = '' }, { limit, offset }) {
  const where = [];
  const params = [];
  if (action) { where.push('a.action = ?'); params.push(action); }
  if (q) {
    const like = likePattern(q);
    where.push(`(u.full_name LIKE ? ESCAPE '\\' OR a.details LIKE ? ESCAPE '\\' OR a.ip_address LIKE ? ESCAPE '\\')`);
    params.push(like, like, like);
  }
  const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const from = 'FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id';
  const rows = db
    .prepare(`SELECT a.*, u.full_name ${from} ${whereSql} ORDER BY a.id DESC LIMIT ? OFFSET ?`)
    .all(...params, limit, offset);
  const total = db.prepare(`SELECT COUNT(*) AS n ${from} ${whereSql}`).get(...params).n;
  return { rows, total };
}

function actions(db) {
  return db.prepare('SELECT DISTINCT action FROM audit_logs ORDER BY action').all().map((r) => r.action);
}

module.exports = { search, actions };

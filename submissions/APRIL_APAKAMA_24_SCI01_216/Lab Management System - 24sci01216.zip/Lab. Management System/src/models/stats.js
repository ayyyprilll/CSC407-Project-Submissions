// Read-only queries that feed the dashboards. All parameterized.

function count(db, sql, ...params) {
  return db.prepare(sql).get(...params).n;
}

function adminStats(db) {
  return {
    computersAvailable: count(db, "SELECT COUNT(*) n FROM computers WHERE status = 'available'"),
    computersTotal: count(db, "SELECT COUNT(*) n FROM computers WHERE status != 'retired'"),
    pendingBookings: count(db, "SELECT COUNT(*) n FROM bookings WHERE status = 'pending'"),
    openFaults: count(db, "SELECT COUNT(*) n FROM fault_reports WHERE status != 'resolved'"),
    activeUsers: count(db, 'SELECT COUNT(*) n FROM users WHERE is_active = 1'),
  };
}

function pendingBookings(db, limit = 5) {
  return db.prepare(
    `SELECT b.id, b.start_time, b.end_time, b.purpose, u.full_name, c.name AS computer_name, c.asset_tag
       FROM bookings b
       JOIN users u ON u.id = b.user_id
       JOIN computers c ON c.id = b.computer_id
      WHERE b.status = 'pending'
      ORDER BY b.start_time ASC LIMIT ?`
  ).all(limit);
}

function recentAudit(db, limit = 6) {
  return db.prepare(
    `SELECT a.id, a.action, a.created_at, a.details, u.full_name
       FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id
      ORDER BY a.id DESC LIMIT ?`
  ).all(limit);
}

// Stats for ONE user: always filtered by that user's id.
function userStats(db, userId) {
  const now = new Date().toISOString();
  return {
    computersAvailable: count(db, "SELECT COUNT(*) n FROM computers WHERE status = 'available'"),
    upcoming: count(db, "SELECT COUNT(*) n FROM bookings WHERE user_id = ? AND status = 'approved' AND end_time >= ?", userId, now),
    pending: count(db, "SELECT COUNT(*) n FROM bookings WHERE user_id = ? AND status = 'pending'", userId),
    openFaults: count(db, "SELECT COUNT(*) n FROM fault_reports WHERE reported_by = ? AND status != 'resolved'", userId),
  };
}

function userNextBookings(db, userId, limit = 5) {
  const now = new Date().toISOString();
  return db.prepare(
    `SELECT b.id, b.start_time, b.end_time, b.status, c.name AS computer_name, c.asset_tag, c.location
       FROM bookings b JOIN computers c ON c.id = b.computer_id
      WHERE b.user_id = ? AND b.status IN ('pending', 'approved') AND b.end_time >= ?
      ORDER BY b.start_time ASC LIMIT ?`
  ).all(userId, now, limit);
}

module.exports = { adminStats, pendingBookings, recentAudit, userStats, userNextBookings };

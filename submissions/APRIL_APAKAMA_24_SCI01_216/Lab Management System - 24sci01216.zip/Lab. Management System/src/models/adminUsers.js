// Admin-side user management queries (parameterized). Password hashes are never selected here.
const { likePattern } = require('../utils/query');

const ROLES = ['user', 'admin'];

function search(db, { q = '', role = '', active = '' }, { limit, offset }) {
  const where = [];
  const params = [];
  if (q) {
    const like = likePattern(q);
    where.push(`(full_name LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\')`);
    params.push(like, like);
  }
  if (role) { where.push('role = ?'); params.push(role); }
  if (active !== '') { where.push('is_active = ?'); params.push(active === 'active' ? 1 : 0); }
  const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const rows = db
    .prepare(`SELECT id, full_name, email, role, is_active, locked_until, created_at FROM users ${whereSql} ORDER BY full_name LIMIT ? OFFSET ?`)
    .all(...params, limit, offset);
  const total = db.prepare(`SELECT COUNT(*) AS n FROM users ${whereSql}`).get(...params).n;
  return { rows, total };
}

function findById(db, id) {
  return db.prepare('SELECT id, full_name, email, role, is_active FROM users WHERE id = ?').get(id);
}

function setRole(db, id, role) {
  db.prepare("UPDATE users SET role = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(role, id);
}

// Deactivating also ends the person's login sessions straight away.
function setActive(db, id, active) {
  db.transaction(() => {
    db.prepare("UPDATE users SET is_active = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(active ? 1 : 0, id);
    if (!active) db.prepare("DELETE FROM sessions WHERE json_extract(sess, '$.userId') = ?").run(id);
  })();
}

module.exports = { ROLES, search, findById, setRole, setActive };

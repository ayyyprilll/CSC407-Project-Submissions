// All user-related database access. EVERY query uses `?` placeholders (parameterized queries):
// user input is sent to SQLite separately from the SQL text, so it can never be run as SQL.
// There is no string concatenation of user data into SQL anywhere in this project.

const MAX_FAILED_ATTEMPTS = 5;
const LOCK_MINUTES = 15;

// Safe fields only (no password hash) - used for the logged-in user on every request.
function findById(db, id) {
  return db
    .prepare('SELECT id, full_name, email, role, is_active FROM users WHERE id = ?')
    .get(id);
}

// Includes the hash and lockout fields. Only the login route should call this.
function findAuthByEmail(db, email) {
  return db.prepare('SELECT * FROM users WHERE email = ?').get(email);
}

function create(db, { fullName, email, passwordHash, role = 'user' }) {
  const info = db
    .prepare('INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)')
    .run(fullName, email, passwordHash, role);
  return info.lastInsertRowid;
}

function findAuthById(db, id) {
  return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
}

function updateName(db, id, fullName) {
  db.prepare("UPDATE users SET full_name = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(fullName, id);
}

function updatePassword(db, id, passwordHash) {
  db.prepare("UPDATE users SET password_hash = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(passwordHash, id);
}

// Ends every login session of a user except the one given (used after a password change, so a
// stolen session cannot outlive the password reset). Sessions are rows in the `sessions` table.
function deleteOtherSessions(db, userId, keepSid) {
  db.prepare("DELETE FROM sessions WHERE json_extract(sess, '$.userId') = ? AND sid != ?").run(userId, keepSid);
}

function isLocked(user, now = Date.now()) {
  return !!user.locked_until && Date.parse(user.locked_until) > now;
}

// Counts a failed login. After MAX_FAILED_ATTEMPTS in a row the account is locked for LOCK_MINUTES.
// Returns true if this failure caused a lock.
function registerFailedAttempt(db, userId) {
  const row = db.prepare('SELECT failed_attempts FROM users WHERE id = ?').get(userId);
  const attempts = row.failed_attempts + 1;
  if (attempts >= MAX_FAILED_ATTEMPTS) {
    const until = new Date(Date.now() + LOCK_MINUTES * 60 * 1000).toISOString();
    db.prepare('UPDATE users SET failed_attempts = 0, locked_until = ? WHERE id = ?').run(until, userId);
    return true;
  }
  db.prepare('UPDATE users SET failed_attempts = ? WHERE id = ?').run(attempts, userId);
  return false;
}

function clearFailedAttempts(db, userId) {
  db.prepare('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?').run(userId);
}

module.exports = {
  MAX_FAILED_ATTEMPTS,
  LOCK_MINUTES,
  findById,
  findAuthByEmail,
  findAuthById,
  updateName,
  updatePassword,
  deleteOtherSessions,
  create,
  isLocked,
  registerFailedAttempt,
  clearFailedAttempts,
};

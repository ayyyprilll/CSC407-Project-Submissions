// Fault report queries (parameterized).
const { likePattern } = require('../utils/query');

const SEVERITIES = ['low', 'medium', 'high'];
const STATUSES = ['open', 'investigating', 'resolved'];

function create(db, { computerId, reportedBy, description, severity }) {
  const computer = db.prepare('SELECT status FROM computers WHERE id = ?').get(computerId);
  if (!computer || computer.status === 'retired') return { error: 'Choose a computer from the list.' };
  const info = db
    .prepare('INSERT INTO fault_reports (computer_id, reported_by, description, severity) VALUES (?, ?, ?, ?)')
    .run(computerId, reportedBy, description, severity);
  return { id: Number(info.lastInsertRowid) };
}

// Admin list. Most severe and oldest unresolved first.
function search(db, { q = '', status = '', severity = '' }, { limit, offset }) {
  const where = [];
  const params = [];
  if (status) { where.push('f.status = ?'); params.push(status); }
  if (severity) { where.push('f.severity = ?'); params.push(severity); }
  if (q) {
    const like = likePattern(q);
    where.push(`(c.name LIKE ? ESCAPE '\\' OR c.asset_tag LIKE ? ESCAPE '\\' OR f.description LIKE ? ESCAPE '\\' OR u.full_name LIKE ? ESCAPE '\\')`);
    params.push(like, like, like, like);
  }
  const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const from = `FROM fault_reports f
                JOIN computers c ON c.id = f.computer_id
                JOIN users u     ON u.id = f.reported_by`;
  const rows = db
    .prepare(
      `SELECT f.*, c.name AS computer_name, c.asset_tag, u.full_name AS reporter
         ${from} ${whereSql}
        ORDER BY (f.status = 'resolved'),
                 CASE f.severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END,
                 f.created_at ASC
        LIMIT ? OFFSET ?`
    )
    .all(...params, limit, offset);
  const total = db.prepare(`SELECT COUNT(*) AS n ${from} ${whereSql}`).get(...params).n;
  return { rows, total };
}

function setStatus(db, id, status, adminId) {
  const resolvedBy = status === 'resolved' ? adminId : null;
  return db
    .prepare("UPDATE fault_reports SET status = ?, resolved_by = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?")
    .run(status, resolvedBy, id).changes;
}

module.exports = { SEVERITIES, STATUSES, create, search, setStatus };

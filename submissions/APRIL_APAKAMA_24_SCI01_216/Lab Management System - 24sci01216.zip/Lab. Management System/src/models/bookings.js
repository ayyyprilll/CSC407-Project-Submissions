// Booking queries.
//
// IDOR (Insecure Direct Object Reference) defence: any query that touches ONE booking on behalf of
// a normal user includes `AND user_id = ?` with the id from the SESSION (never from the form or URL).
// So even if a user edits the URL to /bookings/7/cancel, SQLite finds nothing unless booking 7 is theirs.
const { likePattern } = require('../utils/query');

const STATUSES = ['pending', 'approved', 'rejected', 'cancelled'];
const MAX_PENDING_PER_USER = 10; // stops one account flooding the approval queue

// List/search. Pass userId to restrict to one user's bookings (normal users);
// pass null for the admin view of everyone's bookings.
function search(db, { userId = null, q = '', status = '' }, { limit, offset }) {
  const where = [];
  const params = [];
  if (userId !== null) { where.push('b.user_id = ?'); params.push(userId); }
  if (status) { where.push('b.status = ?'); params.push(status); }
  if (q) {
    const like = likePattern(q);
    where.push(`(c.name LIKE ? ESCAPE '\\' OR c.asset_tag LIKE ? ESCAPE '\\' OR b.purpose LIKE ? ESCAPE '\\' OR u.full_name LIKE ? ESCAPE '\\')`);
    params.push(like, like, like, like);
  }
  const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const from = `FROM bookings b
                JOIN computers c ON c.id = b.computer_id
                JOIN users u     ON u.id = b.user_id`;
  const rows = db
    .prepare(
      `SELECT b.*, c.name AS computer_name, c.asset_tag, c.location, u.full_name AS user_name
         ${from} ${whereSql}
        ORDER BY b.start_time DESC, b.id DESC LIMIT ? OFFSET ?`
    )
    .all(...params, limit, offset);
  const total = db.prepare(`SELECT COUNT(*) AS n ${from} ${whereSql}`).get(...params).n;
  return { rows, total };
}

// One booking, but ONLY if it belongs to this user.
function findOwn(db, id, userId) {
  return db.prepare('SELECT * FROM bookings WHERE id = ? AND user_id = ?').get(id, userId);
}

function findById(db, id) {
  return db.prepare('SELECT * FROM bookings WHERE id = ?').get(id);
}

// Does an APPROVED booking already cover any part of this slot on this computer?
// Two time ranges overlap when each one starts before the other ends.
function hasApprovedClash(db, computerId, startIso, endIso, ignoreId = 0) {
  return !!db
    .prepare("SELECT 1 FROM bookings WHERE computer_id = ? AND status = 'approved' AND id != ? AND start_time < ? AND end_time > ?")
    .get(computerId, ignoreId, endIso, startIso);
}

// Creates a pending booking after checking the rules. Runs as one transaction, so two requests
// cannot both slip through the checks. Returns { id } or { error }.
function create(db, { userId, computerId, startIso, endIso, purpose }) {
  return db.transaction(() => {
    const computer = db.prepare('SELECT status FROM computers WHERE id = ?').get(computerId);
    if (!computer || computer.status !== 'available') return { error: 'Choose a computer that is available.' };

    if (hasApprovedClash(db, computerId, startIso, endIso)) {
      return { error: 'That computer is already booked for part of this time. Choose another time or computer.' };
    }
    const mine = db
      .prepare("SELECT 1 FROM bookings WHERE user_id = ? AND status IN ('pending','approved') AND start_time < ? AND end_time > ?")
      .get(userId, endIso, startIso);
    if (mine) return { error: 'You already have a booking that overlaps this time.' };

    const pending = db.prepare("SELECT COUNT(*) AS n FROM bookings WHERE user_id = ? AND status = 'pending'").get(userId).n;
    if (pending >= MAX_PENDING_PER_USER) {
      return { error: `You already have ${MAX_PENDING_PER_USER} bookings awaiting approval. Wait for a decision first.` };
    }

    const info = db
      .prepare('INSERT INTO bookings (user_id, computer_id, start_time, end_time, purpose) VALUES (?, ?, ?, ?, ?)')
      .run(userId, computerId, startIso, endIso, purpose);
    return { id: Number(info.lastInsertRowid) };
  })();
}

// Cancel: only the owner, and only while pending/approved and not yet finished.
function cancelOwn(db, id, userId) {
  return db
    .prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ? AND user_id = ? AND status IN ('pending','approved') AND end_time > ?")
    .run(id, userId, new Date().toISOString()).changes;
}

// Admin decision on a pending booking. Re-checks the rules at decision time, because things may
// have changed since the request was made (another booking approved, computer taken out of service).
// Returns { ok } or { error }. `decision` is 'approved' or 'rejected'.
function decide(db, { id, adminId, decision }) {
  return db.transaction(() => {
    const b = findById(db, id);
    if (!b) return { notFound: true };
    if (b.status !== 'pending') return { error: 'Only pending bookings can be decided.' };

    if (decision === 'approved') {
      if (b.end_time <= new Date().toISOString()) return { error: 'This booking time has already passed.' };
      const c = db.prepare('SELECT status FROM computers WHERE id = ?').get(b.computer_id);
      if (!c || c.status !== 'available') return { error: 'That computer is not available any more.' };
      if (hasApprovedClash(db, b.computer_id, b.start_time, b.end_time, b.id)) {
        return { error: 'Cannot approve: it overlaps a booking that is already approved.' };
      }
    }
    db.prepare("UPDATE bookings SET status = ?, decided_by = ?, decided_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?")
      .run(decision, adminId, id);
    return { ok: true, booking: b };
  })();
}

module.exports = { STATUSES, search, findOwn, findById, hasApprovedClash, create, cancelOwn, decide };

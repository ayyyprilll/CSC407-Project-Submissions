// Security headers (Helmet) and the Content Security Policy.
const helmet = require('helmet');
const config = require('../config');

// CONTENT SECURITY POLICY (CSP): tells the browser which sources it may load code from.
// Because there are NO inline scripts or styles anywhere in this app, we can use the strictest
// setting: only files served from our own origin ('self'). Even if an attacker managed to inject
// <script> into a page, the browser would refuse to run it.
const csp = {
  useDefaults: false,
  directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'"],            // no 'unsafe-inline', no 'unsafe-eval'
    styleSrc: ["'self'"],             // external stylesheet only, no style="" attributes
    imgSrc: ["'self'", 'data:'],
    fontSrc: ["'self'"],              // fonts are self-hosted, not loaded from Google
    connectSrc: ["'self'"],
    objectSrc: ["'none'"],            // no plugins
    baseUri: ["'self'"],              // stops <base> tag hijacking of relative URLs
    formAction: ["'self'"],           // forms may only submit to this site
    frameAncestors: ["'none'"],       // nobody may embed us in a frame (clickjacking)
    // Only force HTTPS upgrades in production; on http://localhost it would break the app.
    ...(config.isProd ? { upgradeInsecureRequests: [] } : {}),
  },
};

module.exports = helmet({
  contentSecurityPolicy: csp,
  // HSTS tells browsers to use HTTPS only. Production only - never on plain-HTTP localhost.
  strictTransportSecurity: config.isProd
    ? { maxAge: 15552000, includeSubDomains: true }
    : false,
  referrerPolicy: { policy: 'same-origin' },
  // Helmet also sets: X-Content-Type-Options: nosniff, X-Frame-Options, removes X-Powered-By,
  // Cross-Origin-Opener-Policy, Cross-Origin-Resource-Policy, etc.
});

// ACCESS CONTROL MIDDLEWARE.
// These two functions are the single place where "who may do this" is decided. Every protected
// route lists them, so the check is enforced on the SERVER regardless of what the menu shows.
// (Hiding a link in the UI is only cosmetic; an attacker can still type the URL.)
const { HttpError } = require('../utils/errors');

// Must be logged in. Otherwise: redirect to the login page.
function requireLogin(req, res, next) {
  if (!req.user) return res.redirect('/login');
  next();
}

// Must be logged in AND have one of the listed roles. Otherwise: 403 Forbidden.
// Usage: router.get('/admin/users', requireRole('admin'), handler)
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.redirect('/login');
    if (!roles.includes(req.user.role)) return next(new HttpError(403, 'Forbidden'));
    next();
  };
}

// For pages only guests should see (login, register).
function requireGuest(req, res, next) {
  if (req.user) return res.redirect('/dashboard');
  next();
}

module.exports = { requireLogin, requireRole, requireGuest };

// Turns express-validator results into a simple list of messages.
const { validationResult } = require('express-validator');

// Returns an array of error messages, or null if the input is valid.
function collectErrors(req) {
  const result = validationResult(req);
  if (result.isEmpty()) return null;
  // One message per field (the first failure) keeps the error list short.
  const seen = new Set();
  const messages = [];
  for (const e of result.array()) {
    if (seen.has(e.path)) continue;
    seen.add(e.path);
    messages.push(e.msg);
  }
  return messages;
}

module.exports = { collectErrors };

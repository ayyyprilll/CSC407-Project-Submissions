// One-time messages ("Booking cancelled") that survive exactly one redirect.
// Routes set req.session.flash = { type, text }; this moves it into res.locals for the next page.
function flash(req, res, next) {
  res.locals.flash = req.session.flash || null;
  delete req.session.flash;
  next();
}

module.exports = flash;

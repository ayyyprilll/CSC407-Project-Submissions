// Central 404 and error handling.
// SECURITY: users only ever see a short generic message. Stack traces, SQL errors and file paths
// are written to the server log (never to the browser) so internals are not leaked.
const logger = require('../utils/logger');

const MESSAGES = {
  400: { title: 'Bad request', text: 'The request could not be understood.' },
  403: { title: 'Access denied', text: 'You do not have permission to view this page.' },
  404: { title: 'Page not found', text: 'The page you asked for does not exist.' },
  429: { title: 'Too many requests', text: 'You have made too many requests. Please wait a few minutes and try again.' },
  500: { title: 'Something went wrong', text: 'An unexpected error occurred. It has been logged.' },
};

function notFound(req, res, next) {
  const err = new Error('Not found');
  err.status = 404;
  next(err);
}

// Express recognises an error handler by its four parameters - keep `next` even though unused.
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  // Only trust statuses we deliberately handle; anything else becomes a plain 500.
  let status = Number(err.status || err.statusCode) || 500;
  if (!MESSAGES[status]) status = status >= 400 && status < 500 ? 400 : 500;

  if (status >= 500) {
    // Full detail goes to the log only.
    logger.error({ err, method: req.method, path: req.path }, 'unhandled error');
  }
  if (res.headersSent) return next(err);

  let { title, text } = MESSAGES[status];
  // A failed CSRF check is a 403 too, but deserves a more helpful message.
  if (err.code === 'EBADCSRFTOKEN') {
    title = 'Form expired';
    text = 'Your form could not be verified. Go back, reload the page and try again.';
  }
  res.status(status).render('errors/error', { pageTitle: title, status, title, text });
}

module.exports = { notFound, errorHandler };

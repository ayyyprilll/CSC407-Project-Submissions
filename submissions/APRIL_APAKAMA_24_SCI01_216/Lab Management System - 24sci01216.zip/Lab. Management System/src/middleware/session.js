// Session management.
// A session is a server-side record. The browser only holds a random, unguessable ID in a cookie;
// the real data (who is logged in) lives in the SQLite `sessions` table.
const session = require('express-session');
const SqliteStore = require('better-sqlite3-session-store')(session);
const config = require('../config');
const users = require('../models/users');

const IDLE_TIMEOUT_MS = 30 * 60 * 1000;        // logged out after 30 minutes of inactivity
const ABSOLUTE_TIMEOUT_MS = 8 * 60 * 60 * 1000; // ...and never later than 8 hours after login

// The session store starts a cleanup timer it never lets go of, which would stop the process (and
// the test runner) from exiting. We mark that timer as "unref" so it no longer keeps Node alive.
// The HTTP server keeps the real app running; this only affects shutdown.
function createStore(db) {
  const realSetInterval = global.setInterval;
  global.setInterval = (...args) => {
    const timer = realSetInterval(...args);
    if (timer.unref) timer.unref();
    return timer;
  };
  try {
    return new SqliteStore({
      client: db,
      expired: { clear: true, intervalMs: 15 * 60 * 1000 }, // purge dead sessions every 15 min
    });
  } finally {
    global.setInterval = realSetInterval;
  }
}

function sessionMiddleware(db) {
  return session({
    name: 'lab.sid',                 // custom name (not the default "connect.sid") hides the framework
    secret: config.sessionSecret,    // signs the cookie so it cannot be forged
    resave: false,
    saveUninitialized: false,        // don't create a session until we actually store something
    rolling: true,                   // every request pushes the idle expiry forward
    store: createStore(db),
    cookie: {
      httpOnly: true,                // JavaScript cannot read the cookie (limits XSS damage)
      sameSite: 'lax',               // not sent on cross-site POSTs (a CSRF layer)
      secure: config.isProd,         // HTTPS only in production
      maxAge: IDLE_TIMEOUT_MS,
    },
  });
}

// Runs on every request. Looks up the logged-in user FRESH from the database each time, so a
// role change or deactivation by an admin takes effect immediately (not at next login).
function loadUser(db) {
  return (req, res, next) => {
    const s = req.session;
    if (!s || !s.userId) return next();

    // Absolute lifetime check.
    if (s.loginAt && Date.now() - s.loginAt > ABSOLUTE_TIMEOUT_MS) {
      delete s.userId;
      return next();
    }

    const user = users.findById(db, s.userId);
    if (!user || !user.is_active) {
      delete s.userId; // deleted or deactivated: treat as logged out
      return next();
    }
    req.user = user;
    res.locals.user = user; // available in every EJS template as `user`
    next();
  };
}

module.exports = { sessionMiddleware, loadUser };

// Rate limiting: caps how many requests one IP address may make in a time window.
// This slows down password guessing, account-creation spam and general abuse.
// (Per-account lockout after repeated failures is separate - see models/users.js.)
const rateLimit = require('express-rate-limit');
const { HttpError } = require('../utils/errors');

function make({ windowMs, limit }) {
  return rateLimit({
    windowMs,
    limit,
    standardHeaders: 'draft-7', // sends RateLimit-* headers so clients can see the budget
    legacyHeaders: false,
    handler: (req, res, next) => next(new HttpError(429, 'Too many requests')),
  });
}

// Settings are passed in so tests can use tiny limits.
function buildLimiters(opts = {}) {
  return {
    general: make({ windowMs: 15 * 60 * 1000, limit: opts.generalLimit || 600 }),
    login: make({ windowMs: 15 * 60 * 1000, limit: opts.loginLimit || 20 }),
    register: make({ windowMs: 60 * 60 * 1000, limit: opts.registerLimit || 10 }),
  };
}

module.exports = { buildLimiters };

// CSRF protection (csrf-csrf, "double submit cookie" pattern, tied to the session).
//
// The attack: while you are logged in, a malicious site makes your browser POST to our app.
// The browser attaches your session cookie automatically, so the request looks legitimate.
//
// The defence: every form carries a secret token (hidden field `_csrf`). The same token is also
// stored in a cookie. On every POST/PUT/PATCH/DELETE the server checks that the form token and the
// cookie match AND are signed for this session. A foreign site cannot read our pages, so it cannot
// know the token, and its forged request is rejected with 403.
const { doubleCsrf } = require('csrf-csrf');
const config = require('../config');

const { generateCsrfToken, doubleCsrfProtection } = doubleCsrf({
  getSecret: () => config.sessionSecret,
  getSessionIdentifier: (req) => req.session.id,
  // "__Host-" prefix makes the browser enforce Secure + path=/ + no Domain attribute (production).
  cookieName: config.isProd ? '__Host-lab.csrf' : 'lab.csrf',
  cookieOptions: { sameSite: 'lax', secure: config.isProd, httpOnly: true, path: '/' },
  size: 32,
  getCsrfTokenFromRequest: (req) => (req.body && req.body._csrf) || req.headers['x-csrf-token'],
  errorConfig: { statusCode: 403, message: 'Invalid CSRF token', code: 'EBADCSRFTOKEN' },
});

// Makes `csrfToken` available to every template. We also touch the session so it is saved even
// for visitors who are not logged in yet (the token is bound to the session ID).
function exposeCsrfToken(req, res, next) {
  req.session.csrfBound = true;
  res.locals.csrfToken = generateCsrfToken(req, res);
  next();
}

module.exports = { csrfProtection: doubleCsrfProtection, exposeCsrfToken };

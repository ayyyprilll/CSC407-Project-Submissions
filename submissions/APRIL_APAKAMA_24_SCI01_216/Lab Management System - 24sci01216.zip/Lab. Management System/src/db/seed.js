// Seed script. Creates the admin, a few sample users and 20 computers.
//  - Runs automatically on first start (see server.js) because free hosting disks can reset.
//  - Can also be run by hand:  npm run seed
//  - Idempotent: does nothing if users already exist.
// SECURITY: no password is hardcoded. They come from environment variables; in development,
// if none is set, a random one is generated and printed ONCE to the console.
const crypto = require('crypto');
const bcrypt = require('bcrypt');
const config = require('../config');
const { openDb } = require('./connection');

const SAMPLE_USERS = [
  ['Amara Okafor', 'amara@lab.local'],
  ['Tunde Bello', 'tunde@lab.local'],
  ['Chioma Eze', 'chioma@lab.local'],
];

const LOCATIONS = ['Lab A', 'Lab B', 'Lab C'];

function randomPassword() {
  // 16 random bytes -> 22 URL-safe chars; the appended digit guarantees the policy is met.
  return crypto.randomBytes(16).toString('base64url') + '7';
}

function seedIfEmpty(db, { quiet = false } = {}) {
  const count = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  if (count > 0) return false;

  const say = (msg) => { if (!quiet && !config.isTest) console.log(msg); };
  const insertUser = db.prepare(
    'INSERT INTO users (full_name, email, password_hash, role) VALUES (?, ?, ?, ?)'
  );
  const insertComputer = db.prepare(
    'INSERT INTO computers (asset_tag, name, location, specs, status) VALUES (?, ?, ?, ?, ?)'
  );

  const adminPassword = config.admin.password || randomPassword();
  const generatedAdmin = !config.admin.password;

  // Sample users are skipped in production unless a shared password was explicitly provided.
  let userPassword = config.seedUserPassword;
  if (!userPassword && !config.isProd) userPassword = randomPassword();
  const generatedUser = !config.seedUserPassword && !!userPassword;

  const run = db.transaction(() => {
    insertUser.run(config.admin.name, config.admin.email, bcrypt.hashSync(adminPassword, config.bcryptRounds), 'admin');
    if (userPassword) {
      const hash = bcrypt.hashSync(userPassword, config.bcryptRounds);
      for (const [name, email] of SAMPLE_USERS) insertUser.run(name, email, hash, 'user');
    }
    for (let i = 1; i <= 20; i++) {
      const tag = `LAB-${String(i).padStart(3, '0')}`;
      const location = LOCATIONS[(i - 1) % LOCATIONS.length];
      const specs = i <= 12 ? 'Core i5, 16 GB RAM, 512 GB SSD' : 'Core i7, 32 GB RAM, 1 TB SSD';
      // A couple of machines start in maintenance / retired so the filters have data to show.
      const status = i === 7 ? 'maintenance' : i === 19 ? 'retired' : 'available';
      insertComputer.run(tag, `Workstation ${String(i).padStart(2, '0')}`, location, specs, status);
    }
  });
  run();

  say(`Seeded admin ${config.admin.email}, ${userPassword ? SAMPLE_USERS.length : 0} sample users and 20 computers.`);
  if (generatedAdmin) say(`Generated ADMIN password (shown once, store it): ${adminPassword}`);
  if (generatedUser) say(`Generated sample USER password (shown once): ${userPassword}`);
  return true;
}

module.exports = { seedIfEmpty };

if (require.main === module) {
  const db = openDb(config.dbPath);
  const did = seedIfEmpty(db);
  if (!did) console.log('Database already has users; nothing to seed.');
  db.close();
}

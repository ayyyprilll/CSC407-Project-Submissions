-- Database schema. Idempotent (IF NOT EXISTS) so it is safe to run on every start.
-- Constraints (CHECK, UNIQUE, FOREIGN KEY) are a second line of defence: even if application
-- validation had a bug, the database refuses invalid data.

CREATE TABLE IF NOT EXISTS users (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name       TEXT    NOT NULL CHECK (length(full_name) BETWEEN 2 AND 100),
  email           TEXT    NOT NULL UNIQUE COLLATE NOCASE CHECK (length(email) BETWEEN 5 AND 254),
  password_hash   TEXT    NOT NULL,                         -- bcrypt hash, never the password
  role            TEXT    NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'user')),
  is_active       INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
  failed_attempts INTEGER NOT NULL DEFAULT 0,               -- login lockout counter
  locked_until    TEXT,                                     -- ISO time until which login is blocked
  created_at      TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at      TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS computers (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  asset_tag  TEXT    NOT NULL UNIQUE CHECK (length(asset_tag) BETWEEN 2 AND 30),
  name       TEXT    NOT NULL CHECK (length(name) BETWEEN 2 AND 100),
  location   TEXT    NOT NULL CHECK (length(location) BETWEEN 2 AND 100),
  specs      TEXT    NOT NULL DEFAULT '' CHECK (length(specs) <= 300),
  -- Physical condition only. "In use" is derived from approved bookings, so it cannot drift.
  status     TEXT    NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'maintenance', 'retired')),
  created_at TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS bookings (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id)     ON DELETE RESTRICT,
  computer_id INTEGER NOT NULL REFERENCES computers(id) ON DELETE RESTRICT,
  start_time  TEXT    NOT NULL,                             -- ISO 8601 UTC
  end_time    TEXT    NOT NULL,
  purpose     TEXT    NOT NULL CHECK (length(purpose) BETWEEN 3 AND 200),
  status      TEXT    NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'cancelled')),
  decided_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  decided_at  TEXT,
  created_at  TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  CHECK (end_time > start_time)
);
CREATE INDEX IF NOT EXISTS idx_bookings_user     ON bookings(user_id);
CREATE INDEX IF NOT EXISTS idx_bookings_computer ON bookings(computer_id, start_time, end_time);

CREATE TABLE IF NOT EXISTS fault_reports (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  computer_id INTEGER NOT NULL REFERENCES computers(id) ON DELETE RESTRICT,
  reported_by INTEGER NOT NULL REFERENCES users(id)     ON DELETE RESTRICT,
  description TEXT    NOT NULL CHECK (length(description) BETWEEN 5 AND 1000),
  severity    TEXT    NOT NULL CHECK (severity IN ('low', 'medium', 'high')),
  status      TEXT    NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'investigating', 'resolved')),
  resolved_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at  TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at  TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_faults_computer ON fault_reports(computer_id);
CREATE INDEX IF NOT EXISTS idx_faults_reporter ON fault_reports(reported_by);

-- Audit log: who did what, when, from where. Never stores passwords or session IDs.
CREATE TABLE IF NOT EXISTS audit_logs (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
  action      TEXT NOT NULL,
  target_type TEXT,
  target_id   INTEGER,
  details     TEXT,
  ip_address  TEXT,
  created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);

// Central configuration. Every secret comes from environment variables (.env locally,
// the Render dashboard in production). Nothing secret is hardcoded in the code.
require('dotenv').config({ quiet: true });
const crypto = require('crypto');

const env = process.env.NODE_ENV || 'development';
const isProd = env === 'production';
const isTest = env === 'test';

// In production, refuse to start with missing secrets (fail fast, never fall back to a weak default).
if (isProd) {
  const secret = process.env.SESSION_SECRET || '';
  if (secret.length < 32) {
    throw new Error('SESSION_SECRET must be set to a random string of at least 32 characters in production.');
  }
  if (!process.env.ADMIN_PASSWORD) {
    throw new Error('ADMIN_PASSWORD must be set in production so the first admin can be created.');
  }
}

module.exports = {
  env,
  isProd,
  isTest,
  port: parseInt(process.env.PORT, 10) || 3000,
  dbPath: process.env.DB_PATH || (isTest ? ':memory:' : './data/lab.db'),
  // In development a random secret is generated per run (sessions reset on restart - acceptable).
  sessionSecret: process.env.SESSION_SECRET || crypto.randomBytes(48).toString('hex'),
  // bcrypt cost factor. 12 is a sound default; tests use 4 only to keep the suite fast.
  bcryptRounds: isTest ? 4 : 12,
  admin: {
    email: (process.env.ADMIN_EMAIL || 'admin@lab.local').toLowerCase(),
    name: process.env.ADMIN_NAME || 'Lab Administrator',
    password: process.env.ADMIN_PASSWORD || '',
  },
  seedUserPassword: process.env.SEED_USER_PASSWORD || '',
};

// Entry point: open the database, seed it if empty, start listening.
const config = require('./config');
const logger = require('./utils/logger');
const { openDb } = require('./db/connection');
const { seedIfEmpty } = require('./db/seed');
const { createApp } = require('./app');

const db = openDb(config.dbPath);
// Free hosts can wipe the disk, so the app re-creates its starting data on first start.
seedIfEmpty(db);

const app = createApp(db);
const server = app.listen(config.port, () => {
  logger.info({ port: config.port, env: config.env }, 'server started');
});

// Last-resort monitoring: anything that escapes normal error handling is logged as "fatal" (JSON,
// searchable in Render's log viewer) and the process exits so the host restarts it in a clean state.
process.on('uncaughtException', (err) => {
  logger.fatal({ err }, 'uncaught exception');
  process.exit(1);
});
process.on('unhandledRejection', (reason) => {
  logger.fatal({ err: reason }, 'unhandled promise rejection');
  process.exit(1);
});

// Close cleanly when the host stops the process.
function shutdown(signal) {
  logger.info({ signal }, 'shutting down');
  server.close(() => { db.close(); process.exit(0); });
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

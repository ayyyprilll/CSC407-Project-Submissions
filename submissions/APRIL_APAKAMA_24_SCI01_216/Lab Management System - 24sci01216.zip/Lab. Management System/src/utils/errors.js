// A small error type for "expected" failures (403, 404 ...). Routes throw it, and the central
// error handler turns it into a clean error page.
class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
    this.expose = true; // safe to show the message to the user
  }
}

module.exports = { HttpError };

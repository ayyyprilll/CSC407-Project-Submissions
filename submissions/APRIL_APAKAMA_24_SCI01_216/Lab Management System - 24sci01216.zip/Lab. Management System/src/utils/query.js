// Safe reading of URL query-string filters (?q=...&status=...&page=2).
// Query strings are user input too: every value is checked against a type, a length limit or an
// allow-list before it is used. Anything unexpected quietly becomes "no filter".

// Plain string, trimmed and capped. Arrays (?q=a&q=b) and other types become ''.
function str(value, max = 100) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}

// Only accept a value that is in the allowed list.
function oneOf(value, allowed) {
  return typeof value === 'string' && allowed.includes(value) ? value : '';
}

function pageNumber(value) {
  const n = parseInt(typeof value === 'string' ? value : '', 10);
  return Number.isInteger(n) && n >= 1 && n <= 10000 ? n : 1;
}

// Turns user text into a LIKE pattern. % and _ are wildcards in SQL LIKE, so they are escaped;
// the query then uses  LIKE ? ESCAPE '\'  . (The text itself is still passed as a bound parameter.)
function likePattern(text) {
  return '%' + text.replace(/[\\%_]/g, (m) => '\\' + m) + '%';
}

// A database id taken from a URL (/admin/users/:id/role). Only plain digits are accepted;
// anything else (letters, signs, SQL fragments) becomes 0, which matches no row.
function parseId(value) {
  return typeof value === 'string' && /^\d{1,10}$/.test(value) ? parseInt(value, 10) : 0;
}

const PER_PAGE = 15;

// Builds the data the pager partial needs, keeping the active filters in the prev/next links.
function buildPager(basePath, filters, page, total, perPage = PER_PAGE) {
  const pages = Math.max(1, Math.ceil(total / perPage));
  const link = (p) => {
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(filters)) if (v) params.set(k, v);
    if (p > 1) params.set('page', String(p));
    const qs = params.toString();
    return qs ? `${basePath}?${qs}` : basePath;
  };
  return {
    page,
    pages,
    total,
    from: total === 0 ? 0 : (page - 1) * perPage + 1,
    to: Math.min(page * perPage, total),
    prev: page > 1 ? link(page - 1) : null,
    next: page < pages ? link(page + 1) : null,
  };
}

module.exports = { str, oneOf, pageNumber, parseId, likePattern, buildPager, PER_PAGE };

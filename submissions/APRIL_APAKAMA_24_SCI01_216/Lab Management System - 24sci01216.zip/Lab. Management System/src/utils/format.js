// Small helpers made available to every template as `fmt`.
// Dates are stored as UTC ISO strings and shown as UTC with an explicit label, so there is no
// ambiguity about time zones in this project.
function dateTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return d.toISOString().slice(0, 16).replace('T', ' ') + ' UTC';
}

function date(iso) {
  return dateTime(iso).slice(0, 10);
}

// "login_failed" -> "login failed"
function action(name) {
  return String(name || '').replace(/_/g, ' ');
}

module.exports = { dateTime, date, action };

// Password policy. Used by registration (and later by change-password).
// Rules are deliberately simple and explainable: length matters more than complexity tricks.
const MIN_LENGTH = 10;
const MAX_BYTES = 72; // bcrypt silently ignores anything past 72 bytes, so we refuse longer input

function passwordProblems(password, email = '') {
  const problems = [];
  if (typeof password !== 'string') return ['Password is required.'];
  if (password.length < MIN_LENGTH) problems.push(`Password must be at least ${MIN_LENGTH} characters.`);
  if (Buffer.byteLength(password, 'utf8') > MAX_BYTES) problems.push('Password is too long (maximum 72 bytes).');
  if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
    problems.push('Password must contain at least one letter and one number.');
  }
  if (email && password.toLowerCase() === String(email).toLowerCase()) {
    problems.push('Password must not be the same as your email.');
  }
  return problems;
}

module.exports = { passwordProblems, MIN_LENGTH };

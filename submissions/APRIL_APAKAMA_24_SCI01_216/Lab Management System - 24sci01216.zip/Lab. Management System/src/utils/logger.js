// Structured (JSON) logging with pino. Render collects stdout, so JSON lines are searchable there.
// SECURITY: sensitive values are redacted so passwords, cookies and session IDs never reach the logs.
const pino = require('pino');
const config = require('../config');

const redact = {
  paths: [
    'req.headers.cookie',
    'req.headers.authorization',
    'res.headers["set-cookie"]',
    'password',
    'new_password',
    'current_password',
    'confirm_password',
    '*.password',
    '*.password_hash',
    'sessionID',
    '*.sessionID',
  ],
  censor: '[REDACTED]',
};

const logger = pino({
  // LOG_LEVEL can override the default (trace, debug, info, warn, error, fatal, silent).
  level: process.env.LOG_LEVEL || (config.isTest ? 'silent' : config.isProd ? 'info' : 'debug'),
  redact,
});

logger.redactConfig = redact; // exposed so the tests can prove the redaction works

module.exports = logger;

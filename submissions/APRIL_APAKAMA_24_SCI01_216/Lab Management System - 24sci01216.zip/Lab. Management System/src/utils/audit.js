// Audit log helper: records important actions (login, failed login, role change, booking decisions).
// SECURITY: callers must never pass passwords, tokens or session IDs in `details`.
const logger = require('./logger');

function audit(req, action, { userId, targetType = null, targetId = null, details = null } = {}) {
  try {
    const actor = userId !== undefined ? userId : req.user ? req.user.id : null;
    req.app.locals.db
      .prepare(
        'INSERT INTO audit_logs (user_id, action, target_type, target_id, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)'
      )
      .run(actor, action, targetType, targetId, details ? String(details).slice(0, 500) : null, req.ip || null);
  } catch (err) {
    // Failing to write an audit row must not break the user's request, but we do want to know.
    logger.error({ err, action }, 'audit write failed');
  }
}

module.exports = { audit };

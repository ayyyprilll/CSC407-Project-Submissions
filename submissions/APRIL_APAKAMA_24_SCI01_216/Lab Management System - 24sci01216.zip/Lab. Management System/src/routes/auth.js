// Registration, login and logout.
const express = require('express');
const bcrypt = require('bcrypt');
const config = require('../config');
const users = require('../models/users');
const { registerRules, loginRules } = require('../validators/auth');
const { collectErrors } = require('../middleware/validate');
const { requireGuest, requireLogin } = require('../middleware/auth');
const { audit } = require('../utils/audit');

const GENERIC_LOGIN_ERROR =
  'Invalid email or password. If you have made several attempts, wait 15 minutes before trying again.';

// A real bcrypt hash of a throwaway string. When the email is unknown we still run a bcrypt
// comparison against this, so "unknown email" takes as long as "wrong password". Otherwise an
// attacker could measure response times to discover which emails are registered.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', config.bcryptRounds);

// express-session's regenerate/destroy use callbacks; these wrappers let us use await.
const regenerate = (req) => new Promise((resolve, reject) => req.session.regenerate((e) => (e ? reject(e) : resolve())));
const destroy = (req) => new Promise((resolve, reject) => req.session.destroy((e) => (e ? reject(e) : resolve())));

function buildAuthRouter(limiters) {
  const router = express.Router();

  // ---------- Registration ----------
  router.get('/register', requireGuest, (req, res) => {
    res.render('register', { pageTitle: 'Register', errors: [], values: {} });
  });

  router.post('/register', requireGuest, limiters.register, registerRules, async (req, res) => {
    const errors = collectErrors(req);
    if (errors) {
      // Re-show the form with the problems. We never send the password back to the page.
      return res.status(400).render('register', {
        pageTitle: 'Register',
        errors,
        values: { full_name: req.body.full_name, email: req.body.email },
      });
    }

    const db = req.app.locals.db;
    const { full_name: fullName, email, password } = req.body;

    // Always hash, even for a duplicate, so both paths take about the same time.
    const passwordHash = await bcrypt.hash(password, config.bcryptRounds);

    if (!users.findAuthByEmail(db, email)) {
      // Self-registration ALWAYS creates a normal user. The role is never read from the form,
      // so nobody can register themselves as an admin.
      const id = users.create(db, { fullName, email, passwordHash, role: 'user' });
      audit(req, 'register', { userId: id, targetType: 'user', targetId: id });
    }

    // Same response whether or not the email already existed, so the form cannot be used
    // to find out who has an account.
    req.session.flash = {
      type: 'success',
      text: 'Registration received. You can now log in. If you already had an account, use your existing password.',
    };
    res.redirect('/login');
  });

  // ---------- Login ----------
  router.get('/login', requireGuest, (req, res) => {
    res.render('login', { pageTitle: 'Log in', error: null, values: {} });
  });

  router.post('/login', requireGuest, limiters.login, loginRules, async (req, res) => {
    const db = req.app.locals.db;
    const fail = (status = 401) =>
      res.status(status).render('login', {
        pageTitle: 'Log in',
        error: GENERIC_LOGIN_ERROR,
        values: { email: typeof req.body.email === 'string' ? req.body.email.slice(0, 254) : '' },
      });

    // Malformed input gets the same generic message as a wrong password.
    if (collectErrors(req)) return fail(400);

    const { email, password } = req.body;
    const user = users.findAuthByEmail(db, email);

    // Compare against the real hash, or the dummy hash if there is no such user (timing equalisation).
    const passwordOk = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH);
    const locked = user ? users.isLocked(user) : false;

    if (!user || !passwordOk || locked || !user.is_active) {
      if (user) {
        if (locked) {
          audit(req, 'login_blocked_locked', { userId: user.id, targetType: 'user', targetId: user.id });
        } else if (!passwordOk) {
          audit(req, 'login_failed', { userId: user.id, targetType: 'user', targetId: user.id });
          if (users.registerFailedAttempt(db, user.id)) {
            audit(req, 'account_locked', { userId: user.id, targetType: 'user', targetId: user.id, details: `Locked for ${users.LOCK_MINUTES} minutes` });
          }
        } else {
          audit(req, 'login_blocked_inactive', { userId: user.id, targetType: 'user', targetId: user.id });
        }
      } else {
        // Unknown email: record it (emails are not secrets, passwords are never logged).
        audit(req, 'login_failed', { userId: null, details: `Unknown account: ${String(email).slice(0, 100)}` });
      }
      return fail();
    }

    users.clearFailedAttempts(db, user.id);

    // SESSION FIXATION DEFENCE: swap the pre-login session for a brand-new one with a new ID, so an
    // attacker who planted a known session ID in the victim's browser gains nothing.
    await regenerate(req);
    req.session.userId = user.id;
    req.session.loginAt = Date.now();
    audit(req, 'login_success', { userId: user.id, targetType: 'user', targetId: user.id });
    res.redirect('/dashboard');
  });

  // ---------- Logout ----------
  // POST (not GET) and CSRF-protected, so another site cannot log you out with an <img> tag.
  router.post('/logout', requireLogin, async (req, res) => {
    audit(req, 'logout', { targetType: 'user', targetId: req.user.id });
    await destroy(req);        // delete the server-side session record completely
    res.clearCookie('lab.sid'); // and tell the browser to drop the cookie
    res.redirect('/');
  });

  return router;
}

module.exports = { buildAuthRouter };

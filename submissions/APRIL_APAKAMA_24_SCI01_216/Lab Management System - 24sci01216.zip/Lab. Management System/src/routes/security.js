// Public page explaining every security measure and where it lives in the code.
const express = require('express');
const features = require('../securityFeatures');

const router = express.Router();

router.get('/security', (req, res) => {
  res.render('security', { pageTitle: 'Security', groups: features });
});

module.exports = router;

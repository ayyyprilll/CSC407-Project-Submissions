// Report a faulty computer.
const express = require('express');
const { requireLogin } = require('../middleware/auth');
const computers = require('../models/computers');
const faults = require('../models/faults');
const { faultRules } = require('../validators/faults');
const { collectErrors } = require('../middleware/validate');
const { audit } = require('../utils/audit');
const { str } = require('../utils/query');

const router = express.Router();

function renderForm(req, res, { status = 200, errors = [], values = {} } = {}) {
  res.status(status).render('faults/new', {
    pageTitle: 'Report a fault',
    computers: computers.listReportable(req.app.locals.db),
    severities: faults.SEVERITIES,
    errors,
    values,
  });
}

router.get('/faults/new', requireLogin, (req, res) => {
  const pre = parseInt(str(req.query.computer, 10), 10);
  renderForm(req, res, { values: { computer_id: Number.isInteger(pre) ? pre : '', severity: 'medium' } });
});

router.post('/faults', requireLogin, faultRules, (req, res) => {
  const keep = { computer_id: req.body.computer_id, severity: req.body.severity, description: req.body.description };
  const errors = collectErrors(req);
  if (errors) return renderForm(req, res, { status: 400, errors, values: keep });

  const result = faults.create(req.app.locals.db, {
    computerId: req.body.computer_id,
    reportedBy: req.user.id, // from the session, never from the form
    description: req.body.description,
    severity: req.body.severity,
  });
  if (result.error) return renderForm(req, res, { status: 400, errors: [result.error], values: keep });

  audit(req, 'fault_reported', { targetType: 'fault_report', targetId: result.id });
  req.session.flash = { type: 'success', text: 'Fault report submitted. Thank you.' };
  res.redirect('/dashboard');
});

module.exports = router;

// Dashboard (different content for Admin and User) and the admin landing redirect.
const express = require('express');
const { requireLogin } = require('../middleware/auth');
const stats = require('../models/stats');

const router = express.Router();

router.get('/dashboard', requireLogin, (req, res) => {
  const db = req.app.locals.db;
  if (req.user.role === 'admin') {
    return res.render('dashboard-admin', {
      pageTitle: 'Dashboard',
      stats: stats.adminStats(db),
      pending: stats.pendingBookings(db),
      audit: stats.recentAudit(db),
    });
  }
  // Normal users only ever see numbers computed from THEIR OWN id (req.user.id from the session).
  res.render('dashboard-user', {
    pageTitle: 'Dashboard',
    stats: stats.userStats(db, req.user.id),
    next: stats.userNextBookings(db, req.user.id),
  });
});

module.exports = router;

// A user's own bookings: list, create, cancel.
// Everything here is scoped to req.user.id (the id stored in the server-side session).
// The browser never tells us WHOSE bookings to show, so there is nothing to tamper with.
const express = require('express');
const { requireLogin, requireRole } = require('../middleware/auth');
const bookings = require('../models/bookings');
const computers = require('../models/computers');
const { bookingRules, parseSlot } = require('../validators/bookings');
const { collectErrors } = require('../middleware/validate');
const { audit } = require('../utils/audit');
const { HttpError } = require('../utils/errors');
const { str, oneOf, pageNumber, buildPager, PER_PAGE } = require('../utils/query');

const router = express.Router();

// Booking is for lab users. (Admins review bookings under /admin/bookings.)
const userOnly = requireRole('user');

router.get('/bookings', userOnly, (req, res) => {
  const db = req.app.locals.db;
  const filters = { q: str(req.query.q), status: oneOf(req.query.status, bookings.STATUSES) };
  const page = pageNumber(req.query.page);
  const { rows, total } = bookings.search(db, { userId: req.user.id, ...filters }, { limit: PER_PAGE, offset: (page - 1) * PER_PAGE });
  res.render('bookings/index', {
    pageTitle: 'My bookings',
    bookings: rows,
    filters,
    statuses: bookings.STATUSES,
    pager: buildPager('/bookings', filters, page, total),
    now: new Date().toISOString(),
  });
});

function renderForm(req, res, { status = 200, errors = [], values = {} } = {}) {
  res.status(status).render('bookings/new', {
    pageTitle: 'Book a computer',
    computers: computers.listBookable(req.app.locals.db),
    errors,
    values,
  });
}

router.get('/bookings/new', userOnly, (req, res) => {
  // ?computer=ID pre-selects a machine (the "Book" button on the computers list).
  const pre = parseInt(str(req.query.computer, 10), 10);
  renderForm(req, res, { values: { computer_id: Number.isInteger(pre) ? pre : '' } });
});

router.post('/bookings', userOnly, bookingRules, (req, res) => {
  const db = req.app.locals.db;
  const keep = { computer_id: req.body.computer_id, start: req.body.start, end: req.body.end, purpose: req.body.purpose };

  const errors = collectErrors(req);
  if (errors) return renderForm(req, res, { status: 400, errors, values: keep });

  const slot = parseSlot(req.body.start, req.body.end);
  const result = bookings.create(db, {
    userId: req.user.id,           // from the session, never from the form
    computerId: req.body.computer_id,
    startIso: slot.startIso,
    endIso: slot.endIso,
    purpose: req.body.purpose,
  });
  if (result.error) return renderForm(req, res, { status: 400, errors: [result.error], values: keep });

  audit(req, 'booking_created', { targetType: 'booking', targetId: result.id });
  req.session.flash = { type: 'success', text: 'Booking submitted. It is waiting for administrator approval.' };
  res.redirect('/bookings');
});

router.post('/bookings/:id/cancel', userOnly, (req, res, next) => {
  const db = req.app.locals.db;
  const id = /^\d{1,10}$/.test(req.params.id) ? parseInt(req.params.id, 10) : 0;

  // IDOR check: look the booking up by id AND owner. Someone else's booking looks exactly like a
  // booking that does not exist (404), so ids cannot be probed.
  const booking = bookings.findOwn(db, id, req.user.id);
  if (!booking) return next(new HttpError(404, 'Not found'));

  const changed = bookings.cancelOwn(db, id, req.user.id);
  if (changed) {
    audit(req, 'booking_cancelled', { targetType: 'booking', targetId: id });
    req.session.flash = { type: 'success', text: 'Booking cancelled.' };
  } else {
    req.session.flash = { type: 'error', text: 'This booking can no longer be cancelled.' };
  }
  res.redirect('/bookings');
});

module.exports = router;

// Profile page: edit your name and change your password.
// There is no user id in these URLs or forms - the account being changed is always req.user
// (from the session), so a user cannot edit anyone else's profile or password.
const express = require('express');
const bcrypt = require('bcrypt');
const config = require('../config');
const users = require('../models/users');
const { requireLogin } = require('../middleware/auth');
const { profileRules, passwordChangeRules } = require('../validators/profile');
const { collectErrors } = require('../middleware/validate');
const { audit } = require('../utils/audit');

const regenerate = (req) => new Promise((resolve, reject) => req.session.regenerate((e) => (e ? reject(e) : resolve())));

function buildProfileRouter(limiters) {
  const router = express.Router();

  function render(req, res, { status = 200, profileErrors = [], passwordErrors = [], values = {} } = {}) {
    const account = users.findAuthById(req.app.locals.db, req.user.id);
    res.status(status).render('profile', {
      pageTitle: 'Profile',
      account: { full_name: account.full_name, email: account.email, role: account.role, created_at: account.created_at },
      profileErrors,
      passwordErrors,
      values,
    });
  }

  router.get('/profile', requireLogin, (req, res) => render(req, res));

  // Mass-assignment defence: only `full_name` is read from the form. Even if someone adds
  // role=admin or email=... to the request, those fields are simply never used.
  router.post('/profile', requireLogin, profileRules, (req, res) => {
    const errors = collectErrors(req);
    if (errors) return render(req, res, { status: 400, profileErrors: errors, values: { full_name: req.body.full_name } });
    users.updateName(req.app.locals.db, req.user.id, req.body.full_name);
    audit(req, 'profile_updated', { targetType: 'user', targetId: req.user.id });
    req.session.flash = { type: 'success', text: 'Profile updated.' };
    res.redirect('/profile');
  });

  router.post('/profile/password', requireLogin, limiters.login, passwordChangeRules, async (req, res) => {
    const db = req.app.locals.db;
    const errors = collectErrors(req);
    if (errors) return render(req, res, { status: 400, passwordErrors: errors });

    // The current password must be re-entered: a stolen session alone cannot change the password.
    const account = users.findAuthById(db, req.user.id);
    const ok = await bcrypt.compare(req.body.current_password, account.password_hash);
    if (!ok) {
      audit(req, 'password_change_failed', { targetType: 'user', targetId: req.user.id });
      return render(req, res, { status: 400, passwordErrors: ['Your current password is not correct.'] });
    }

    users.updatePassword(db, req.user.id, await bcrypt.hash(req.body.new_password, config.bcryptRounds));

    // Fresh session ID, and end every OTHER session for this account (e.g. a stolen one).
    await regenerate(req);
    req.session.userId = account.id;
    req.session.loginAt = Date.now();
    await new Promise((resolve, reject) => req.session.save((e) => (e ? reject(e) : resolve())));
    users.deleteOtherSessions(db, account.id, req.sessionID);

    audit(req, 'password_changed', { userId: account.id, targetType: 'user', targetId: account.id });
    req.session.flash = { type: 'success', text: 'Password changed. Other devices have been logged out.' };
    res.redirect('/profile');
  });

  return router;
}

module.exports = { buildProfileRouter };

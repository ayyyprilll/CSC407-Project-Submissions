// Health check for Render (and uptime monitors). Confirms the app is up AND the database answers.
// It reveals nothing about the system beyond ok / not ok.
const express = require('express');
const router = express.Router();

router.get('/health', (req, res) => {
  try {
    req.app.locals.db.prepare('SELECT 1').get();
    res.json({ status: 'ok' });
  } catch (e) {
    res.status(503).json({ status: 'unavailable' });
  }
});

module.exports = router;

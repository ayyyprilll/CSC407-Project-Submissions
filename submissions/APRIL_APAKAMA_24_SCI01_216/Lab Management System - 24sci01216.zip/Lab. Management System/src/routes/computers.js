// Computers list with keyword / status / location filters. Any logged-in user may view it.
const express = require('express');
const { requireLogin } = require('../middleware/auth');
const computers = require('../models/computers');
const { str, oneOf, pageNumber, buildPager, PER_PAGE } = require('../utils/query');

const router = express.Router();

router.get('/computers', requireLogin, (req, res) => {
  const db = req.app.locals.db;
  const locationList = computers.locations(db);
  // Every filter is validated: text is length-capped, status/location must be known values.
  const filters = {
    q: str(req.query.q),
    status: oneOf(req.query.status, computers.STATUS_FILTERS),
    location: oneOf(req.query.location, locationList),
  };
  const page = pageNumber(req.query.page);
  const { rows, total } = computers.search(db, filters, { limit: PER_PAGE, offset: (page - 1) * PER_PAGE });

  res.render('computers/index', {
    pageTitle: 'Computers',
    computers: rows,
    filters,
    locations: locationList,
    statuses: computers.STATUS_FILTERS,
    pager: buildPager('/computers', filters, page, total),
  });
});

module.exports = router;

// ADMIN AREA. Mounted at /admin in app.js.
//
// The very first line below (router.use(requireRole('admin'))) protects EVERY route in this file.
// A route cannot be added here and accidentally left open: anyone who is not an admin gets 403
// before any handler runs. All changes are POST requests (CSRF-protected) and are written to the audit log.
const express = require('express');
const { requireRole } = require('../middleware/auth');
const { collectErrors } = require('../middleware/validate');
const { audit } = require('../utils/audit');
const { HttpError } = require('../utils/errors');
const { str, oneOf, pageNumber, parseId, buildPager, PER_PAGE } = require('../utils/query');
const computers = require('../models/computers');
const bookings = require('../models/bookings');
const faults = require('../models/faults');
const adminUsers = require('../models/adminUsers');
const auditLogs = require('../models/auditLogs');
const { computerRules, faultStatusRules, roleRules, activeRules } = require('../validators/admin');

const router = express.Router();
router.use(requireRole('admin'));

const offsetFor = (page, perPage = PER_PAGE) => (page - 1) * perPage;
const notFound = () => new HttpError(404, 'Not found');
const flash = (req, type, text) => { req.session.flash = { type, text }; };

router.get('/', (req, res) => res.redirect('/dashboard'));

// ======================= Computers =======================

router.get('/computers', (req, res) => {
  const db = req.app.locals.db;
  const locationList = computers.locations(db);
  const filters = {
    q: str(req.query.q),
    status: oneOf(req.query.status, computers.STATUS_FILTERS),
    location: oneOf(req.query.location, locationList),
  };
  const page = pageNumber(req.query.page);
  const { rows, total } = computers.search(db, filters, { limit: PER_PAGE, offset: offsetFor(page) });
  res.render('admin/computers', {
    pageTitle: 'Manage computers',
    computers: rows, filters, locations: locationList, statuses: computers.STATUS_FILTERS,
    pager: buildPager('/admin/computers', filters, page, total),
  });
});

function renderComputerForm(res, { status = 200, errors = [], values = {}, computer = null } = {}) {
  res.status(status).render('admin/computer-form', {
    pageTitle: computer ? 'Edit computer' : 'Add computer',
    computer, errors, values, statuses: computers.STATUSES,
  });
}

router.get('/computers/new', (req, res) => renderComputerForm(res, { values: { status: 'available' } }));

router.post('/computers', computerRules, (req, res) => {
  const values = { asset_tag: req.body.asset_tag, name: req.body.name, location: req.body.location, specs: req.body.specs || '', status: req.body.status };
  const errors = collectErrors(req);
  if (errors) return renderComputerForm(res, { status: 400, errors, values });

  const result = computers.create(req.app.locals.db, {
    assetTag: values.asset_tag, name: values.name, location: values.location, specs: values.specs, status: values.status,
  });
  if (result.error) return renderComputerForm(res, { status: 400, errors: [result.error], values });

  audit(req, 'computer_created', { targetType: 'computer', targetId: result.id, details: values.asset_tag });
  flash(req, 'success', 'Computer added.');
  res.redirect('/admin/computers');
});

router.get('/computers/:id/edit', (req, res, next) => {
  const computer = computers.findById(req.app.locals.db, parseId(req.params.id));
  if (!computer) return next(notFound());
  renderComputerForm(res, { computer, values: { asset_tag: computer.asset_tag, name: computer.name, location: computer.location, specs: computer.specs, status: computer.status } });
});

router.post('/computers/:id', computerRules, (req, res, next) => {
  const db = req.app.locals.db;
  const id = parseId(req.params.id);
  const computer = computers.findById(db, id);
  if (!computer) return next(notFound());

  const values = { asset_tag: req.body.asset_tag, name: req.body.name, location: req.body.location, specs: req.body.specs || '', status: req.body.status };
  const errors = collectErrors(req);
  if (errors) return renderComputerForm(res, { status: 400, errors, values, computer });

  const result = computers.update(db, id, {
    assetTag: values.asset_tag, name: values.name, location: values.location, specs: values.specs, status: values.status,
  });
  if (result.error) return renderComputerForm(res, { status: 400, errors: [result.error], values, computer });

  audit(req, 'computer_updated', { targetType: 'computer', targetId: id, details: `${computer.status} -> ${values.status}` });
  flash(req, 'success', result.cancelled ? `Computer updated. ${result.cancelled} future booking(s) were cancelled.` : 'Computer updated.');
  res.redirect('/admin/computers');
});

// "Retire" is a soft change (status = retired), never a delete, so booking history stays intact.
router.post('/computers/:id/retire', (req, res, next) => {
  const db = req.app.locals.db;
  const id = parseId(req.params.id);
  const computer = computers.findById(db, id);
  if (!computer) return next(notFound());
  const { cancelled } = computers.retire(db, id);
  audit(req, 'computer_retired', { targetType: 'computer', targetId: id, details: `${computer.asset_tag}; ${cancelled} booking(s) cancelled` });
  flash(req, 'success', `${computer.asset_tag} retired.${cancelled ? ` ${cancelled} future booking(s) were cancelled.` : ''}`);
  res.redirect('/admin/computers');
});

// ======================= Bookings =======================

router.get('/bookings', (req, res) => {
  const db = req.app.locals.db;
  const filters = { q: str(req.query.q), status: oneOf(req.query.status, bookings.STATUSES) };
  const page = pageNumber(req.query.page);
  const { rows, total } = bookings.search(db, { userId: null, ...filters }, { limit: PER_PAGE, offset: offsetFor(page) });
  res.render('admin/bookings', {
    pageTitle: 'Bookings', bookings: rows, filters, statuses: bookings.STATUSES,
    pager: buildPager('/admin/bookings', filters, page, total),
  });
});

function decideBooking(decision) {
  return (req, res, next) => {
    const db = req.app.locals.db;
    const id = parseId(req.params.id);
    const result = bookings.decide(db, { id, adminId: req.user.id, decision });
    if (result.notFound) return next(notFound());
    if (result.error) {
      flash(req, 'error', result.error);
    } else {
      audit(req, `booking_${decision}`, { targetType: 'booking', targetId: id, details: `booking owner id ${result.booking.user_id}` });
      flash(req, 'success', `Booking ${decision}.`);
    }
    res.redirect('/admin/bookings?status=pending'); // back to the review queue
  };
}
router.post('/bookings/:id/approve', decideBooking('approved'));
router.post('/bookings/:id/reject', decideBooking('rejected'));

// ======================= Fault reports =======================

router.get('/faults', (req, res) => {
  const db = req.app.locals.db;
  const filters = {
    q: str(req.query.q),
    status: oneOf(req.query.status, faults.STATUSES),
    severity: oneOf(req.query.severity, faults.SEVERITIES),
  };
  const page = pageNumber(req.query.page);
  const { rows, total } = faults.search(db, filters, { limit: PER_PAGE, offset: offsetFor(page) });
  res.render('admin/faults', {
    pageTitle: 'Fault reports', faults: rows, filters, statuses: faults.STATUSES, severities: faults.SEVERITIES,
    pager: buildPager('/admin/faults', filters, page, total),
  });
});

router.post('/faults/:id/status', faultStatusRules, (req, res, next) => {
  const id = parseId(req.params.id);
  if (collectErrors(req)) { flash(req, 'error', 'Invalid status.'); return res.redirect('/admin/faults'); }
  const changed = faults.setStatus(req.app.locals.db, id, req.body.status, req.user.id);
  if (!changed) return next(notFound());
  audit(req, 'fault_status_changed', { targetType: 'fault_report', targetId: id, details: req.body.status });
  flash(req, 'success', 'Fault report updated.');
  res.redirect('/admin/faults');
});

// ======================= Users =======================

router.get('/users', (req, res) => {
  const db = req.app.locals.db;
  const filters = { q: str(req.query.q), role: oneOf(req.query.role, adminUsers.ROLES), active: oneOf(req.query.active, ['active', 'inactive']) };
  const page = pageNumber(req.query.page);
  const { rows, total } = adminUsers.search(db, filters, { limit: PER_PAGE, offset: offsetFor(page) });
  res.render('admin/users', {
    pageTitle: 'Users', users: rows, filters, roles: adminUsers.ROLES, now: new Date().toISOString(),
    pager: buildPager('/admin/users', filters, page, total),
  });
});

router.post('/users/:id/role', roleRules, (req, res, next) => {
  const db = req.app.locals.db;
  const target = adminUsers.findById(db, parseId(req.params.id));
  if (!target) return next(notFound());
  if (collectErrors(req)) { flash(req, 'error', 'Invalid role.'); return res.redirect('/admin/users'); }

  // Safety rule: an admin cannot change their own role. This guarantees at least one admin always remains.
  if (target.id === req.user.id) { flash(req, 'error', 'You cannot change your own role.'); return res.redirect('/admin/users'); }

  if (target.role !== req.body.role) {
    adminUsers.setRole(db, target.id, req.body.role);
    audit(req, 'role_changed', { targetType: 'user', targetId: target.id, details: `${target.email}: ${target.role} -> ${req.body.role}` });
  }
  flash(req, 'success', `${target.full_name} is now ${req.body.role}.`);
  res.redirect('/admin/users');
});

router.post('/users/:id/active', activeRules, (req, res, next) => {
  const db = req.app.locals.db;
  const target = adminUsers.findById(db, parseId(req.params.id));
  if (!target) return next(notFound());
  if (collectErrors(req)) { flash(req, 'error', 'Invalid request.'); return res.redirect('/admin/users'); }

  if (target.id === req.user.id) { flash(req, 'error', 'You cannot deactivate your own account.'); return res.redirect('/admin/users'); }

  const active = req.body.active === '1';
  adminUsers.setActive(db, target.id, active);
  audit(req, active ? 'user_activated' : 'user_deactivated', { targetType: 'user', targetId: target.id, details: target.email });
  flash(req, 'success', `${target.full_name} ${active ? 'activated' : 'deactivated'}.`);
  res.redirect('/admin/users');
});

// ======================= Audit log =======================

router.get('/audit', (req, res) => {
  const db = req.app.locals.db;
  const actionList = auditLogs.actions(db);
  const filters = { q: str(req.query.q), action: oneOf(req.query.action, actionList) };
  const page = pageNumber(req.query.page);
  const perPage = 25;
  const { rows, total } = auditLogs.search(db, filters, { limit: perPage, offset: offsetFor(page, perPage) });
  res.render('admin/audit', {
    pageTitle: 'Audit log', entries: rows, filters, actions: actionList,
    pager: buildPager('/admin/audit', filters, page, total, perPage),
  });
});

module.exports = router;

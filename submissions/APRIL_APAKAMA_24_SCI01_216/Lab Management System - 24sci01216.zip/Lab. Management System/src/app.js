// Builds the Express app. Kept separate from server.js (which calls listen) so that the tests
// can create an app around a throwaway in-memory database.
const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');
const pinoHttp = require('pino-http');
const config = require('./config');
const logger = require('./utils/logger');
const security = require('./middleware/security');
const { sessionMiddleware, loadUser } = require('./middleware/session');
const flash = require('./middleware/flash');
const { csrfProtection, exposeCsrfToken } = require('./middleware/csrf');
const { buildLimiters } = require('./middleware/rateLimit');
const { notFound, errorHandler } = require('./middleware/errorHandler');
const { buildAuthRouter } = require('./routes/auth');
const { buildProfileRouter } = require('./routes/profile');

// `opts` lets tests shrink the rate limits (see tests/ratelimit.test.js).
function createApp(db, opts = {}) {
  const app = express();
  app.locals.db = db;
  const limiters = buildLimiters(opts);

  // Behind Render's HTTPS proxy, Express must trust the first proxy hop. Without this,
  // `req.secure` is false (Secure cookies would break) and every client IP looks the same
  // (rate limiting would block everyone together). Only enabled in production.
  if (config.isProd) app.set('trust proxy', 1);

  app.disable('x-powered-by'); // don't advertise the framework

  app.locals.fmt = require('./utils/format'); // date helpers available in every template
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, '..', 'views'));

  // Request logging. We log only method, path (no query string, which could hold tokens),
  // status and timing. Headers (cookies!) and bodies (passwords!) are never logged.
  app.use(pinoHttp({
    logger,
    serializers: {
      req: (req) => ({ id: req.id, method: req.method, url: String(req.url).split('?')[0] }),
      res: (res) => ({ statusCode: res.statusCode }),
    },
  }));

  // Defaults so templates never hit an undefined variable (even on early errors).
  app.use((req, res, next) => {
    res.locals.user = null;
    res.locals.csrfToken = '';
    res.locals.flash = null;
    res.locals.currentPath = req.path;
    next();
  });

  app.use(security); // Helmet: CSP + security headers
  app.use(express.static(path.join(__dirname, '..', 'public'), { maxAge: config.isProd ? '1d' : 0 }));

  // Health check sits before sessions/CSRF so monitoring pings don't create session rows.
  app.use(require('./routes/health'));

  // Dynamic pages must never be cached: otherwise the Back button after logout could show
  // a previous user's data from the browser cache.
  app.use((req, res, next) => {
    res.set('Cache-Control', 'no-store');
    next();
  });

  app.use(limiters.general);

  // Body parsing with small size limits (blocks oversized payloads).
  app.use(express.urlencoded({ extended: false, limit: '10kb' }));
  app.use(cookieParser()); // needed to read the CSRF cookie

  // Order matters: session -> load user -> flash -> CSRF check -> routes.
  app.use(sessionMiddleware(db));
  app.use(loadUser(db));
  app.use(flash);
  app.use(csrfProtection);   // rejects any state-changing request without a valid token
  app.use(exposeCsrfToken);

  app.use(require('./routes/pages'));
  app.use(buildAuthRouter(limiters));
  app.use(require('./routes/dashboard'));
  app.use(require('./routes/computers'));
  app.use(require('./routes/bookings'));
  app.use(require('./routes/faults'));
  app.use(buildProfileRouter(limiters));
  app.use('/admin', require('./routes/admin'));
  app.use(require('./routes/security'));

  app.use(notFound);
  app.use(errorHandler);
  return app;
}

module.exports = { createApp };

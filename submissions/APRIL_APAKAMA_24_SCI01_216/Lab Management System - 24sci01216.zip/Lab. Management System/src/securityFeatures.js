// Content of the Security page: each protection, how it works here, and where the code lives.
// Keeping this as data (not hard-coded HTML) makes it easy to update as the code changes.
// File paths are relative to the project root.
module.exports = [
  {
    group: 'Identity',
    items: [
      {
        title: 'Password hashing',
        what: 'Passwords are never stored. Only a bcrypt hash (cost factor 12, with a random salt built in) is saved, and login compares by hashing again. Policy: at least 10 characters, a letter and a number, at most 72 bytes (bcrypt limit).',
        where: ['src/routes/auth.js (register, login)', 'src/utils/password.js (policy)', 'src/config.js (bcryptRounds)'],
        tests: 'tests/auth.test.js',
      },
      {
        title: 'Session management',
        what: 'The browser holds only a random session ID in a cookie (HttpOnly, SameSite=Lax, Secure in production). Sessions live in the database, expire after 30 minutes idle or 8 hours total, get a new ID at login (stops session fixation) and are destroyed completely at logout. Changing a password ends the account\'s other sessions.',
        where: ['src/middleware/session.js', 'src/routes/auth.js (regenerate / destroy)', 'src/routes/profile.js (password change)'],
        tests: 'tests/auth.test.js, tests/faults-profile.test.js',
      },
      {
        title: 'Login throttling and lockout',
        what: 'Two layers: an IP rate limit on login and registration, and a per-account lockout (5 wrong passwords lock the account for 15 minutes). Failed attempts and lockouts are written to the audit log.',
        where: ['src/middleware/rateLimit.js', 'src/models/users.js (registerFailedAttempt)', 'src/routes/auth.js'],
        tests: 'tests/ratelimit.test.js, tests/auth.test.js',
      },
      {
        title: 'Generic errors, no account enumeration',
        what: 'Wrong password, unknown email, locked and deactivated accounts all show the same message. A dummy bcrypt comparison keeps response times equal. Registering an email that already exists gives the same reply as a new one.',
        where: ['src/routes/auth.js (GENERIC_LOGIN_ERROR, DUMMY_HASH)'],
        tests: 'tests/auth.test.js',
      },
    ],
  },
  {
    group: 'Access control',
    items: [
      {
        title: 'Role-based access control',
        what: 'Two reusable middleware functions decide access on the server: requireLogin and requireRole. The whole /admin area is protected by one requireRole(\'admin\') line at the top of its router, so no admin route can be left open. The role is read fresh from the database on every request. The navigation menu changes by role, but that is cosmetic only.',
        where: ['src/middleware/auth.js', 'src/routes/admin.js (first line)', 'src/middleware/session.js (loadUser)'],
        tests: 'tests/auth.test.js, tests/admin.test.js',
      },
      {
        title: 'IDOR prevention',
        what: 'Users can only reach their own data. Booking queries always include the owner\'s id taken from the session, so changing an ID in the URL finds nothing; another user\'s booking returns the same 404 as one that does not exist. The profile has no id in its URLs at all.',
        where: ['src/models/bookings.js (findOwn, cancelOwn)', 'src/routes/bookings.js', 'src/routes/profile.js'],
        tests: 'tests/bookings.test.js, tests/faults-profile.test.js',
      },
      {
        title: 'Mass-assignment protection',
        what: 'Routes read only the specific fields they expect. Extra fields such as role, user_id or status in a request are ignored. Self-registration always creates a normal user.',
        where: ['src/routes/profile.js', 'src/routes/bookings.js', 'src/routes/auth.js'],
        tests: 'tests/faults-profile.test.js, tests/auth.test.js',
      },
    ],
  },
  {
    group: 'Input and output',
    items: [
      {
        title: 'Input validation and sanitization',
        what: 'Every form and every query-string filter is validated on the server: type, length, allowed characters, allowed values. Names use a letters-only allow-list; free text must not contain < or >; filters must match known values. The browser\'s own checks are a convenience only.',
        where: ['src/validators/*.js', 'src/middleware/validate.js', 'src/utils/query.js'],
        tests: 'tests/auth.test.js, tests/bookings.test.js, tests/computers.test.js',
      },
      {
        title: 'SQL injection protection',
        what: 'All queries use parameterized statements: user input is passed as bound values, never joined into the SQL text. LIKE wildcards typed by users are escaped. The schema adds CHECK, UNIQUE and FOREIGN KEY constraints as a second line of defence.',
        where: ['src/models/*.js', 'src/db/schema.sql'],
        tests: 'tests/computers.test.js, tests/bookings.test.js, tests/foundation.test.js',
      },
      {
        title: 'Cross-site scripting (XSS) protection',
        what: 'Templates output every value with the escaping tag, so injected markup is shown as text. There are no inline scripts, inline event handlers or style attributes, which lets the Content Security Policy forbid them.',
        where: ['views/**/*.ejs (the <%= %> tag)', 'src/middleware/security.js (CSP)'],
        tests: 'tests/computers.test.js, tests/bookings.test.js, tests/layout.test.js',
      },
      {
        title: 'Content Security Policy',
        what: 'Scripts, styles, fonts and images may only load from this site. Plugins, framing and form posts to other sites are blocked. Fonts are self-hosted so nothing is fetched from third parties.',
        where: ['src/middleware/security.js'],
        tests: 'tests/auth.test.js (security headers)',
      },
      {
        title: 'CSRF protection',
        what: 'Every form carries a secret token tied to the session and a matching cookie. Any POST without a valid token is rejected with 403. Logout is a POST too, so another site cannot log you out.',
        where: ['src/middleware/csrf.js', 'src/app.js (middleware order)', 'every <form> in views/ (hidden _csrf field)'],
        tests: 'tests/csrf.test.js',
      },
    ],
  },
  {
    group: 'Platform and operations',
    items: [
      {
        title: 'Security headers (Helmet)',
        what: 'Helmet adds X-Content-Type-Options, frame protections, a strict referrer policy, cross-origin isolation headers and (in production) HSTS. The X-Powered-By header is removed. Dynamic pages send Cache-Control: no-store.',
        where: ['src/middleware/security.js', 'src/app.js'],
        tests: 'tests/auth.test.js',
      },
      {
        title: 'Error handling',
        what: 'Users see a short, generic page for 400, 403, 404, 429 and 500. Stack traces and SQL errors go to the server log only.',
        where: ['src/middleware/errorHandler.js', 'views/errors/error.ejs'],
        tests: 'tests/foundation.test.js, tests/csrf.test.js',
      },
      {
        title: 'Safe logging',
        what: 'Logs are structured JSON. Cookies, authorization headers, passwords and session IDs are redacted; request logs keep only method, path and status, never the query string or body.',
        where: ['src/utils/logger.js', 'src/app.js (pino-http serializers)'],
        tests: 'tests/audit.test.js',
      },
      {
        title: 'Audit log',
        what: 'Important actions are recorded with user, time and IP: logins, failed logins, lockouts, registrations, password changes, bookings and decisions, role changes, user activation, computer changes. Admins can search it; the application has no code to edit or delete entries.',
        where: ['src/utils/audit.js', 'src/routes/admin.js', 'src/models/auditLogs.js'],
        tests: 'tests/admin.test.js, tests/auth.test.js',
      },
      {
        title: 'HTTPS and proxy settings',
        what: 'In production the app trusts the host\'s proxy (so client IPs and the secure flag are correct), sends Secure cookies and HSTS, and upgrades insecure requests. See DEPLOYMENT.md.',
        where: ['src/app.js (trust proxy)', 'src/middleware/session.js', 'src/middleware/security.js', 'DEPLOYMENT.md'],
        tests: 'manual (see TESTING.md)',
      },
      {
        title: 'Secrets and configuration',
        what: 'No secret is written in the code. Session secret and admin password come from environment variables, and in production the app refuses to start without them. .env is excluded from git.',
        where: ['src/config.js', '.env.example', '.gitignore', 'src/db/seed.js'],
        tests: 'manual (see TESTING.md)',
      },
      {
        title: 'Request limits',
        what: 'Request bodies are capped at 10 KB and the general rate limit applies to every route.',
        where: ['src/app.js', 'src/middleware/rateLimit.js'],
        tests: 'tests/ratelimit.test.js',
      },
    ],
  },
];

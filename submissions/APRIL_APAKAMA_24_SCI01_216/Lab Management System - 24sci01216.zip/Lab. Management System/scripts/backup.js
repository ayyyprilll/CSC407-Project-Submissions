// Database backup:  npm run backup
// Uses SQLite's online backup API, which produces a consistent copy even while the app is running
// (a plain file copy of a live WAL-mode database could be inconsistent).
// Keeps the newest BACKUP_KEEP files (default 7) and deletes older ones, so the folder cannot grow forever.
// Backups contain password HASHES and personal data: store them somewhere private, never in git.
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

async function runBackup({ dbPath, dir, keep = 7, now = new Date() }) {
  if (!fs.existsSync(dbPath)) throw new Error(`Database file not found: ${dbPath}`);
  fs.mkdirSync(dir, { recursive: true });

  const stamp = now.toISOString().replace(/[:.]/g, '-');
  const target = path.join(dir, `lab-${stamp}.db`);

  const db = new Database(dbPath, { readonly: true, fileMustExist: true });
  try {
    await db.backup(target);
  } finally {
    db.close();
  }

  // Retention: file names sort by time, so the oldest come first.
  const all = fs.readdirSync(dir).filter((f) => /^lab-.*\.db$/.test(f)).sort();
  const old = all.slice(0, Math.max(0, all.length - keep));
  old.forEach((f) => fs.rmSync(path.join(dir, f), { force: true }));

  return { target, removed: old.length };
}

module.exports = { runBackup };

if (require.main === module) {
  require('dotenv').config({ quiet: true });
  runBackup({
    dbPath: process.env.DB_PATH || './data/lab.db',
    dir: process.env.BACKUP_DIR || './backups',
    keep: parseInt(process.env.BACKUP_KEEP, 10) || 7,
  })
    .then(({ target, removed }) => console.log(`Backup written to ${target} (${removed} old backup(s) removed)`))
    .catch((err) => { console.error('Backup failed:', err.message); process.exit(1); });
}
